#!/usr/bin/env python3
"""Verify the LaTeX layer with only jinja2 + stdlib.

Renders the template against a fixture full of the characters that break LaTeX
resume pipelines, and asserts nothing leaked unescaped and no Jinja delimiter
survived. Runs without pydantic/tectonic so it works in CI before the container
is built.
"""

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "services" / "docsvc"))

from app.render.latex_env import (  # noqa: E402
    build_env,
    fmt_month,
    fmt_range,
    latex_escape,
    latex_url,
)

FAIL: list[str] = []


def check(name: str, cond: bool, detail: str = "") -> None:
    if cond:
        print(f"  ok   {name}")
    else:
        print(f"  FAIL {name} {detail}")
        FAIL.append(name)


print("\n[1] escaping")
for raw, frag in [
    ("Ernst & Young", r"\&"),
    ("100% integrity", r"\%"),
    ("C#", r"\#"),
    ("user_accounts", r"\_"),
    ("Zeta {Fintech}", r"\{"),
    ("cost $500", r"\$"),
    ("a~b", r"\textasciitilde"),
    ("x^2", r"\textasciicircum"),
    ("back\\slash", r"\textbackslash"),
]:
    check(f"{raw!r} -> {frag}", frag in latex_escape(raw), f"got {latex_escape(raw)!r}")

check("smart quotes normalised", "\u201c" not in latex_escape("\u201chi\u201d"))
check("ellipsis normalised", "\u2026" not in latex_escape("wait\u2026"))
check("zero-width stripped", latex_escape("Py\u200bthon") == "Python")
check("fi ligature normalised", latex_escape("\ufb01nance") == "finance")
check("rupee mapped", r"\textrupee" in latex_escape("\u20b9200"))
check("backslash not double-escaped",
      latex_escape("a\\b").count("textbackslash") == 1)

print("\n[2] urls")
check("url keeps slashes", "/" in latex_url("https://github.com/a/b"))
check("url escapes hash", r"\#" in latex_url("https://x.com/a#b"))

print("\n[3] dates")
check("YYYY-MM", fmt_month("2024-03") == "Mar 2024", fmt_month("2024-03"))
check("YYYY", fmt_month("2024") == "2024")
check("present", fmt_month("present") == "Present")
check("till date variant", fmt_month("till date") == "Present")
check("range", fmt_range({"start": "2022-03", "end": "present"}) == "Mar 2022 -- Present",
      fmt_range({"start": "2022-03", "end": "present"}))
check("bad month falls back", fmt_month("2024-99") == "2024")

print("\n[4] every template renders against hostile data")

FIXTURE = {
    "basics": {
        "name": "Priya Raghunathan",
        "headline": "Backend Engineer — Payments & Ledger",
        "email": "priya.r+jobs@example.co.in",
        "phone": "+91 98765 43210",
        "location": "Kolkata, West Bengal",
        "links": [{"label": "GitHub", "url": "https://github.com/priya_r"}],
        "legacy": {"fatherName": "R. Raghunathan", "dob": "1996-04-12",
                   "maritalStatus": "Single"},
    },
    "summary": {"text": "Cut settlement failures by 40% on a \u20b9200Cr/month ledger.",
                "origin": "user"},
    "sections": [
        {
            "id": "s1", "kind": "experience", "heading": "Work Experience",
            "items": [{
                "id": "e1", "role": "Senior Engineer — Payments",
                "org": "Ernst & Young Technology", "location": "Bengaluru",
                "dates": {"start": "2022-03", "end": "present"},
                "bullets": [
                    {"id": "b1", "origin": "user",
                     "text": "Migrated user_accounts & tax_records with 100% integrity."},
                    {"id": "b2", "origin": "user",
                     "text": "Owned the ledger service (C#/.NET) at 99.98% uptime."},
                ],
            }],
        },
        {
            "id": "s2", "kind": "education", "heading": "Education",
            "items": [{
                "id": "ed1", "degree": "B.Tech",
                "field": "Computer Science & Engineering",
                "institution": "Jadavpur University", "location": "Kolkata",
                "dates": {"start": "2016", "end": "2020"},
                "score": "8.7 CGPA", "details": [],
            }],
        },
        {
            "id": "s3", "kind": "skills", "heading": "Skills",
            "groups": [{"label": "Languages", "items": ["C#", "Python", "Go"]}],
        },
        {
            "id": "s4", "kind": "projects", "heading": "Projects",
            "items": [{
                "id": "p1", "title": "ledger-lite",
                "subtitle": "Open-source double-entry ledger",
                "org": None, "dates": None,
                "url": "https://github.com/priya_r/ledger-lite",
                "bullets": [{"id": "pb1", "origin": "user",
                             "text": "400+ stars; used by 3 startups."}],
            }],
        },
    ],
}

OPT = {
    "accentColor": "#111111", "accentHex": "111111", "fontFamily": "charter",
    "sectionRule": True, "density": "normal", "showSummary": True,
    "margin": 16, "fontsize": 10, "sectionSpaceBefore": 2.0,
    "sectionSpaceAfter": 0.8, "listTopSep": 0.3, "listItemSep": 0.25,
    "entryGap": 0.9,
}

# Render EVERY template against the hostile fixture. A template that only works
# for tidy data is not a working template.
TEMPLATE_ROOT = ROOT / "services" / "docsvc" / "templates"
UNIVERSAL = {
    "accentColor": "#111111", "fontFamily": "charter", "sectionRule": True,
    "density": "normal", "showSummary": True, "headingCase": "upper",
    "nameSize": "LARGE", "nameAlign": "left", "contactStyle": "pipes",
    "ruleWeight": 0.6, "sectionSpread": False, "bulletChar": "textbullet",
    "twoColumn": False, "leftRailWidth": 0.32, "pageLimitHint": 1,
}
DENSITY = {
    "airy":    dict(margin=20, fontsize=11, sectionSpaceBefore=2.6, sectionSpaceAfter=1.1,
                    listTopSep=0.5, listItemSep=0.45, entryGap=1.2),
    "normal":  dict(margin=16, fontsize=10, sectionSpaceBefore=2.0, sectionSpaceAfter=0.8,
                    listTopSep=0.3, listItemSep=0.25, entryGap=0.9),
    "compact": dict(margin=13, fontsize=10, sectionSpaceBefore=1.5, sectionSpaceAfter=0.5,
                    listTopSep=0.15, listItemSep=0.1,  entryGap=0.6),
}

GREEDY = (
    r"tiny|scriptsize|footnotesize|small|normalsize|large|Large|LARGE"
    r"|huge|Huge|bfseries|mdseries|itshape|slshape|scshape|upshape"
    r"|rmfamily|sffamily|ttfamily|normalfont"
)

def resolve(manifest):
    opt = dict(UNIVERSAL)
    opt.update(manifest.get("fixed", {}))
    for k, meta in manifest.get("options", {}).items():
        opt.setdefault(k, meta.get("default"))
    for k, v in DENSITY.get(opt.get("density", "normal"), DENSITY["normal"]).items():
        opt.setdefault(k, v)
    for k, v in manifest.get("fixed", {}).items():
        opt[k] = v
    opt["accentHex"] = str(opt.get("accentColor", "#111111")).lstrip("#").upper() or "111111"
    return opt

def balanced(text):
    depth, prev = 0, ""
    for ch in text:
        if ch == "{" and prev != "\\":
            depth += 1
        elif ch == "}" and prev != "\\":
            depth -= 1
            if depth < 0:
                return False
        prev = ch if prev != "\\" else ""
    return depth == 0

outdir = ROOT / "build"
outdir.mkdir(exist_ok=True)
tdirs = sorted(d for d in TEMPLATE_ROOT.iterdir()
               if d.is_dir() and not d.name.startswith("_"))
check("found 12 templates", len(tdirs) == 12, f"found {len(tdirs)}")

for tdir in tdirs:
    tid = tdir.name
    manifest = json.loads((tdir / "template.json").read_text())
    opt = resolve(manifest)
    env = build_env(tdir)
    try:
        tex = env.get_template("main.tex.j2").render(resume=FIXTURE, opt=opt)
    except Exception as e:
        check(f"{tid}: renders", False, f"{type(e).__name__}: {e}")
        continue

    stripped = re.sub(r"(?m)^\s*%%.*$", "", tex)
    problems = []
    if r"\documentclass" not in tex: problems.append("no documentclass")
    if r"\begin{document}" not in tex: problems.append("no begin document")
    if r"\end{document}" not in tex: problems.append("no end document")
    if r"\VAR{" in tex: problems.append("unconsumed \\VAR")
    if r"\BLOCK{" in tex: problems.append("unconsumed \\BLOCK")
    if re.search(r"(?<!\\)&", stripped): problems.append("bare ampersand")
    greedy = re.findall(rf"\\(?:{GREEDY})[A-Za-z]", stripped)
    if greedy: problems.append(f"greedy cs {sorted(set(greedy))}")
    if not balanced(stripped): problems.append("unbalanced braces")
    # Two \titleformat declarations for \section means one is dead code and a
    # future edit will land on the wrong one.
    if len(re.findall(r"\\titleformat\{(?:name=)?\\section", stripped)) > 1:
        problems.append("duplicate \\titleformat for \\section")
    # A command must be defined before titleformat references it.
    for cmd in re.findall(r"\\titleformat[^\n]*\n(?:[^\n]*\n)?[^\n]*\{(\\rf\w+)\}", stripped):
        defpos = stripped.find(r"\newcommand{" + cmd + "}")
        usepos = stripped.find(cmd + "}")
        if defpos == -1:
            problems.append(f"{cmd} used but never defined")
    # The escaping must survive in every template, not just the first one.
    if r"Ernst \& Young" not in tex: problems.append("ampersand not escaped")
    if r"user\_accounts" not in tex: problems.append("underscore not escaped")
    if r"C\#" not in tex: problems.append("hash not escaped")
    if "100\\%" not in tex: problems.append("percent not escaped")
    # Legacy bio-data must never reach the page, in any template.
    for leaked in ["R. Raghunathan", "1996-04-12"]:
        if leaked in tex: problems.append(f"LEAKED {leaked!r}")
    # Layout claims in the manifest must match what actually got emitted.
    if manifest["layout"]["columns"] == 1:
        for bad in [r"\begin{multicols}", r"\begin{paracol}", r"\begin{minipage}"]:
            if bad in tex: problems.append(f"single-column template used {bad}")

    check(f"{tid} ({manifest['atsGrade']}, {manifest['layout']['columns']}col)",
          not problems, "; ".join(problems))
    (outdir / f"{tid}.tex").write_text(tex, encoding="utf-8")

print(f"\n  wrote {len(tdirs)} .tex files to {outdir}")

print("\n" + "=" * 58)
if FAIL:
    print(f"FAILED: {len(FAIL)} check(s): {', '.join(FAIL)}")
    sys.exit(1)
print("All LaTeX-layer checks passed.")
