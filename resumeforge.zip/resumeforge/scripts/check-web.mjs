#!/usr/bin/env node
/**
 * Static consistency check for the web app.
 *
 * Not a substitute for `tsc --noEmit`, which needs node_modules. This runs with
 * zero dependencies and catches the class of mistake that comes from writing
 * many files in sequence: an import that names an export nobody wrote, a fetch
 * to a route that doesn't exist, a response field the caller never reads.
 */

import { readFileSync, readdirSync, statSync, existsSync } from "node:fs";
import { join, dirname, resolve } from "node:path";

const WEB = resolve(import.meta.dirname, "..", "apps", "web");
const SRC = join(WEB, "src");

const fail = [];
const warn = [];
const ok = [];

function walk(dir) {
  const out = [];
  for (const entry of readdirSync(dir)) {
    const p = join(dir, entry);
    if (statSync(p).isDirectory()) out.push(...walk(p));
    else if (/\.tsx?$/.test(entry)) out.push(p);
  }
  return out;
}

const files = walk(SRC);
const rel = (p) => p.replace(SRC + "/", "");

// ---------------------------------------------------------------- exports map
const exports = new Map(); // module path (no ext) -> Set of export names

for (const f of files) {
  const src = readFileSync(f, "utf8");
  const names = new Set();
  // `export const { handlers, auth } = NextAuth(...)` is how Auth.js is set up
  // and a plain \w+ capture silently misses every name in it.
  let dm;
  const destructured = /export\s+const\s*\{([^}]+)\}\s*=/g;
  while ((dm = destructured.exec(src))) {
    for (const part of dm[1].split(",")) {
      const n = part.trim().split(":").pop()?.trim();
      if (n) names.add(n);
    }
  }

  const patterns = [
    /export\s+(?:async\s+)?function\s+(\w+)/g,
    /export\s+const\s+(\w+)/g,
    /export\s+(?:type|interface)\s+(\w+)/g,
    /export\s+class\s+(\w+)/g,
    /export\s+default\s+/g,
  ];
  for (const re of patterns) {
    let m;
    while ((m = re.exec(src))) names.add(m[1] ?? "default");
  }
  // `export { a, b }` and `export type { A }`
  let m;
  const braceRe = /export\s+(?:type\s+)?\{([^}]+)\}/g;
  while ((m = braceRe.exec(src))) {
    for (const part of m[1].split(",")) {
      const name = part.trim().split(/\s+as\s+/).pop()?.trim();
      if (name) names.add(name);
    }
  }
  exports.set(f.replace(/\.tsx?$/, ""), names);
}

// ---------------------------------------------------------------- imports
console.log("\n[1] internal imports resolve to real exports");

for (const f of files) {
  const src = readFileSync(f, "utf8");
  const importRe = /import\s+(?:type\s+)?(?:\{([^}]+)\}|(\w+))\s+from\s+["']([^"']+)["']/g;
  let m;
  while ((m = importRe.exec(src))) {
    const [, braced, defaultName, spec] = m;
    if (!spec.startsWith("@/") && !spec.startsWith(".")) continue;

    const target = spec.startsWith("@/")
      ? join(SRC, spec.slice(2))
      : resolve(dirname(f), spec);

    const candidates = [
      target,
      target + "/index",
    ];
    const found = candidates.find(
      (c) => exports.has(c) || existsSync(c + ".ts") || existsSync(c + ".tsx")
    );

    if (!found || !exports.has(found)) {
      fail.push(`${rel(f)} imports missing module '${spec}'`);
      continue;
    }

    const available = exports.get(found);
    if (braced) {
      for (const part of braced.split(",")) {
        const name = part.trim().replace(/^type\s+/, "").split(/\s+as\s+/)[0]?.trim();
        if (!name) continue;
        if (!available.has(name)) {
          fail.push(`${rel(f)} imports { ${name} } from '${spec}' — not exported`);
        }
      }
    }
    if (defaultName && !available.has("default")) {
      fail.push(`${rel(f)} default-imports '${spec}' — no default export`);
    }
  }
}
if (!fail.length) ok.push("all internal imports resolve");

// ---------------------------------------------------------------- api routes
console.log("[2] client fetch targets exist as route handlers");

const routeDirs = new Set();
for (const f of files) {
  if (/app\/api\/.*\/route\.ts$/.test(f)) {
    const r = rel(f).replace(/^app/, "").replace(/\/route\.ts$/, "");
    routeDirs.add(r);
  }
}

const fetched = new Set();
for (const f of files) {
  const src = readFileSync(f, "utf8");
  const re = /fetch\(\s*["'](\/api\/[^"'?]+)/g;
  let m;
  while ((m = re.exec(src))) fetched.add(m[1]);
}

/** Dynamic segments are written as [id] on disk but interpolated at runtime,
 *  so compare against a pattern rather than a literal. */
function matchesRoute(url) {
  // Next.js resolves static segments before dynamic ones, so an exact hit must
  // be preferred — otherwise /api/resumes/claim appears to be served by
  // /api/resumes/[id], which is wrong and hides a genuinely missing route.
  if (routeDirs.has(url)) return url;

  const dynamic = [...routeDirs]
    .filter((r) => r.includes("["))
    .sort((a, b) => b.length - a.length);

  for (const r of dynamic) {
    const rx = new RegExp("^" + r.replace(/\[[^\]]+\]/g, "[^/]+") + "$");
    if (rx.test(url)) return r;
  }
  return null;
}

// Template literals in fetch() leave a trailing segment we can't resolve
// statically; treat the resolvable prefix as the claim.
for (const url of fetched) {
  const hit = matchesRoute(url) ?? matchesRoute(url.replace(/\/$/, ""));
  if (hit) ok.push(`route ${url} -> ${hit}`);
  else fail.push(`fetch('${url}') has no route handler`);
}

// ---------------------------------------------------------------- contracts
console.log("[3] response field contracts line up");

// Fields the editor reads out of /api/tailor, via setDraft(json).
const draftSrc = readFileSync(join(SRC, "lib", "draft.ts"), "utf8");
const tailorSrc = readFileSync(join(SRC, "app", "api", "tailor", "route.ts"), "utf8");

const draftFields = [...draftSrc.matchAll(/^\s{2}(\w+):/gm)].map((m) => m[1]);
for (const field of draftFields) {
  if (!new RegExp(`\\b${field}[,:]`).test(tailorSrc)) {
    fail.push(`Draft.${field} is not returned by /api/tailor`);
  }
}
if (draftFields.length) ok.push(`Draft has ${draftFields.length} fields, all returned by /api/tailor`);

// The patch route's response shape vs what PromptPanel reads.
const patchRoute = readFileSync(join(SRC, "app", "api", "patch", "route.ts"), "utf8");
const promptPanel = readFileSync(join(SRC, "components", "PromptPanel.tsx"), "utf8");
for (const key of ["refused", "noop", "explanation", "patch", "resume", "pdfB64", "ats"]) {
  const inRoute = new RegExp(`\\b${key}\\b`).test(patchRoute);
  const inPanel = new RegExp(`json\\.${key}|\\b${key}:`).test(promptPanel);
  if (inPanel && !inRoute) fail.push(`PromptPanel reads json.${key}, /api/patch never sends it`);
}
ok.push("patch route ↔ PromptPanel contract consistent");

// preview route must return what SectionEditor reads
const previewRoute = readFileSync(join(SRC, "app", "api", "render", "preview", "route.ts"), "utf8");
const sectionEditor = readFileSync(join(SRC, "components", "SectionEditor.tsx"), "utf8");
for (const key of ["pdfB64", "ats"]) {
  if (new RegExp(`json\\.${key}`).test(sectionEditor) && !new RegExp(`${key}:`).test(previewRoute)) {
    fail.push(`SectionEditor reads json.${key}, preview route never sends it`);
  }
}
ok.push("preview route ↔ SectionEditor contract consistent");

// ---------------------------------------------------------------- hygiene
console.log("[4] ownership and auth discipline");

const sessionSrc = readFileSync(join(SRC, "lib", "session.ts"), "utf8");
const reposSrc = readFileSync(join(SRC, "lib", "db", "repos.ts"), "utf8");

// Anonymous drafts must expire. A resume held without being asked to hold it
// should not persist indefinitely.
if (!/expireAfterSeconds/.test(readFileSync(join(SRC, "lib", "db", "client.ts"), "utf8"))) {
  fail.push("no TTL index defined — anonymous resumes would never expire");
} else ok.push("TTL index present for anonymous data");

// Anonymous session tokens must be stored hashed.
if (!/sha256\(token\)|sha256\(/.test(reposSrc)) {
  fail.push("anonymous session tokens are not hashed before storage");
} else ok.push("anon session tokens stored hashed");

// The claim must be idempotent, since it runs from two places.
if (!/claim/.test(reposSrc) || !existsSync(join(SRC, "app", "api", "resumes", "claim", "route.ts"))) {
  fail.push("no claim path — anonymous work could not transfer on sign-in");
} else ok.push("claim path present (event + client retry)");

// Every route that writes must resolve an owner rather than trusting a body id.
for (const f of files) {
  if (!/app\/api\/.*route\.ts$/.test(f)) continue;
  const src = readFileSync(f, "utf8");
  const writes = /\b(POST|PATCH|DELETE)\b/.test(src);
  const touchesDb = /db\/repos|resumes\.|versions\./.test(src);
  // Any of these establish identity from a server-side source: a session, or a
  // hashed cookie the client cannot forge. Reading it from the body does not.
  const resolvesOwner =
    /ownerForWrite|currentOwner|pendingAnonId/.test(src) ||
    (/await auth\(\)/.test(src) && /session\??\.user\??\.id/.test(src));
  if (writes && touchesDb && !resolvesOwner) {
    fail.push(`${rel(f)} writes to the database without resolving an owner`);
  }
  // An ownerId taken from the request body is an authorisation hole.
  if (/body\.(ownerId|userId)/.test(src)) {
    fail.push(`${rel(f)} reads an owner id from the request body`);
  }
}
ok.push("all DB-writing routes resolve ownership server-side");

// Undo correctness: the inverse must be computed server-side, never accepted
// from a caller (the prompt path's caller is a language model).
if (/body\.inverse|input\.inverse/.test(reposSrc)) {
  fail.push("inverse patch accepted from caller — undo could be silently wrong");
} else ok.push("inverse patches computed server-side");

if (!/rateLimit/.test(reposSrc)) {
  warn.push("no rate limiter found; the build path is the expensive one");
} else ok.push("rate limiter present");

console.log("[5] development stubs are fenced off");

const phoneSrc = existsSync(join(SRC, "lib", "auth-phone.ts"))
  ? readFileSync(join(SRC, "lib", "auth-phone.ts"), "utf8")
  : "";

if (phoneSrc) {
  // A static OTP is a full auth bypass. It must be impossible to enable in
  // production by accident.
  if (!/NODE_ENV\s*!==\s*["']production["']/.test(phoneSrc)) {
    fail.push("auth-phone.ts does not gate the static OTP on NODE_ENV");
  } else ok.push("static OTP gated on NODE_ENV");

  if (!/ALLOW_STATIC_OTP_IN_PROD/.test(phoneSrc)) {
    fail.push("no explicit production override constant — the gate is not auditable");
  } else ok.push("production override is explicit and greppable");

  if (!/console\.(warn|error)/.test(phoneSrc)) {
    fail.push("static OTP does not log when used; it could run unnoticed");
  } else ok.push("static OTP logs on every use");

  // The synthetic email must not be able to collide with a real address.
  if (/@gmail|@example\.com/.test(phoneSrc)) {
    fail.push("phone users get a real-looking email domain; use a reserved one");
  } else ok.push("phone users get a reserved synthetic address");
}

// Credentials providers do not get database sessions in Auth.js. Using the
// database strategy alongside one means phone sign-in succeeds and then appears
// signed out on the next request.
const authSrc = readFileSync(join(SRC, "lib", "auth.ts"), "utf8");
if (/PhoneOtpProvider|Credentials/.test(authSrc) && /strategy:\s*["']database["']/.test(authSrc)) {
  fail.push(
    'auth.ts uses a Credentials provider with strategy:"database" — Auth.js will not persist the session'
  );
} else ok.push("session strategy compatible with the configured providers");

console.log("[6] build-ability");

// A compose service that builds from a path with no Dockerfile fails at
// `docker compose up`, which is the first thing anyone runs.
const composePath = resolve(WEB, "..", "..", "docker-compose.yml");
if (existsSync(composePath)) {
  const compose = readFileSync(composePath, "utf8");
  for (const m of compose.matchAll(/build:\s*(\S+)/g)) {
    const ctx = resolve(WEB, "..", "..", m[1]);
    if (!existsSync(join(ctx, "Dockerfile"))) {
      fail.push(`docker-compose builds '${m[1]}' but there is no Dockerfile there`);
    }
  }
  if (!fail.some((f) => f.includes("Dockerfile"))) {
    ok.push("every compose build context has a Dockerfile");
  }
}

// output:"standalone" is required by the web Dockerfile's COPY paths.
const nextCfg = existsSync(join(WEB, "next.config.mjs"))
  ? readFileSync(join(WEB, "next.config.mjs"), "utf8")
  : "";
if (existsSync(join(WEB, "Dockerfile")) && !/output:\s*["']standalone["']/.test(nextCfg)) {
  fail.push('web Dockerfile expects .next/standalone but next.config.mjs lacks output:"standalone"');
} else if (nextCfg) ok.push("next.config standalone output matches the Dockerfile");

// useSearchParams outside a Suspense boundary is a build error in Next 15, not
// a warning. The page that renders it must not be the client component itself.
for (const f of files) {
  const src = readFileSync(f, "utf8");
  if (!/useSearchParams/.test(src)) continue;
  const isPage = /app\/.*\/page\.tsx$/.test(f);
  if (isPage && /^["']use client["']/m.test(src)) {
    fail.push(`${rel(f)} is a client page using useSearchParams — needs a Suspense boundary in a server page`);
  }
}
ok.push("useSearchParams sits behind a Suspense boundary");

// session.user.id is load-bearing for ownership and is not in Auth.js defaults.
if (/session\??\.user\??\.id/.test(readFileSync(join(SRC, "lib", "session.ts"), "utf8"))) {
  if (!existsSync(join(SRC, "types", "next-auth.d.ts"))) {
    fail.push("session.user.id is used but next-auth is not module-augmented; this will not typecheck");
  } else ok.push("next-auth module augmentation present for session.user.id");
}

console.log("[7] hygiene");

for (const f of files) {
  const src = readFileSync(f, "utf8");
  if (/localStorage|sessionStorage/.test(src)) {
    warn.push(`${rel(f)} uses browser storage — confirm that's intended for anonymous drafts`);
  }
  // Hooks and event handlers require the client directive.
  const needsClient = /use(State|Effect|Ref|Callback|Memo|Router)\s*[(<]|onClick=|onChange=/.test(src);
  const isRoute = /route\.ts$/.test(f);
  if (needsClient && !isRoute && !/^["']use client["']/m.test(src)) {
    fail.push(`${rel(f)} uses client-only features but has no "use client"`);
  }
  if (/process\.env\.GEMINI_API_KEY/.test(src) && !/lib\/gemini\.ts$/.test(f)) {
    fail.push(`${rel(f)} reads GEMINI_API_KEY directly — go through lib/gemini.ts`);
  }
  if (/NEXT_PUBLIC_[A-Z_]*(KEY|TOKEN|SECRET)/.test(src)) {
    fail.push(`${rel(f)} exposes a credential to the browser via NEXT_PUBLIC_`);
  }
}
if (!fail.some((f) => f.includes("use client"))) ok.push('"use client" present where required');

// ---------------------------------------------------------------- report
console.log("\n" + "=".repeat(62));
for (const o of ok) console.log(`  ok    ${o}`);
for (const w of warn) console.log(`  note  ${w}`);
for (const f of fail) console.log(`  FAIL  ${f}`);
console.log("=".repeat(62));
console.log(`${ok.length} ok · ${warn.length} notes · ${fail.length} failures`);
process.exit(fail.length ? 1 : 0);
