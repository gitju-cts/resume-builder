#!/usr/bin/env node
/**
 * Schema drift check.
 *
 * One JSON Schema, two languages. Every field has to exist in all three places
 * or the two halves of the system disagree — and the failure mode is nasty:
 * Pydantic runs `extra="forbid"`, so a field added on the TypeScript side but
 * not the Python side makes the render service reject the document with a 422.
 * That is a production outage caused by a one-line edit, which is exactly the
 * kind of thing a cheap CI check should catch instead of a user.
 *
 * Deliberately dependency-free so it runs before `npm install`.
 */

import { readFileSync } from "node:fs";
import { join, resolve } from "node:path";

const ROOT = resolve(import.meta.dirname, "..");
const schema = JSON.parse(
  readFileSync(join(ROOT, "schema", "resume.schema.json"), "utf8")
);
const zodSrc = readFileSync(
  join(ROOT, "apps", "web", "src", "lib", "schema.ts"),
  "utf8"
);
const pySrc = readFileSync(
  join(ROOT, "services", "docsvc", "app", "models.py"),
  "utf8"
);

const fail = [];
const ok = [];

/** camelCase -> snake_case, matching the Pydantic alias convention. */
const snake = (s) => s.replace(/[A-Z]/g, (c) => "_" + c.toLowerCase());

/** Collect every property name declared anywhere in the JSON Schema. */
function collectFields(node, acc = new Map(), owner = "root") {
  if (!node || typeof node !== "object") return acc;

  if (node.properties) {
    for (const [name, sub] of Object.entries(node.properties)) {
      if (!acc.has(name)) acc.set(name, owner);
      collectFields(sub, acc, name);
    }
  }
  for (const key of ["items", "then", "if"]) {
    if (node[key]) collectFields(node[key], acc, owner);
  }
  for (const key of ["oneOf", "anyOf", "allOf"]) {
    if (Array.isArray(node[key])) {
      for (const sub of node[key]) collectFields(sub, acc, owner);
    }
  }
  if (node.$defs) {
    for (const [name, sub] of Object.entries(node.$defs)) {
      collectFields(sub, acc, name);
    }
  }
  return acc;
}

const fields = collectFields(schema);

// Fields the schema declares but each language legitimately need not name.
const SKIP = new Set([
  "$schema",
  // Union discriminators appear as `kind: z.literal(...)` / Literal[...]
  "kind",
]);

console.log(`\n[1] ${fields.size} field(s) declared in resume.schema.json`);

for (const [name] of fields) {
  if (SKIP.has(name)) continue;

  // Zod: field names appear verbatim as object keys.
  const inZod = new RegExp(`\\b${name}\\s*:`).test(zodSrc);

  // Pydantic: either the snake_case attribute or an explicit alias.
  const snakeName = snake(name);
  const inPy =
    new RegExp(`\\b${snakeName}\\s*:`).test(pySrc) ||
    new RegExp(`alias\\s*=\\s*["']${name}["']`).test(pySrc);

  if (!inZod && !inPy) {
    fail.push(`'${name}' missing from BOTH schema.ts and models.py`);
  } else if (!inZod) {
    fail.push(`'${name}' in models.py but missing from schema.ts`);
  } else if (!inPy) {
    fail.push(
      `'${name}' in schema.ts but missing from models.py — Pydantic uses extra="forbid", so the render service will reject documents containing it`
    );
  } else {
    ok.push(name);
  }
}

// ---------------------------------------------------------------- invariants
console.log("[2] provenance invariant present in both languages");

if (!/ai-rewritten/.test(zodSrc) || !/sourceId|source_id/.test(zodSrc)) {
  fail.push("schema.ts has no ai-rewritten/sourceId provenance rule");
} else {
  ok.push("provenance rule (TypeScript)");
}
if (!/ai-rewritten/.test(pySrc) || !/source_id/.test(pySrc)) {
  fail.push("models.py has no ai-rewritten/source_id provenance rule");
} else {
  ok.push("provenance rule (Python)");
}

// The rule has to be *enforced*, not merely mentioned.
if (!/superRefine|ResumeStrict/.test(zodSrc)) {
  fail.push("schema.ts mentions provenance but never enforces it (no ResumeStrict)");
}
if (!/model_validator/.test(pySrc)) {
  fail.push("models.py mentions provenance but never enforces it (no model_validator)");
}

console.log("[3] legacy bio-data fields are captured, not rendered");

const legacyFields = Object.keys(
  schema.properties.basics.properties.legacy.properties
);
for (const f of legacyFields) {
  const inZod = new RegExp(`\\b${f}\\s*:`).test(zodSrc);
  const inPy =
    new RegExp(`\\b${snake(f)}\\s*:`).test(pySrc) ||
    new RegExp(`alias\\s*=\\s*["']${f}["']`).test(pySrc);
  if (!inZod || !inPy) fail.push(`legacy field '${f}' not carried in both languages`);
}
if (legacyFields.length) {
  ok.push(`${legacyFields.length} legacy bio-data fields carried in both`);
}

// ---------------------------------------------------------------- report
console.log("\n" + "=".repeat(62));
console.log(`  ok    ${ok.length} field(s)/invariant(s) consistent across all three`);
for (const f of fail) console.log(`  FAIL  ${f}`);
console.log("=".repeat(62));

if (fail.length) {
  console.log(`${fail.length} drift(s). Fix schema.ts and/or models.py.`);
  process.exit(1);
}
console.log("No drift.");
