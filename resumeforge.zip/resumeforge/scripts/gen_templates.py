#!/usr/bin/env python3
"""Generate the template catalogue.

Twelve templates, one shared base. Each entry below declares only what makes it
different — typography, density, rule treatment, heading style, layout — and the
ATS rules stay in `_shared/base.tex.j2` where they can be fixed once.

Run after editing SPECS:  python3 scripts/gen_templates.py

`atsScore` is deliberately null in every manifest. A score is a measurement of a
rendered document, not a property a template can assert about itself; it gets
filled in by `atslint` at publish time. Claiming one here would be the exact
dishonesty the lint engine exists to prevent.
"""

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEMPLATES = ROOT / "services" / "docsvc" / "templates"

COLOR = {
    "type": "color", "label": "Accent colour", "default": "#111111",
    "help": "Near-black scores best. Colour carries no meaning to a parser.",
}
FONT = {
    "type": "enum", "label": "Typeface",
    "values": ["charter", "latinmodern", "helvet", "palatino", "times"],
    "labels": ["Charter (serif)", "Latin Modern (serif)", "Helvetica (sans)",
               "Palatino (serif)", "Times (serif)"],
    "default": "charter",
}
DENSITY = {
    "type": "enum", "label": "Spacing", "values": ["airy", "normal", "compact"],
    "labels": ["Airy", "Normal", "Compact — fits more on one page"],
    "default": "normal",
}
RULE = {"type": "boolean", "label": "Rule under section headings", "default": True}
SUMMARY = {"type": "boolean", "label": "Show the summary paragraph", "default": True}

BASE_OPTS = {
    "accentColor": COLOR, "fontFamily": FONT, "sectionRule": RULE,
    "density": DENSITY, "showSummary": SUMMARY,
}

# --------------------------------------------------------------------------
# id, name, blurb, grade, cols, fixed overrides, categories, situations,
# seniority, maxPages, recommendedOrder, extra preamble/blocks
# --------------------------------------------------------------------------
SPECS = [
    {
        "id": "ats-classic-single",
        "name": "Classic Single Column",
        "blurb": "The safest choice. Plain headings, one column, nothing a parser can trip over.",
        "grade": "A", "cols": 1,
        "fixed": {},
        "categories": ["fresher-any-stream", "cs-engineer-fresher", "software-engineer",
                       "commerce-accounting", "govt-employee", "school-teacher",
                       "retail-frontline", "skilled-trades", "bpo-customer-support",
                       "business-analyst", "operations-supplychain"],
        "situations": ["standard", "biodata-upgrade", "first-job-no-experience",
                       "returning-after-gap"],
        "seniority": ["fresher", "entry", "mid", "senior"],
        "maxPages": 1,
        "order": ["summary", "experience", "education", "skills", "projects"],
    },
    {
        "id": "ats-compact-tech",
        "name": "Compact Technical",
        "blurb": "Tight spacing so a dense technical history still fits one page.",
        "grade": "A", "cols": 1,
        "fixed": {"density": "compact", "fontFamily": "latinmodern",
                  "headingCase": "upper", "ruleWeight": 0.5},
        "categories": ["cs-engineer-fresher", "software-engineer", "java-backend",
                       "dotnet-backend", "frontend-web", "fullstack", "mobile-android-ios",
                       "devops-sre-cloud", "qa-automation", "database-admin",
                       "cybersecurity", "embedded-vlsi", "ai-ml-engineer"],
        "situations": ["standard", "internship-seeker"],
        "seniority": ["entry", "mid", "senior"],
        "maxPages": 1,
        "order": ["summary", "skills", "experience", "projects", "education"],
    },
    {
        "id": "ats-senior-impact",
        "name": "Senior Impact",
        "blurb": "Summary-led, generous spacing. Built for scope and outcomes over lists of tools.",
        "grade": "A", "cols": 1,
        "fixed": {"density": "airy", "fontFamily": "palatino", "nameSize": "huge",
                  "headingCase": "upper", "ruleWeight": 0.8},
        "categories": ["senior-dev-manager", "product-manager", "operations-supplychain",
                       "finance-analyst", "mba-marketing", "sales-bd",
                       "business-analyst", "hr-recruiter"],
        "situations": ["standard"],
        "seniority": ["senior", "lead", "executive"],
        "maxPages": 2,
        "order": ["summary", "experience", "skills", "education", "awards"],
    },
    {
        "id": "ats-skills-forward",
        "name": "Skills Forward",
        "blurb": "Leads with capability rather than chronology. For changing field or returning to work.",
        "grade": "A", "cols": 1,
        "fixed": {"headingCase": "upper", "sectionRule": True, "fontFamily": "helvet"},
        "categories": ["career-switcher", "java-backend", "ai-ml-engineer",
                       "data-analyst-bi", "uiux-designer", "qa-automation",
                       "bpo-customer-support", "hr-recruiter"],
        "situations": ["career-switcher", "returning-after-gap", "standard"],
        "seniority": ["entry", "mid", "senior"],
        "maxPages": 1,
        "order": ["summary", "skills", "projects", "experience", "education"],
    },
    {
        "id": "ats-academic-cv",
        "name": "Academic CV",
        "blurb": "Publications first and no page limit. For faculty, research and doctoral applications.",
        "grade": "A", "cols": 1,
        "fixed": {"fontFamily": "times", "density": "normal", "headingCase": "title",
                  "sectionRule": True, "bulletChar": "textendash", "pageLimitHint": 99},
        "categories": ["professor-lecturer", "research-scholar-phd",
                       "academic-administrator", "biotech-lifesciences",
                       "doctor-mbbs", "agriculture-agronomy"],
        "situations": ["academic-cv"],
        "seniority": ["mid", "senior", "lead", "executive"],
        "maxPages": 99,
        "order": ["summary", "education", "experience", "publications",
                  "awards", "skills"],
        "passes": 2,
    },
    {
        "id": "ats-simple-modern",
        "name": "Simple and Clear",
        "blurb": "Larger type, plenty of air, no decoration. The easiest to read on paper or a phone.",
        "grade": "A", "cols": 1,
        "fixed": {"density": "airy", "fontFamily": "helvet", "sectionRule": False,
                  "headingCase": "upper", "nameSize": "LARGE"},
        "categories": ["retail-frontline", "skilled-trades", "logistics-driver",
                       "hospitality-hotel", "bpo-customer-support", "govt-employee",
                       "nursing-paramedical", "lab-technician", "fresher-any-stream"],
        "situations": ["biodata-upgrade", "first-job-no-experience", "standard",
                       "returning-after-gap"],
        "seniority": ["fresher", "entry", "mid"],
        "maxPages": 1,
        "order": ["summary", "experience", "education", "skills"],
    },
    {
        "id": "ats-banded-sections",
        "name": "Banded Sections",
        "blurb": "Full-width tinted bands separate each section. Visual structure without columns.",
        "grade": "B", "cols": 1,
        "fixed": {"headingCase": "upper", "sectionRule": False, "sectionSpread": True,
                  "fontFamily": "helvet", "accentColor": "#243B6B"},
        "categories": ["uiux-designer", "graphic-designer", "content-writer",
                       "video-editor-motion", "mba-marketing", "product-manager"],
        "situations": ["standard"],
        "seniority": ["entry", "mid", "senior"],
        "maxPages": 1,
        "order": ["summary", "experience", "projects", "skills", "education"],
        "band": True,
    },
    {
        "id": "ats-two-column",
        "name": "Two Column",
        "blurb": "Narrow rail for skills and education, main column for experience. Lower ATS grade — check the score.",
        "grade": "B", "cols": 2,
        "fixed": {"twoColumn": True, "density": "compact", "leftRailWidth": 0.32,
                  "headingCase": "upper", "fontFamily": "helvet", "showSummary": False},
        "categories": ["fullstack", "data-analyst-bi", "uiux-designer",
                       "frontend-web", "graphic-designer"],
        "situations": ["standard"],
        "seniority": ["entry", "mid"],
        "maxPages": 1,
        "order": ["skills", "education", "experience", "projects"],
        "note": "Multi-column layouts risk reading-order scrambling. Entries are never split across columns, but this still grades below single column.",
    },
    {
        "id": "ats-educator",
        "name": "Educator",
        "blurb": "Room for subjects taught, boards and certifications alongside teaching history.",
        "grade": "A", "cols": 1,
        "fixed": {"fontFamily": "palatino", "headingCase": "title",
                  "sectionRule": True, "density": "normal"},
        "categories": ["school-teacher", "professor-lecturer",
                       "academic-administrator", "nursing-paramedical"],
        "situations": ["standard", "returning-after-gap"],
        "seniority": ["entry", "mid", "senior", "lead"],
        "maxPages": 2,
        "order": ["summary", "experience", "education", "certifications", "skills"],
    },
    {
        "id": "ats-creative-minimal",
        "name": "Creative Minimal",
        "blurb": "Quiet type and wide margins, with room for portfolio links. Still plain text underneath.",
        "grade": "B", "cols": 1,
        "fixed": {"density": "airy", "fontFamily": "latinmodern", "sectionRule": False,
                  "headingCase": "title", "bulletChar": "textendash",
                  "nameAlign": "center", "contactStyle": "pipes"},
        "categories": ["artist-portfolio", "content-writer", "photographer",
                       "graphic-designer", "video-editor-motion"],
        "situations": ["standard"],
        "seniority": ["entry", "mid", "senior"],
        "maxPages": 1,
        "order": ["summary", "projects", "experience", "skills", "education"],
    },
    {
        "id": "ats-govt-formal",
        "name": "Formal",
        "blurb": "Conventional and unadorned. Suits government, banking and defence applications.",
        "grade": "A", "cols": 1,
        "fixed": {"fontFamily": "times", "headingCase": "upper", "sectionRule": True,
                  "ruleWeight": 0.8, "contactStyle": "lines", "density": "normal"},
        "categories": ["govt-employee", "defence-services", "banking-bfsi",
                       "legal-advocate", "ca-cs-cma", "commerce-accounting"],
        "situations": ["standard", "biodata-upgrade"],
        "seniority": ["fresher", "entry", "mid", "senior"],
        "maxPages": 2,
        "order": ["summary", "education", "experience", "certifications", "skills"],
    },
    {
        "id": "ats-fresher-projects",
        "name": "Fresher — Projects First",
        "blurb": "For a first job: coursework, projects and internships lead, before a short work history.",
        "grade": "A", "cols": 1,
        "fixed": {"density": "normal", "fontFamily": "charter", "headingCase": "upper"},
        "categories": ["cs-engineer-fresher", "fresher-any-stream",
                       "mechanical-engineer", "civil-engineer",
                       "electrical-electronics", "chemical-engineer",
                       "agriculture-agronomy", "biotech-lifesciences",
                       "commerce-accounting", "data-analyst-bi"],
        "situations": ["first-job-no-experience", "internship-seeker", "standard"],
        "seniority": ["fresher", "entry"],
        "maxPages": 1,
        "order": ["summary", "education", "projects", "skills", "experience"],
    },
]

ALL_SECTIONS = ["experience", "education", "skills", "projects", "certifications",
                "publications", "awards", "languages", "volunteering",
                "extracurricular", "custom"]

PACKAGES = ["geometry", "titlesec", "enumitem", "hyperref", "textcomp", "fontenc",
            "inputenc", "microtype", "xcolor", "charter", "lmodern", "helvet",
            "tgpagella", "tgtermes"]


def manifest(spec: dict) -> dict:
    pkgs = list(PACKAGES)
    if spec["cols"] == 2:
        pkgs.append("paracol")
    if spec.get("band"):
        pkgs.append("tcolorbox")

    m = {
        "id": spec["id"],
        "version": "1.0.0",
        "name": spec["name"],
        "blurb": spec["blurb"],
        "engine": "tectonic",
        "passes": spec.get("passes", 1),
        "layout": {
            "columns": spec["cols"],
            "style": spec["id"].replace("ats-", ""),
            "photo": False,
        },
        "atsGrade": spec["grade"],
        # Measured by atslint on a rendered document, never asserted here.
        "atsScore": None,
        "categories": spec["categories"],
        "situations": spec["situations"],
        "seniority": spec["seniority"],
        "supportedSections": ALL_SECTIONS,
        "maxPagesRecommended": spec["maxPages"],
        "minSchemaVersion": "1.0",
        "packages": sorted(set(pkgs)),
        # A recommendation the tailoring step reads. The document's own section
        # order always wins at render time — a template must not silently
        # reorder what the person arranged.
        "recommendedOrder": spec["order"],
        "fixed": spec["fixed"],
        "options": {k: v for k, v in BASE_OPTS.items() if k not in spec["fixed"]},
    }
    if spec.get("note"):
        m["atsNote"] = spec["note"]
    return m


def template_body(spec: dict) -> str:
    """Each template is an override set, not a copy of the base."""
    lines = [
        f"%% {spec['id']} v1.0.0 — {spec['name']}",
        f"%% {spec['blurb']}",
        "%%",
        "%% Extends the shared base, which owns every ATS rule. This file only",
        "%% expresses what makes this template different.",
        r"\BLOCK{ extends '_shared/base.tex.j2' }",
    ]

    if spec.get("band"):
        lines += [
            "",
            "%% Tinted full-width bands behind section headings.",
            "%%",
            "%% Full width on purpose: a colorbox paints a background, so the",
            "%% heading stays ordinary extractable text and costs a parser",
            "%% nothing. A coloured box set beside the text would become a",
            "%% column, which is the thing that actually breaks reading order.",
            "%%",
            "%% The command is defined in extra_preamble because the base emits",
            "%% that block before sectionstyle, so it exists by the time",
            "%% titleformat references it.",
            r"\BLOCK{ block extra_preamble }",
            r"\newcommand{\rfband}[1]{%",
            r"  \colorbox{accent}{%",
            r"    \parbox{\dimexpr\linewidth-2\fboxsep\relax}{%",
            r"      \strut\color{white}\MakeUppercase{#1}\strut}}%",
            r"}",
            r"\BLOCK{ endblock }",
            "",
            "%% One titleformat, not two. An earlier draft declared it twice and",
            "%% the first was silently dead — the kind of thing that looks fine",
            "%% until someone edits the wrong one.",
            r"\BLOCK{ block sectionstyle }",
            r"\titleformat{\section}[block]",
            r"  {\normalfont\large\bfseries}{}{0pt}{\rfband}",
            r"\titlespacing*{\section}{0pt}{\VAR{opt.sectionSpaceBefore}ex}{\VAR{opt.sectionSpaceAfter}ex}",
            r"\BLOCK{ endblock }",
        ]

    if spec["id"] == "ats-academic-cv":
        lines += [
            "",
            "%% Academic CVs run long and are read differently — no one-page",
            "%% pressure, and numbered publications so they can be cited.",
            r"\BLOCK{ block extra_preamble }",
            r"\setlist[enumerate]{leftmargin=6mm, topsep=0.3ex, itemsep=0.2ex}",
            r"\BLOCK{ endblock }",
        ]

    if spec["id"] == "ats-creative-minimal":
        lines += [
            "",
            "%% Wider margins and a hairline under the name rather than under",
            "%% every heading. Restraint is the whole point of this one.",
            r"\BLOCK{ block extra_preamble }",
            r"\setlength{\emergencystretch}{2em}",
            r"\BLOCK{ endblock }",
        ]

    return "\n".join(lines) + "\n"


def main() -> int:
    written = 0
    for spec in SPECS:
        d = TEMPLATES / spec["id"]
        d.mkdir(parents=True, exist_ok=True)

        (d / "template.json").write_text(
            json.dumps(manifest(spec), indent=2) + "\n", encoding="utf-8"
        )
        (d / "main.tex.j2").write_text(template_body(spec), encoding="utf-8")
        (d / "packages.txt").write_text(
            "\n".join(manifest(spec)["packages"]) + "\n", encoding="utf-8"
        )
        written += 1
        print(f"  {spec['id']:<26} grade {spec['grade']}  {spec['cols']} col")

    print(f"\n{written} templates written to {TEMPLATES}")

    grades = {}
    for spec in SPECS:
        grades[spec["grade"]] = grades.get(spec["grade"], 0) + 1
    print("grade mix:", ", ".join(f"{g}={n}" for g, n in sorted(grades.items())))
    print("(A-heavy is correct — the safe layouts should outnumber the pretty ones)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
