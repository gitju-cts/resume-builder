#!/usr/bin/env bash
# Everything verifiable without node_modules, a TeX engine, or an API key.
# Wire this into CI as the pre-install gate.
set -e
cd "$(dirname "$0")/.."
echo "=== schema drift (JSON Schema <-> Zod <-> Pydantic) ==="
node scripts/check-schema-drift.mjs
echo
echo "=== template catalogue (12 manifests, grade honesty) ==="
node scripts/check-templates.mjs
echo
echo "=== web wiring (imports, routes, ownership, stubs) ==="
node scripts/check-web.mjs
echo
echo "=== latex layer (all 12 templates vs hostile data) ==="
python3 scripts/verify_latex.py
echo
echo "All pre-install checks passed."
