#!/usr/bin/env bash
# First-run setup. Idempotent — safe to run again.
set -e
cd "$(dirname "$0")/.."

echo "ResumeForge setup"
echo

if [ ! -f .env ]; then
  cp .env.example .env
  echo "  created .env from .env.example"
  # A real secret beats a placeholder nobody replaces.
  if command -v openssl >/dev/null 2>&1; then
    SECRET=$(openssl rand -base64 32)
    TOKEN=$(openssl rand -base64 32)
    sed -i.bak "s|^AUTH_SECRET=.*|AUTH_SECRET=${SECRET}|" .env
    sed -i.bak "s|^DOCSVC_TOKEN=.*|DOCSVC_TOKEN=${TOKEN}|" .env
    rm -f .env.bak
    echo "  generated AUTH_SECRET and DOCSVC_TOKEN"
  fi
else
  echo "  .env already exists, leaving it alone"
fi

if [ ! -f apps/web/.env.local ]; then
  ln -sf ../../.env apps/web/.env.local
  echo "  linked apps/web/.env.local -> .env"
fi

echo
echo "Running pre-install checks..."
./scripts/check-all.sh >/dev/null && echo "  all checks passed"

echo
if grep -q "^GEMINI_API_KEY=paste-your-key-here" .env 2>/dev/null; then
  echo "NEXT: add your Gemini API key to .env, then run:  npm run dev"
  echo "      (get one at https://aistudio.google.com/apikey)"
else
  echo "NEXT: npm run dev    # brings up mongo, docsvc and web"
fi
echo
echo "Notes for this build:"
echo "  - Phone sign-in accepts a fixed code (123456). Development only."
echo "  - Rate limiting is off. Turn it on before anyone else can reach this."
