#!/usr/bin/env node
/**
 * Template catalogue check.
 *
 * The manifests drive the gallery, the options panel and the picker, so a
 * malformed one breaks UI that has no other source of truth. This runs without
 * Python or TeX so it can gate a commit.
 */
import { readFileSync, readdirSync, existsSync } from "node:fs";
import { join, resolve } from "node:path";

const ROOT = resolve(import.meta.dirname, "..");
const DIR = join(ROOT, "services", "docsvc", "templates");
const fail = [];
const ok = [];

const dirs = readdirSync(DIR).filter((d) => !d.startsWith("_"));
const REQUIRED = [
  "id", "version", "name", "blurb", "engine", "atsGrade", "categories",
  "situations", "seniority", "supportedSections", "maxPagesRecommended",
  "minSchemaVersion", "packages", "options", "layout",
];

const ids = new Set();
const allCategories = new Set();
const gradeCount = {};

for (const d of dirs) {
  const mPath = join(DIR, d, "template.json");
  if (!existsSync(mPath)) { fail.push(`${d}: no template.json`); continue; }
  if (!existsSync(join(DIR, d, "main.tex.j2"))) { fail.push(`${d}: no main.tex.j2`); continue; }

  let m;
  try { m = JSON.parse(readFileSync(mPath, "utf8")); }
  catch (e) { fail.push(`${d}: manifest is not valid JSON — ${e.message}`); continue; }

  for (const k of REQUIRED) {
    if (m[k] === undefined) fail.push(`${d}: manifest missing '${k}'`);
  }
  if (m.id !== d) fail.push(`${d}: manifest id '${m.id}' does not match its directory`);
  if (ids.has(m.id)) fail.push(`${m.id}: duplicate template id`);
  ids.add(m.id);

  if (!["A", "B", "C"].includes(m.atsGrade)) fail.push(`${d}: bad atsGrade '${m.atsGrade}'`);
  gradeCount[m.atsGrade] = (gradeCount[m.atsGrade] ?? 0) + 1;

  // A template must never assert its own score. Scores are measured from a
  // rendered document by atslint; a self-declared one is exactly the unearned
  // claim this product exists to replace.
  if (m.atsScore !== null && m.atsScore !== undefined) {
    fail.push(`${d}: atsScore must be null — it is measured, not declared`);
  }

  // Multi-column carries real parsing risk and must not be sold as safest.
  if (m.layout?.columns > 1 && m.atsGrade === "A") {
    fail.push(`${d}: ${m.layout.columns}-column layout cannot be grade A`);
  }
  if (m.layout?.columns > 1 && !m.atsNote) {
    fail.push(`${d}: multi-column template needs an atsNote explaining the risk`);
  }
  // A photo on a resume is unreadable to a parser and a liability to employers.
  if (m.layout?.photo === true) fail.push(`${d}: templates must not render photos`);

  for (const c of m.categories ?? []) allCategories.add(c);

  // Every option must declare a default, or the render hits StrictUndefined.
  for (const [k, meta] of Object.entries(m.options ?? {})) {
    if (meta.default === undefined) fail.push(`${d}: option '${k}' has no default`);
    if (meta.type === "enum" && !meta.values?.includes(meta.default)) {
      fail.push(`${d}: option '${k}' default is not one of its values`);
    }
  }
  ok.push(`${m.id} (${m.atsGrade}, ${m.layout?.columns}col)`);
}

if (dirs.length < 12) fail.push(`only ${dirs.length} templates; 12 expected`);

// Grade A must dominate. If the pretty layouts outnumber the safe ones, the
// default experience is worse regardless of what the picker prefers.
if ((gradeCount.A ?? 0) <= (gradeCount.B ?? 0) + (gradeCount.C ?? 0)) {
  fail.push("grade A templates do not outnumber the rest; the safe path must be the common one");
}

// Cross-check against the picker's taxonomy so a category can't be referenced
// by a manifest but absent from the code that routes to it.
const pickerSrc = readFileSync(
  join(ROOT, "apps", "web", "src", "lib", "templatePicker.ts"), "utf8"
);
const known = new Set([...pickerSrc.matchAll(/"([a-z0-9-]+)"/g)].map((m) => m[1]));
for (const c of allCategories) {
  if (!known.has(c)) fail.push(`category '${c}' used by a manifest but missing from ROLE_FAMILIES`);
}

console.log("\n" + "=".repeat(62));
for (const o of ok) console.log(`  ok    ${o}`);
for (const f of fail) console.log(`  FAIL  ${f}`);
console.log("=".repeat(62));
console.log(
  `${dirs.length} templates · grades ${Object.entries(gradeCount).sort().map(([g, n]) => `${g}=${n}`).join(" ")} · ` +
  `${allCategories.size} categories covered · ${fail.length} failures`
);
process.exit(fail.length ? 1 : 0);
