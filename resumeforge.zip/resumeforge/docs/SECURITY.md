# Security — the LaTeX sandbox

**Read this before deploying anything. The compile path is a remote code
execution surface, and it is a launch blocker, not a hardening task.**

## Why this is serious

LaTeX is Turing-complete. It can read files, write files, and — with
shell-escape — execute arbitrary commands. Two facts make that our problem:

1. Even for our own templates, the *content* is user-supplied text.
2. Once the LaTeX editor panel ships, the *source itself* is user-supplied.

A naively configured TeX Live container plus a user-editable LaTeX panel is the
fastest known route to being cryptomined. Treat every compile as hostile code.

## Defence layers

Defence in depth. No single layer is trusted.

### 1. Source rejection (`app/render/pdf.py`)

`assert_safe_tex()` rejects source matching any of:

| Pattern | Why |
|---|---|
| `\write18`, `\immediate\write` | shell execution |
| `\openout`, `\openin` | file write / read |
| `\input{/…}`, `\include{/…}` | absolute path read (`/etc/passwd`) |
| `../` | directory traversal |
| `\directlua` | Lua `os.execute` |
| `\catcode` reassignment of `\` | escapes the other filters |
| `shellesc` package, `\ShellEscape` | shell execution |

This is a **filter, not a boundary**. TeX has many ways to obfuscate a command
name, so this layer exists to catch the obvious and cheap cases. It is never the
thing standing between an attacker and the host.

### 2. Engine flags

Tectonic runs with `--untrusted`, which disables shell-escape and `\write18`
at the engine level regardless of what the document requests. Never pass
`--shell-escape`. Never make it configurable.

### 3. Process limits (`_limits()`, applied post-fork pre-exec)

| Limit | Value | Prevents |
|---|---|---|
| `RLIMIT_CPU` | 20s | infinite expansion loops |
| `RLIMIT_AS` | 512MB | memory exhaustion |
| `RLIMIT_FSIZE` | 10MB | disk-filling output |
| `RLIMIT_NPROC` | 32 | fork bombs |
| `RLIMIT_CORE` | 0 | core dumps containing memory |

Plus a wall-clock `subprocess.timeout` as a backstop, because `RLIMIT_CPU` does
not catch a process blocked on I/O.

### 4. Filesystem

- Each compile gets a fresh `mkdtemp` directory, destroyed in a `finally` block.
- The container root is `read_only: true`.
- `/tmp/compile` is a `tmpfs` capped at 128MB.
- The Tectonic cache is `chmod a-w` at build time.
- `HOME` and `TEXMFHOME` point *inside* the scratch dir, so a document that
  writes config files cannot affect the next compile.

### 5. Network

**The compile container has no network access** (`networks: [internal]` with
`internal: true` in `docker-compose.yml`).

This is why the Dockerfile primes the Tectonic cache at build time. Tectonic
normally downloads CTAN packages on demand; with networking off, an unprimed
cache means every compile fails. Priming is not an optimisation — it is what
makes the no-network posture possible.

When a template adds a package to its `packages[]` manifest array, add the
matching `\usepackage` to the `prime.tex` heredoc in the Dockerfile, or that
template will fail in production while working locally.

### 6. Privileges

`cap_drop: [ALL]`, `no-new-privileges:true`, non-root UID 10001,
`pids_limit: 128`.

### 7. Log scrubbing

`friendly_log()` keeps only error lines and replaces anything matching a
filesystem path with `[path]`. Raw engine logs leak container structure and are
useless to non-technical users anyway.

## What is still missing

Honest gaps, to close before opening the LaTeX panel to the public:

- [ ] **gVisor or Firecracker.** Container isolation is not a security boundary
      against a kernel exploit. For untrusted user LaTeX at scale, use
      `runsc` (gVisor) or a microVM.
- [ ] **Per-user compile rate limits.** A compile loop is a trivial DoS. Limit
      in the web tier before the request reaches docsvc.
- [ ] **Warm container pool.** Currently a subprocess in a long-lived container.
      One container per compile is stronger and removes cross-compile state
      entirely.
- [ ] **Package allowlist enforcement.** The manifest declares `packages[]` but
      `assert_safe_tex` does not yet reject `\usepackage` of anything outside it.
- [ ] **Egress monitoring.** Alert if the compile network namespace ever emits
      a packet. It should be impossible; alert if the impossible happens.

## Never do these

- Never run docsvc on a host that also holds database credentials, API keys, or
  customer data. It is the blast-radius container.
- Never expose docsvc to the public internet. Only the Next.js server calls it.
- Never enable `--shell-escape`, for any template, for any reason.
- Never echo raw compile logs to the client.
- Never `pip install` or `apt-get` at runtime in the compile container.

## API key handling

`GEMINI_API_KEY` is a bearer credential with a spend limit attached.

- It lives only in `.env` / platform secrets, never in a committed file.
- It is never sent to docsvc — docsvc has no model access and needs none.
- It is never exposed to the browser. All model calls happen server-side.
- If it appears in a chat log, screenshot, support ticket, or git history,
  **rotate it**. Git history is forever; deleting the commit does not help.
