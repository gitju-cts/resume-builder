# Auth & ownership

## The rule

**Persist first. Authenticate second. Claim third.**

Everything in this document follows from that ordering, and the ordering exists
because of one concrete failure: an OAuth redirect navigates away from the page.
Any design that asks for an account *before* writing the resume loses the draft
for exactly the person most motivated to sign up.

```
   Build ──▶ Save ──▶ [resume exists, owned by anon session]
                          │
                          ├── person stops here → expires in 7 days
                          │
                          └── person signs in → ownership transfers
                                                 (one field update)
```

## Ownership is a pair, not an id

```ts
type Owner = { kind: "anon" | "user"; id: string };
```

Anonymous ownership is *real* ownership that happens to expire. It is not a
special case bolted onto the side. That symmetry is what makes the rest cheap:

- Save doesn't need an account, it needs an owner.
- Every write path asks one question and gets a usable answer either way.
- The claim is `updateMany({ownerKind:"anon", ownerId}, {$set:{ownerKind:"user", ownerId:userId}})`
  plus `$unset: {expiresAt}` — a field update, not a data migration.

If anonymous work lived in a separate collection or a separate shape, the claim
would be a copy operation, and copy operations fail halfway.

## Anonymous sessions

- A 32-byte random token goes in an `httpOnly`, `sameSite=lax` cookie.
- Only `sha256(token)` is stored. A database leak does not hand an attacker
  other people's drafts.
- TTL index on `expiresAt`, 7 days. A resume held without anyone having asked us
  to hold it must expire on its own.
- Cookie lifetime matches the DB TTL, and `ownerForWrite()` handles the case
  where the row expired under a still-valid cookie by minting a fresh session.

## The claim runs twice, on purpose

| Path | When | Why |
|---|---|---|
| `events.signIn` in `lib/auth.ts` | during the OAuth callback | no extra round trip, instant |
| `POST /api/resumes/claim` | client, on editor mount | the event runs inside a provider callback where `cookies()` access can fail depending on provider and redirect shape |

Both are idempotent. A failed claim that also blocked sign-in would leave someone
locked out of work they can see is theirs, so the event catches and logs rather
than throwing, and the client retry is the safety net.

## Providers, and one deliberate omission

- **Google** — one tap on a phone, and most students and early-career applicants
  already have an account.
- **Email link** — a meaningful share of this market does not have a Google
  account. OAuth-only would quietly exclude them.
- **Phone OTP** — the best fit for the cyber-café persona, and now wired end to
  end, **but the verifier accepts a fixed code**. See below.

Sign-in is optional at every level. With no provider configured the app still
works end to end — saving included — and `/signin` explains the situation
instead of showing a dead button.

## What sign-in is sold as

**Permanence, not access.** The resume is already saved by the time anyone sees
the prompt. Copy says so explicitly:

> Your resume is already saved. An account stops it expiring and lets you open it
> from another device.

"Sign in to save your work" would be false, and would make the anonymous path
feel like a trap once the person discovered the work was already safe.

## Version history

Append-only patch log. Each version stores the forward patch **and its inverse**.

- The inverse is computed server-side from the actual before/after pair, never
  accepted from the caller. In the prompt path the caller is a language model —
  the least trustworthy possible source for a patch that undo correctness
  depends on.
- Undo applies the stored inverse and is recorded as a *new* version. History is
  never rewritten, so the log reflects what actually happened, undos included.
  That matters for a document someone may be questioned about in an interview.
- A full snapshot is written every 20 versions to bound replay cost. Seq 0 always
  carries one, so there is always a base.
- `versions.list()` projects snapshots out — nobody scrolling history needs a
  megabyte of embedded documents.

## Rate limiting

Sliding window on Mongo, keyed by user → anon session → forwarded IP.

Redis is the right tool at scale and is in the infra list. This is deliberately
the boring version that works with infrastructure already present, because the
build path costs several model calls plus a compile, and shipping with *no* limit
is how a free tier becomes someone else's compute budget.

## Enforced by CI

`scripts/check-web.mjs` fails the build on:

- a DB-writing route that never resolves an owner server-side
- an owner id read from the request body (`body.ownerId`) — the classic
  authorisation hole
- an inverse patch accepted from a caller instead of computed
- a missing TTL index, which would make anonymous data permanent
- unhashed session tokens
- a missing claim path
- any credential exposed through `NEXT_PUBLIC_`

Each of those checks has been negative-tested — injected the fault, confirmed the
check fails, reverted. A check that has never failed is not known to work.


## Phone OTP is a static stub

`lib/auth-phone.ts` accepts a fixed code (default `123456`, override with
`STATIC_OTP_CODE`). **This is not authentication.** Anyone who knows the code can
sign in as any phone number.

The two-step flow (number, then code) is the real shape, so replacing the stub is
a backend change only — `PhoneSignIn.tsx` does not move. To go live: implement
SMS delivery, generate a random code, delete the static comparison.

### Three guards, because "we'll remember to remove it" is not a plan

1. **Refuses to load in production.** `staticOtpEnabled` returns false when
   `NODE_ENV === "production"` unless `ALLOW_STATIC_OTP_IN_PROD` is set to an
   exact magic string (not a boolean — nobody sets that by accident). Forgetting
   to remove the stub breaks the deploy loudly instead of opening the door
   quietly.
2. **Logs on every use**, with the phone number masked.
3. **CI enforces both.** `check-web.mjs` fails the build if the `NODE_ENV` gate,
   the override constant, or the logging is removed. That check has been
   fault-injected and confirmed to fail.

The UI is equally blunt: the code entry screen carries a warning naming the
accepted codes and stating this is not real authentication. An interface should
never imply a guarantee the system isn't providing.

## Rate limiting is off

`RATE_LIMIT_ENABLED` defaults to `false` for single-user operation. The limiter
code is intact — re-enabling is one variable, whereas rewriting it later is an
afternoon.

**Turn it on before the app is reachable by anyone else.** The build path costs
several model calls plus a LaTeX compile, so an open endpoint is a way for a
stranger to spend your API budget.
