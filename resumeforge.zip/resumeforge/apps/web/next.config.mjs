/** @type {import('next').NextConfig} */
export default {
  // Required by apps/web/Dockerfile: emits a self-contained server bundle so the
  // runtime image doesn't ship the whole node_modules tree.
  output: "standalone",
  experimental: {
    // Uploads can be a photographed bio-data straight off a phone camera.
    serverActions: { bodySizeLimit: "12mb" },
  },
};
