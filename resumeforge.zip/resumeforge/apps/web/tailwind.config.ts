import type { Config } from "tailwindcss";

/** Tokens live in globals.css as RGB triples so opacity modifiers work
 *  (`bg-stamp/10`). Colour names describe role, not hue. */
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        paper: {
          DEFAULT: "rgb(var(--paper) / <alpha-value>)",
          raised: "rgb(var(--paper-2) / <alpha-value>)",
          sunk: "rgb(var(--paper-sunk) / <alpha-value>)",
        },
        ink: {
          DEFAULT: "rgb(var(--ink) / <alpha-value>)",
          2: "rgb(var(--ink-2) / <alpha-value>)",
          3: "rgb(var(--ink-3) / <alpha-value>)",
        },
        rule: {
          DEFAULT: "rgb(var(--rule) / <alpha-value>)",
          strong: "rgb(var(--rule-strong) / <alpha-value>)",
        },
        stamp: "rgb(var(--stamp) / <alpha-value>)",
        pass: "rgb(var(--pass) / <alpha-value>)",
        ochre: "rgb(var(--ochre) / <alpha-value>)",
        flag: "rgb(var(--flag) / <alpha-value>)",
      },
      fontFamily: {
        display: ["var(--font-display)", "Georgia", "serif"],
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
        mono: ["ui-monospace", "SFMono-Regular", "Menlo", "monospace"],
      },
      fontSize: {
        "display-lg": ["clamp(2rem, 5.5vw, 3.25rem)", { lineHeight: "1.04", letterSpacing: "-0.022em" }],
        "display-sm": ["clamp(1.35rem, 3vw, 1.75rem)", { lineHeight: "1.15", letterSpacing: "-0.015em" }],
      },
      borderRadius: { sheet: "2px", well: "3px" },
      maxWidth: { shell: "76rem", prose: "34rem" },
    },
  },
  plugins: [],
};

export default config;
