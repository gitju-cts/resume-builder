"use client";

import { useEffect, useState } from "react";
import { Button, Notice, Panel } from "@/components/ui/primitives";
import type { AtsReport } from "@/lib/docsvc";
import type { Resume } from "@/lib/schema";

/**
 * Save-triggered auth.
 *
 * The sequence matters and is the reason this component exists rather than a
 * plain "Sign in to save" button:
 *
 *   1. Save writes the resume immediately, owned by an anonymous session.
 *   2. Only then do we mention accounts, and only to explain the expiry.
 *   3. Signing in transfers ownership. Nothing is re-uploaded, nothing in
 *      flight, nothing to lose.
 *
 * If we asked for an account first, the OAuth redirect would navigate away and
 * take the unsaved draft with it — so the person most motivated to sign in would
 * be the one who loses their work. Saving first makes the account genuinely
 * optional, which is also the honest framing: it buys permanence, not access.
 */

type SaveState =
  | { phase: "idle" }
  | { phase: "saving" }
  | { phase: "saved"; id: string; ownerKind: "anon" | "user"; expiresAt: string | null }
  | { phase: "error"; message: string };

export function SaveGate({
  resume,
  templateId,
  ats,
  signedIn,
  onSaved,
}: {
  resume: Resume;
  templateId: string;
  ats: AtsReport | null;
  signedIn: boolean;
  onSaved: (id: string) => void;
}) {
  const [state, setState] = useState<SaveState>({ phase: "idle" });

  // Retry the ownership transfer on mount. Cheap, idempotent, and covers the
  // case where the sign-in event couldn't read the cookie.
  useEffect(() => {
    if (!signedIn) return;
    fetch("/api/resumes/claim", { method: "POST" }).catch(() => {});
  }, [signedIn]);

  async function save() {
    setState({ phase: "saving" });
    try {
      const res = await fetch("/api/resumes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resume, templateId, ats }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Couldn't save that.");

      setState({
        phase: "saved",
        id: json.id,
        ownerKind: json.ownerKind,
        expiresAt: json.expiresAt,
      });
      onSaved(json.id);
    } catch (e) {
      setState({
        phase: "error",
        message: e instanceof Error ? e.message : "Couldn't save that.",
      });
    }
  }

  if (state.phase === "saved" && state.ownerKind === "anon") {
    return (
      <Panel className="p-3.5">
        <p className="text-[13px] font-semibold text-ink">Saved.</p>
        <p className="mt-1.5 text-[12.5px] leading-relaxed text-ink-2">
          It&apos;ll stay here for {daysUntil(state.expiresAt)}. Add an account
          and it stays for good — you&apos;ll also be able to open it from
          another device.
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          <Button size="sm" onClick={() => (window.location.href = "/signin")}>
            Keep it permanently
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => setState({ phase: "idle" })}
          >
            Not now
          </Button>
        </div>
        <p className="mt-2.5 text-[11.5px] leading-relaxed text-ink-3">
          Your resume is already saved. Signing in moves it to your account —
          nothing gets re-uploaded and nothing is lost.
        </p>
      </Panel>
    );
  }

  if (state.phase === "saved") {
    return (
      <Notice tone="info">
        Saved to your account. Changes from here on save automatically.
      </Notice>
    );
  }

  return (
    <div className="flex flex-col gap-2">
      <Button
        variant="secondary"
        onClick={save}
        disabled={state.phase === "saving"}
        className="w-full"
      >
        {state.phase === "saving" ? "Saving…" : "Save this resume"}
      </Button>
      {state.phase === "error" && <Notice tone="error">{state.message}</Notice>}
      {state.phase === "idle" && !signedIn && (
        <p className="text-[11.5px] leading-relaxed text-ink-3">
          No account needed to save. We&apos;ll ask about one afterwards.
        </p>
      )}
    </div>
  );
}

function daysUntil(iso: string | null): string {
  if (!iso) return "a week";
  const days = Math.max(
    1,
    Math.round((new Date(iso).getTime() - Date.now()) / 864e5)
  );
  return days === 1 ? "one more day" : `${days} days`;
}
