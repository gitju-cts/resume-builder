"use client";

import { useState } from "react";
import { Button, Notice, Textarea } from "@/components/ui/primitives";
import type { AtsReport } from "@/lib/docsvc";
import type { Resume } from "@/lib/schema";

/**
 * Prompt editing.
 *
 * The model returns a JSON Patch, not a rewritten document. This panel shows
 * the resulting diff and waits for approval before anything changes. That is
 * what makes an AI edit auditable: the person sees exactly which lines moved
 * before they move.
 *
 * It also means "undo" is free — rejecting is just not applying.
 */

type Pending = {
  patch: Array<{ op: string; path: string; value?: unknown }>;
  explanation: string;
  /** Kept so the accepted change can be labelled in version history. */
  instruction: string;
  resume: Resume;
  pdfB64: string;
  ats: AtsReport | null;
};

const SUGGESTIONS = [
  "Make it shorter — one page",
  "Put my projects above my education",
  "Make the wording simpler",
  "Focus more on my teamwork",
];

export function PromptPanel({
  resume,
  templateId,
  onApplied,
}: {
  resume: Resume;
  templateId: string;
  onApplied: (
    next: { resume: Resume; pdfB64: string; ats: AtsReport | null },
    /** The instruction that produced it, so history can label the entry. */
    prompt: string
  ) => void;
}) {
  const [instruction, setInstruction] = useState("");
  const [busy, setBusy] = useState(false);
  const [pending, setPending] = useState<Pending | null>(null);
  const [refusal, setRefusal] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);

  async function submit(text: string) {
    if (!text.trim() || busy) return;
    setBusy(true);
    setError(null);
    setRefusal(null);
    setDone(null);
    setPending(null);

    try {
      const res = await fetch("/api/patch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resume, instruction: text, templateId }),
      });
      const json = await res.json();

      if (!res.ok) throw new Error(json.error ?? "That edit didn't work.");

      if (json.refused) {
        setRefusal(json.reason);
        return;
      }
      if (json.noop) {
        setDone(json.explanation);
        return;
      }

      setPending({
        patch: json.patch,
        explanation: json.explanation,
        instruction: text,
        resume: json.resume,
        pdfB64: json.pdfB64,
        ats: json.ats,
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "That edit didn't work.");
    } finally {
      setBusy(false);
    }
  }

  function accept() {
    if (!pending) return;
    onApplied(
      {
        resume: pending.resume,
        pdfB64: pending.pdfB64,
        ats: pending.ats,
      },
      pending.instruction
    );
    setDone(pending.explanation);
    setPending(null);
    setInstruction("");
  }

  return (
    <div className="flex flex-col gap-4">
      <Textarea
        rows={3}
        value={instruction}
        onChange={(e) => setInstruction(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) submit(instruction);
        }}
        placeholder="Tell us what to change…"
        disabled={busy}
      />

      <Button onClick={() => submit(instruction)} disabled={busy || !instruction.trim()}>
        {busy ? "Working…" : "Suggest the change"}
      </Button>

      {!pending && !busy && (
        <div className="flex flex-wrap gap-1.5">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              onClick={() => {
                setInstruction(s);
                submit(s);
              }}
              className="rounded-well border border-rule px-2.5 py-1 text-[12px] text-ink-2 hover:border-rule-strong hover:bg-paper-sunk"
            >
              {s}
            </button>
          ))}
        </div>
      )}

      {error && <Notice tone="error">{error}</Notice>}

      {/* A refusal is a real answer, not a failure. It should read as helpful
          information, which is why it gets the warn tone rather than error. */}
      {refusal && <Notice tone="warn">{refusal}</Notice>}

      {done && <Notice tone="info">{done}</Notice>}

      {pending && (
        <div className="flex flex-col gap-3 rounded-sheet border border-stamp/35 bg-stamp/5 p-3.5">
          <p className="text-[13px] leading-relaxed text-ink">{pending.explanation}</p>

          <div>
            <h4 className="field-label mb-1.5">
              {pending.patch.length} change
              {pending.patch.length === 1 ? "" : "s"}
            </h4>
            <ul className="flex flex-col gap-1">
              {pending.patch.slice(0, 8).map((op, i) => (
                <li key={i} className="font-mono text-[11px] leading-snug text-ink-2">
                  <span className="text-stamp">{op.op}</span> {humanPath(op.path)}
                </li>
              ))}
              {pending.patch.length > 8 && (
                <li className="font-mono text-[11px] text-ink-3">
                  +{pending.patch.length - 8} more
                </li>
              )}
            </ul>
          </div>

          <div className="flex gap-2">
            <Button size="sm" onClick={accept}>
              Apply
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setPending(null)}>
              Discard
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

/** JSON Pointers are for machines. Nobody should have to read
 *  "/sections/1/items/0/bullets/2/text" to approve an edit. */
function humanPath(pointer: string): string {
  const parts = pointer.split("/").filter(Boolean);
  const out: string[] = [];

  for (let i = 0; i < parts.length; i++) {
    const p = parts[i]!;
    if (/^\d+$/.test(p)) {
      out.push(`#${Number(p) + 1}`);
      continue;
    }
    if (p === "-") {
      out.push("(new)");
      continue;
    }
    out.push(
      {
        sections: "section",
        items: "entry",
        bullets: "line",
        details: "line",
        groups: "group",
        basics: "your details",
        text: "wording",
        heading: "title",
      }[p] ?? p
    );
  }

  return out.join(" › ");
}
