"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import { AtsChip, AtsStamp } from "@/components/AtsStamp";
import { GapCards } from "@/components/GapCards";
import { PromptPanel } from "@/components/PromptPanel";
import { SaveGate } from "@/components/SaveGate";
import { SectionEditor } from "@/components/SectionEditor";
import { TemplateGallery } from "@/components/TemplateGallery";
import { VersionHistory } from "@/components/VersionHistory";
import { Button, Notice, Panel } from "@/components/ui/primitives";
import {
  getDraft,
  patchDraft,
  setDraft,
  pdfObjectUrl,
  subscribeDraft,
  type Draft,
} from "@/lib/draft";
import type { AtsReport } from "@/lib/docsvc";
import type { Resume } from "@/lib/schema";

/**
 * The editor.
 *
 * Three panes on desktop: what to change (left), the document (centre), whether
 * it will survive (right). On mobile it collapses to one pane with a switcher,
 * and the prompt panel is the default — for the least technical users, asking in
 * words is the only interface that works.
 *
 * Prompt mode is the default tab on every breakpoint. The form editor is there
 * for people who want it; LaTeX sits behind a deliberate door.
 */

type Mode = "prompt" | "form" | "design" | "latex";
type MobilePane = "edit" | "doc" | "score";

export function EditorClient() {
  const router = useRouter();
  const [draft, setDraftState] = useState<Draft | null>(() => getDraft());
  const [mode, setMode] = useState<Mode>("prompt");
  const [pane, setPane] = useState<MobilePane>("doc");
  const [downloading, setDownloading] = useState<string | null>(null);
  const [savedId, setSavedId] = useState<string | null>(null);
  const [seq, setSeq] = useState(0);
  const [signedIn, setSignedIn] = useState(false);

  const params = useSearchParams();
  const openId = params.get("id");

  useEffect(() => subscribeDraft(() => setDraftState(getDraft())), []);

  // Opened from the dashboard: pull the saved document and render it, so a
  // refresh-lost draft is recoverable once it has been saved.
  useEffect(() => {
    if (!openId || getDraft()) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`/api/resumes/${openId}`);
        if (!res.ok) return;
        const j = await res.json();
        if (cancelled) return;
        setDraft({
          resume: j.resume,
          jd: null,
          gaps: [],
          changeNotes: [],
          templateId: j.templateId,
          pdfB64: j.pdfB64 ?? "",
          ats: j.ats,
          meta: { detectedFormat: "saved", lowConfidence: [], notes: [], renderMs: 0 },
        });
        setSavedId(openId);
        setSeq(j.seq ?? 0);
      } catch {
        // Falls through to the "draft isn't here" screen, which offers a restart.
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [openId]);

  // Cheap session probe. The editor works identically either way — this only
  // decides whether to offer an account or mention the expiry.
  useEffect(() => {
    fetch("/api/resumes")
      .then((r) => r.json())
      .then((j) => setSignedIn(j.ownerKind === "user"))
      .catch(() => {});
  }, []);

  /** Once saved, edits are persisted as patches so history stays complete. */
  const persist = useCallback(
    async (resume: Resume, ats: AtsReport | null, authoredBy: "user" | "ai", prompt?: string) => {
      if (!savedId) return;
      try {
        const res = await fetch(`/api/resumes/${savedId}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ resume, ats, authoredBy, prompt }),
        });
        if (res.ok) setSeq((await res.json()).seq ?? seq);
      } catch {
        // A failed autosave must not interrupt editing. The draft in memory is
        // still correct and the next edit retries.
      }
    },
    [savedId, seq]
  );

  // Object URLs must be revoked or each edit leaks a few MB.
  const pdfUrl = useMemo(
    () => (draft?.pdfB64 ? pdfObjectUrl(draft.pdfB64) : null),
    [draft?.pdfB64]
  );
  useEffect(() => {
    return () => {
      if (pdfUrl) URL.revokeObjectURL(pdfUrl);
    };
  }, [pdfUrl]);

  if (!draft) {
    return (
      <main className="mx-auto flex min-h-dvh max-w-prose flex-col items-start justify-center gap-5 px-6">
        <h1 className="font-display text-display-sm font-bold">
          This draft isn&apos;t here any more.
        </h1>
        <p className="text-[15px] leading-relaxed text-ink-2">
          Resumes aren&apos;t saved until you have an account, so refreshing
          clears them. Start again and it&apos;ll take about a minute.
        </p>
        <Button onClick={() => router.push("/")}>Start again</Button>
      </main>
    );
  }

  async function download(format: "pdf" | "docx" | "tex") {
    setDownloading(format);
    try {
      const res = await fetch("/api/render", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          resume: draft!.resume,
          templateId: draft!.templateId,
          format,
        }),
      });
      if (!res.ok) throw new Error("Couldn't build that file.");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${draft!.resume.basics.name.replace(/\s+/g, "_")}_Resume.${format}`;
      a.click();
      URL.revokeObjectURL(url);
    } finally {
      setDownloading(null);
    }
  }

  const errors = draft.ats?.findings.filter((f) => f.severity === "error") ?? [];
  const warnings = draft.ats?.findings.filter((f) => f.severity === "warning") ?? [];
  const infos = draft.ats?.findings.filter((f) => f.severity === "info") ?? [];

  return (
    <main className="flex min-h-dvh flex-col">
      {/* ------------------------------------------------------------ topbar */}
      <header className="flex flex-wrap items-center gap-x-5 gap-y-2 border-b border-rule px-4 py-3 sm:px-6">
        <button
          onClick={() => router.push("/")}
          className="font-display text-[16px] font-bold tracking-tight hover:text-ink-2"
        >
          ResumeForge
        </button>

        <span className="hidden h-4 w-px bg-rule sm:block" aria-hidden />

        <span className="min-w-0 truncate text-[13.5px] text-ink-2">
          {draft.resume.basics.name}
          {draft.jd?.title && (
            <span className="text-ink-3"> → {draft.jd.title}</span>
          )}
        </span>

        <div className="ml-auto flex items-center gap-3">
          {draft.ats && (
            <div className="hidden sm:block">
              <AtsChip report={draft.ats} />
            </div>
          )}
          <div className="flex gap-2">
            <Button
              size="sm"
              onClick={() => download("pdf")}
              disabled={downloading !== null}
            >
              {downloading === "pdf" ? "Building…" : "PDF"}
            </Button>
            <Button
              size="sm"
              variant="secondary"
              onClick={() => download("docx")}
              disabled={downloading !== null}
            >
              {downloading === "docx" ? "Building…" : "Word"}
            </Button>
          </div>
        </div>
      </header>

      {/* Mobile pane switcher */}
      <nav className="flex border-b border-rule lg:hidden" role="tablist">
        {(
          [
            ["edit", "Edit"],
            ["doc", "Resume"],
            ["score", draft.ats ? `Score ${draft.ats.score}` : "Score"],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            role="tab"
            aria-selected={pane === key}
            onClick={() => setPane(key)}
            className={`flex-1 border-b-2 py-2.5 text-[13px] font-semibold ${
              pane === key
                ? "border-ink text-ink"
                : "border-transparent text-ink-3"
            }`}
          >
            {label}
          </button>
        ))}
      </nav>

      <div className="grid flex-1 lg:grid-cols-[minmax(300px,360px)_1fr_minmax(280px,320px)]">
        {/* ------------------------------------------------------- edit pane */}
        <section
          className={`panel-scroll overflow-y-auto border-rule lg:block lg:border-r ${
            pane === "edit" ? "block" : "hidden"
          }`}
        >
          <div className="flex border-b border-rule" role="tablist">
            {(
              [
                ["prompt", "Ask"],
                ["form", "Sections"],
                ["design", "Design"],
                ["latex", "LaTeX"],
              ] as const
            ).map(([key, label]) => (
              <button
                key={key}
                role="tab"
                aria-selected={mode === key}
                onClick={() => setMode(key)}
                className={`flex-1 border-b-2 px-3 py-2.5 text-[13px] font-semibold transition-colors ${
                  mode === key
                    ? "border-ink text-ink"
                    : "border-transparent text-ink-3 hover:text-ink-2"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="p-4">
            {mode === "prompt" && (
              <PromptPanel
                resume={draft.resume}
                templateId={draft.templateId}
                onApplied={(next, prompt) => {
                  patchDraft({
                    resume: next.resume,
                    pdfB64: next.pdfB64,
                    ats: next.ats,
                  });
                  void persist(next.resume, next.ats, "ai", prompt);
                }}
              />
            )}

            {mode === "form" && (
              <SectionEditor
                resume={draft.resume}
                templateId={draft.templateId}
                lowConfidence={draft.meta.lowConfidence}
                onChange={(next) => {
                  patchDraft({
                    resume: next.resume,
                    pdfB64: next.pdfB64,
                    ats: next.ats,
                  });
                  void persist(next.resume, next.ats, "user");
                }}
              />
            )}

            {mode === "design" && (
              <TemplateGallery
                resume={draft.resume}
                currentTemplateId={draft.templateId}
                onSwitched={(next) => {
                  patchDraft({
                    templateId: next.templateId,
                    pdfB64: next.pdfB64,
                    ats: next.ats,
                  });
                  if (savedId) {
                    void fetch(`/api/resumes/${savedId}`, {
                      method: "PATCH",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({
                        resume: draft.resume,
                        templateId: next.templateId,
                        ats: next.ats,
                        note: `Switched design to ${next.templateId}`,
                      }),
                    });
                  }
                }}
              />
            )}

            {mode === "latex" && <LatexDoor />}
          </div>
        </section>

        {/* -------------------------------------------------------- document */}
        <section
          className={`form-grid min-h-[60vh] p-4 sm:p-7 lg:block ${
            pane === "doc" ? "block" : "hidden"
          }`}
        >
          {pdfUrl ? (
            <div className="sheet relative mx-auto max-w-[720px]">
              <iframe
                src={`${pdfUrl}#toolbar=0&navpanes=0&view=FitH`}
                title="Your resume"
                className="h-[calc(100dvh-13rem)] w-full"
              />
              {/* The stamp lands on the corner of the page, the way an approval
                  mark would. This is the signature moment of the interface. */}
              {draft.ats && (
                <div className="pointer-events-none absolute -right-4 -top-4 hidden sm:block">
                  <AtsStamp report={draft.ats} size={112} />
                </div>
              )}
            </div>
          ) : (
            <Notice tone="warn">
              The preview didn&apos;t build. Your text is safe — try an edit to
              rebuild it.
            </Notice>
          )}
        </section>

        {/* ----------------------------------------------------------- score */}
        <aside
          className={`panel-scroll overflow-y-auto border-rule p-4 lg:block lg:border-l ${
            pane === "score" ? "block" : "hidden"
          }`}
        >
          {draft.ats && (
            <div className="mb-6 flex justify-center py-2">
              <AtsStamp report={draft.ats} size={124} />
            </div>
          )}

          {draft.ats && (
            <p className="mb-5 text-[12.5px] leading-relaxed text-ink-2">
              We rebuilt your resume, then read it back with a different parser —
              the way an employer&apos;s system would.{" "}
              <span className="font-mono">
                {Math.round(draft.ats.fieldRecovery * 100)}%
              </span>{" "}
              of your details survived that.
            </p>
          )}

          {errors.length > 0 && (
            <FindingGroup
              title="Fix these"
              tone="error"
              items={errors.map((f) => f.message)}
            />
          )}
          {warnings.length > 0 && (
            <FindingGroup
              title="Worth checking"
              tone="warn"
              items={warnings.map((f) => f.message)}
            />
          )}
          {infos.length > 0 && (
            <FindingGroup
              title="Good to know"
              tone="info"
              items={infos.map((f) => f.message)}
            />
          )}

          {errors.length === 0 && warnings.length === 0 && (
            <Panel className="p-3.5">
              <p className="text-[13px] leading-relaxed text-ink-2">
                Nothing to fix. Every detail we put in came back out when we
                re-read the file.
              </p>
            </Panel>
          )}

          {draft.gaps.length > 0 && (
            <div className="mt-6">
              <GapCards gaps={draft.gaps} />
            </div>
          )}

          {draft.changeNotes.length > 0 && (
            <div className="mt-6">
              <h3 className="field-label mb-2.5">What we changed</h3>
              <ul className="flex flex-col gap-1.5">
                {draft.changeNotes.map((n, i) => (
                  <li
                    key={i}
                    className="border-l-2 border-rule pl-2.5 text-[12.5px] leading-snug text-ink-2"
                  >
                    {n}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="mt-6 border-t border-rule pt-4">
            <SaveGate
              resume={draft.resume}
              templateId={draft.templateId}
              ats={draft.ats}
              signedIn={signedIn}
              onSaved={setSavedId}
            />
          </div>

          {savedId && (
            <div className="mt-6 border-t border-rule pt-4">
              <h3 className="field-label mb-2.5">History</h3>
              <VersionHistory
                resumeId={savedId}
                seq={seq}
                onReverted={(next) => {
                  patchDraft({
                    resume: next.resume,
                    ats: next.ats,
                    ...(next.pdfB64 ? { pdfB64: next.pdfB64 } : {}),
                  });
                }}
              />
            </div>
          )}

          <p className="mt-6 border-t border-rule pt-3.5 text-[11.5px] leading-relaxed text-ink-3">
            The Word file is deliberately plainer than the PDF. It&apos;s built to
            be read by software and edited by you, not to look identical.
          </p>
        </aside>
      </div>
    </main>
  );
}

function FindingGroup({
  title,
  tone,
  items,
}: {
  title: string;
  tone: "error" | "warn" | "info";
  items: string[];
}) {
  const color =
    tone === "error" ? "text-flag" : tone === "warn" ? "text-ochre" : "text-ink-3";
  return (
    <div className="mb-5">
      <h3 className={`field-label mb-2 ${color}`}>
        {title} · {items.length}
      </h3>
      <ul className="flex flex-col gap-2">
        {items.map((m, i) => (
          <li key={i} className="text-[12.5px] leading-relaxed text-ink-2">
            {m}
          </li>
        ))}
      </ul>
    </div>
  );
}

/**
 * The LaTeX door.
 *
 * Ejecting to LaTeX is one-way: once the source is hand-edited we cannot
 * reliably parse it back into the structured document, so the form and prompt
 * editors would be operating on stale data. Rather than pretend to sync, we say
 * so plainly and offer a duplicate — which removes almost all of the pain.
 */
function LatexDoor() {
  return (
    <div className="flex flex-col gap-4">
      <Notice tone="warn">
        Taking over the LaTeX gives you complete control of the layout. After
        that, the <strong>Ask</strong> and <strong>Sections</strong> editors
        can&apos;t be used on this resume — we can&apos;t read your hand-written
        layout back into fields.
      </Notice>
      <p className="text-[13px] leading-relaxed text-ink-2">
        Most people don&apos;t need this. It&apos;s here for engineers who want
        to control spacing and typography directly.
      </p>
      <div className="flex flex-col gap-2">
        <Button variant="secondary" disabled>
          Duplicate, then edit LaTeX
        </Button>
        <Button variant="secondary" disabled>
          Edit LaTeX on this resume
        </Button>
      </div>
      <p className="font-mono text-[11px] text-ink-3">
        Editor lands next — the compile endpoint and eject flow are already
        built.
      </p>
    </div>
  );
}
