"use client";

import { useCallback, useEffect, useState } from "react";
import { Button, Notice } from "@/components/ui/primitives";
import type { AtsReport } from "@/lib/docsvc";
import type { Resume } from "@/lib/schema";

/**
 * Version history, read from the append-only patch log.
 *
 * Undo applies a stored inverse patch and is itself recorded as a new version.
 * History is never rewritten, which means the log always reflects what actually
 * happened — including the undos. That's the right trade for a document someone
 * may need to account for in an interview.
 */

type Entry = {
  seq: number;
  authoredBy: "user" | "ai";
  prompt: string | null;
  note: string | null;
  changeCount: number;
  createdAt: string;
  undoable: boolean;
};

export function VersionHistory({
  resumeId,
  seq,
  onReverted,
}: {
  resumeId: string;
  seq: number;
  onReverted: (next: {
    resume: Resume;
    pdfB64: string | null;
    ats: AtsReport | null;
  }) => void;
}) {
  const [entries, setEntries] = useState<Entry[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch(`/api/resumes/${resumeId}/history`);
      if (!res.ok) return;
      const json = await res.json();
      setEntries(json.versions ?? []);
    } catch {
      // History is supplementary — a failure here must not break the editor.
    }
  }, [resumeId]);

  useEffect(() => {
    void load();
  }, [load, seq]);

  async function undo(targetSeq: number) {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/resumes/${resumeId}/history`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ seq: targetSeq }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Couldn't undo that.");

      onReverted({ resume: json.resume, pdfB64: json.pdfB64, ats: json.ats });
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Couldn't undo that.");
    } finally {
      setBusy(false);
    }
  }

  if (!entries) return null;

  if (entries.length <= 1) {
    return (
      <p className="text-[12px] leading-relaxed text-ink-3">
        No changes yet. Every edit from here is recorded, and you can step back
        through them.
      </p>
    );
  }

  return (
    <div className="flex flex-col gap-2.5">
      {error && <Notice tone="error">{error}</Notice>}

      <ol className="flex flex-col">
        {entries.map((e, i) => (
          <li
            key={e.seq}
            className={`flex items-start gap-2.5 border-l-2 py-2 pl-3 ${
              i === 0 ? "border-stamp" : "border-rule"
            }`}
          >
            <span className="mt-0.5 font-mono text-[10px] text-ink-3">
              {String(e.seq).padStart(2, "0")}
            </span>

            <div className="min-w-0 flex-1">
              <p className="text-[12.5px] leading-snug text-ink">
                {describe(e)}
              </p>
              <p className="mt-0.5 font-mono text-[10.5px] text-ink-3">
                {e.authoredBy === "ai" ? "asked" : "edited"} ·{" "}
                {e.changeCount > 0
                  ? `${e.changeCount} change${e.changeCount === 1 ? "" : "s"}`
                  : "original"}{" "}
                · {relativeTime(e.createdAt)}
              </p>
            </div>

            {e.undoable && (
              <Button
                size="sm"
                variant="ghost"
                disabled={busy}
                onClick={() => undo(e.seq)}
              >
                Undo
              </Button>
            )}
          </li>
        ))}
      </ol>

      <p className="text-[11px] leading-relaxed text-ink-3">
        Undoing adds a new step rather than erasing one, so the record stays
        complete.
      </p>
    </div>
  );
}

function describe(e: Entry): string {
  if (e.note) return e.note;
  if (e.prompt) return `"${e.prompt}"`;
  return e.authoredBy === "ai" ? "Reworded by us" : "Edited by hand";
}

function relativeTime(iso: string): string {
  const seconds = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}
