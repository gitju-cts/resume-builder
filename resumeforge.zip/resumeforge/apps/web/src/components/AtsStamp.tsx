"use client";

import type { AtsReport } from "@/lib/docsvc";

/**
 * The ATS score, as a rubber approval stamp.
 *
 * This is the one place the interface raises its voice. The product's entire
 * premise is that a resume has to clear an automated gate, and a stamp is what
 * that world uses to say cleared or not cleared. It also does real work: a
 * number in a stamp is read as a verdict, which is what it is, whereas the same
 * number in a progress bar reads as a game score to improve.
 *
 * Grade caps the colour, not the score — an error-level finding means the
 * document loses information, and no amount of points elsewhere makes that fine.
 */

const GRADE_COPY: Record<string, { verdict: string; tone: string }> = {
  A: { verdict: "Safe to send", tone: "text-pass" },
  B: { verdict: "Minor risk", tone: "text-ochre" },
  C: { verdict: "Check warnings", tone: "text-flag" },
  F: { verdict: "Do not send", tone: "text-flag" },
};

function gradeColorVar(grade: string): string {
  if (grade === "A") return "var(--pass)";
  if (grade === "B") return "var(--ochre)";
  return "var(--flag)";
}

export function AtsStamp({
  report,
  size = 132,
  animate = true,
}: {
  report: AtsReport;
  size?: number;
  animate?: boolean;
}) {
  const copy = GRADE_COPY[report.grade] ?? GRADE_COPY.F;
  const rgb = gradeColorVar(report.grade);

  return (
    <div
      className={animate ? "stamp-impress" : ""}
      style={{ transform: "rotate(-3.5deg)" }}
      role="img"
      aria-label={`Applicant tracking score ${report.score} out of 100, grade ${report.grade}. ${copy.verdict}.`}
    >
      <svg width={size} height={size} viewBox="0 0 132 132" aria-hidden="true">
        <g stroke={`rgb(${rgb})`} fill="none">
          {/* Double ring, the outer one dashed — rubber stamps ink unevenly and
              the dash reads as that without faking texture. */}
          <circle cx="66" cy="66" r="62" strokeWidth="2.5" strokeDasharray="5 3.5" opacity="0.85" />
          <circle cx="66" cy="66" r="53" strokeWidth="1.25" opacity="0.6" />
        </g>

        {/* Curved caption, top */}
        <defs>
          <path id="stamp-arc-top" d="M 66 66 m -42 0 a 42 42 0 0 1 84 0" fill="none" />
          <path id="stamp-arc-bottom" d="M 66 66 m -40 0 a 40 40 0 0 0 80 0" fill="none" />
        </defs>

        <text
          fill={`rgb(${rgb})`}
          fontSize="9"
          fontWeight="700"
          letterSpacing="2.4"
          style={{ fontFamily: "var(--font-sans)" }}
        >
          <textPath href="#stamp-arc-top" startOffset="50%" textAnchor="middle">
            ATS SCREENING
          </textPath>
        </text>

        <text
          fill={`rgb(${rgb})`}
          fontSize="7.5"
          fontWeight="600"
          letterSpacing="1.6"
          opacity="0.8"
          style={{ fontFamily: "var(--font-sans)" }}
        >
          <textPath href="#stamp-arc-bottom" startOffset="50%" textAnchor="middle">
            {copy.verdict.toUpperCase()}
          </textPath>
        </text>

        {/* The verdict itself */}
        <text
          x="66"
          y="62"
          textAnchor="middle"
          fill={`rgb(${rgb})`}
          fontSize="40"
          fontWeight="800"
          letterSpacing="-1"
          style={{ fontFamily: "var(--font-sans)" }}
        >
          {report.score}
        </text>
        <line x1="40" y1="72" x2="92" y2="72" stroke={`rgb(${rgb})`} strokeWidth="1.25" opacity="0.5" />
        <text
          x="66"
          y="87"
          textAnchor="middle"
          fill={`rgb(${rgb})`}
          fontSize="12"
          fontWeight="700"
          letterSpacing="1.5"
          style={{ fontFamily: "var(--font-sans)" }}
        >
          GRADE {report.grade}
        </text>
      </svg>
    </div>
  );
}

/** Compact inline form for headers and template cards, where a full stamp
 *  would be shouting. */
export function AtsChip({ report }: { report: AtsReport }) {
  const copy = GRADE_COPY[report.grade] ?? GRADE_COPY.F;
  const errors = report.findings.filter((f) => f.severity === "error").length;
  const warnings = report.findings.filter((f) => f.severity === "warning").length;

  return (
    <div className="flex items-center gap-2.5">
      <span
        className={`font-mono text-sm font-bold tabular-nums ${copy.tone}`}
        aria-label={`Score ${report.score} of 100`}
      >
        {report.score}
      </span>
      <span className="h-3.5 w-px bg-rule" aria-hidden />
      <span className={`field-label ${copy.tone}`}>{copy.verdict}</span>
      {(errors > 0 || warnings > 0) && (
        <span className="font-mono text-[11px] text-ink-3">
          {errors > 0 && `${errors}e`}
          {errors > 0 && warnings > 0 && " "}
          {warnings > 0 && `${warnings}w`}
        </span>
      )}
    </div>
  );
}
