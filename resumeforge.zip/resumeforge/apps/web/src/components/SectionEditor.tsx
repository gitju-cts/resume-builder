"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Button, Field, Input, Panel, Textarea } from "@/components/ui/primitives";
import type { AtsReport } from "@/lib/docsvc";
import type { Resume } from "@/lib/schema";

/**
 * Section form editor.
 *
 * Edits mutate the canonical document directly and trigger a debounced
 * re-render. No AI involved, so nothing needs approving — this is the pane for
 * people who know exactly what they want to say.
 *
 * Fields the extraction model was unsure about are flagged inline. That is the
 * whole reason we carry `lowConfidence` through from ingestion: showing a
 * mostly-correct resume with three fields marked "check this" converts far
 * better than blocking on a form, and it's honest about what we guessed.
 */

const RENDER_DEBOUNCE_MS = 700;

export function SectionEditor({
  resume,
  templateId,
  lowConfidence,
  onChange,
}: {
  resume: Resume;
  templateId: string;
  lowConfidence: string[];
  onChange: (next: { resume: Resume; pdfB64: string; ats: AtsReport | null }) => void;
}) {
  const [local, setLocal] = useState<Resume>(resume);
  const [rendering, setRendering] = useState(false);
  const [open, setOpen] = useState<string>("basics");
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const latest = useRef(local);

  // Accept upstream changes (a prompt edit landed) without clobbering typing.
  useEffect(() => {
    setLocal(resume);
    latest.current = resume;
  }, [resume]);

  const scheduleRender = useCallback(
    (next: Resume) => {
      latest.current = next;
      if (timer.current) clearTimeout(timer.current);
      timer.current = setTimeout(async () => {
        setRendering(true);
        try {
          const res = await fetch("/api/render/preview", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ resume: latest.current, templateId }),
          });
          if (res.ok) {
            const json = await res.json();
            onChange({
              resume: latest.current,
              pdfB64: json.pdfB64,
              ats: json.ats,
            });
          }
        } finally {
          setRendering(false);
        }
      }, RENDER_DEBOUNCE_MS);
    },
    [templateId, onChange]
  );

  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    []
  );

  function update(mutate: (draft: Resume) => void) {
    const next = structuredClone(local);
    mutate(next);
    setLocal(next);
    scheduleRender(next);
  }

  const flagged = (path: string) => lowConfidence.includes(path);

  return (
    <div className="flex flex-col gap-3">
      {rendering && (
        <p className="font-mono text-[11px] text-ink-3">Rebuilding the page…</p>
      )}

      {/* ------------------------------------------------------------ basics */}
      <Accordion
        id="basics"
        title="Your details"
        open={open === "basics"}
        onToggle={setOpen}
      >
        <div className="flex flex-col gap-3.5">
          <Field label="Full name" htmlFor="f-name">
            <Input
              id="f-name"
              value={local.basics.name}
              onChange={(e) =>
                update((d) => {
                  d.basics.name = e.target.value;
                })
              }
            />
          </Field>

          <Field
            label="Job title"
            optional
            hint="One line, e.g. Backend Engineer. Not a summary."
            htmlFor="f-headline"
          >
            <Input
              id="f-headline"
              value={local.basics.headline ?? ""}
              onChange={(e) =>
                update((d) => {
                  d.basics.headline = e.target.value;
                })
              }
            />
          </Field>

          <div className="grid gap-3.5 sm:grid-cols-2">
            <Field
              label="Email"
              htmlFor="f-email"
              hint={flagged("basics.email") ? "We guessed this — please check." : undefined}
            >
              <Input
                id="f-email"
                type="email"
                value={local.basics.email ?? ""}
                className={flagged("basics.email") ? "border-ochre" : undefined}
                onChange={(e) =>
                  update((d) => {
                    d.basics.email = e.target.value;
                  })
                }
              />
            </Field>

            <Field
              label="Phone"
              htmlFor="f-phone"
              hint={flagged("basics.phone") ? "We guessed this — please check." : undefined}
            >
              <Input
                id="f-phone"
                value={local.basics.phone ?? ""}
                className={flagged("basics.phone") ? "border-ochre" : undefined}
                onChange={(e) =>
                  update((d) => {
                    d.basics.phone = e.target.value;
                  })
                }
              />
            </Field>
          </div>

          <Field label="City" optional htmlFor="f-loc" hint="City and state is enough.">
            <Input
              id="f-loc"
              value={local.basics.location ?? ""}
              onChange={(e) =>
                update((d) => {
                  d.basics.location = e.target.value;
                })
              }
            />
          </Field>
        </div>
      </Accordion>

      {/* ----------------------------------------------------------- summary */}
      <Accordion
        id="summary"
        title="Summary"
        open={open === "summary"}
        onToggle={setOpen}
      >
        <Field label="Summary" optional hint="Two or three lines. Skip it if unsure.">
          <Textarea
            rows={4}
            value={local.summary?.text ?? ""}
            onChange={(e) =>
              update((d) => {
                d.summary = { text: e.target.value, origin: "user" };
              })
            }
          />
        </Field>
      </Accordion>

      {/* ---------------------------------------------------------- sections */}
      {local.sections.map((section, si) => (
        <Accordion
          key={section.id}
          id={section.id}
          title={section.heading}
          badge={
            section.kind === "skills"
              ? `${section.groups.length} group${section.groups.length === 1 ? "" : "s"}`
              : `${section.items.length} entr${section.items.length === 1 ? "y" : "ies"}`
          }
          open={open === section.id}
          onToggle={setOpen}
        >
          {section.kind === "skills" ? (
            <div className="flex flex-col gap-3.5">
              {section.groups.map((group, gi) => (
                <Field
                  key={gi}
                  label={group.label}
                  hint="Separate with commas. Plain lines like this parse best."
                >
                  <Textarea
                    rows={2}
                    value={group.items.join(", ")}
                    onChange={(e) =>
                      update((d) => {
                        const s = d.sections[si];
                        if (s?.kind === "skills" && s.groups[gi]) {
                          s.groups[gi]!.items = e.target.value
                            .split(",")
                            .map((x) => x.trim())
                            .filter(Boolean);
                        }
                      })
                    }
                  />
                </Field>
              ))}
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              {section.items.map((item, ii) => (
                <Panel key={item.id} className="p-3">
                  <p className="mb-2.5 text-[13px] font-semibold">
                    {"role" in item
                      ? item.role
                      : "degree" in item
                        ? item.degree
                        : item.title}
                  </p>

                  {"bullets" in item && (
                    <div className="flex flex-col gap-2">
                      {item.bullets.map((bullet, bi) => (
                        <div key={bullet.id} className="flex flex-col gap-1">
                          <Textarea
                            rows={2}
                            value={bullet.text}
                            className="text-[13.5px]"
                            onChange={(e) =>
                              update((d) => {
                                const s = d.sections[si];
                                if (!s || s.kind === "skills") return;
                                const it = s.items[ii];
                                const bl = (it as { bullets?: Array<{ text: string; origin: string }> })
                                  .bullets?.[bi];
                                if (bl) {
                                  bl.text = e.target.value;
                                  // A human edit takes ownership of the line, so
                                  // it stops being an AI suggestion.
                                  bl.origin = "user";
                                }
                              })
                            }
                          />
                          {bullet.origin === "ai-rewritten" && (
                            <p className="font-mono text-[10.5px] text-stamp">
                              reworded by us — edit to make it yours
                            </p>
                          )}
                        </div>
                      ))}

                      <Button
                        variant="ghost"
                        size="sm"
                        className="self-start"
                        onClick={() =>
                          update((d) => {
                            const s = d.sections[si];
                            if (!s || s.kind === "skills") return;
                            const it = s.items[ii] as {
                              bullets?: Array<{ id: string; text: string; origin: string }>;
                            };
                            it.bullets ??= [];
                            it.bullets.push({
                              id: `b-${Date.now().toString(36)}`,
                              text: "",
                              origin: "user",
                            });
                          })
                        }
                      >
                        + Add a line
                      </Button>
                    </div>
                  )}
                </Panel>
              ))}
            </div>
          )}
        </Accordion>
      ))}

      <p className="mt-1 text-[11.5px] leading-relaxed text-ink-3">
        Reordering by drag lands next. For now, ask in the Ask tab — &ldquo;put
        projects above education&rdquo; works.
      </p>
    </div>
  );
}

function Accordion({
  id,
  title,
  badge,
  open,
  onToggle,
  children,
}: {
  id: string;
  title: string;
  badge?: string;
  open: boolean;
  onToggle: (id: string) => void;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-sheet border border-rule">
      <button
        onClick={() => onToggle(open ? "" : id)}
        aria-expanded={open}
        className="flex w-full items-center justify-between gap-2 px-3.5 py-2.5 text-left hover:bg-paper-sunk"
      >
        <span className="text-[13.5px] font-semibold">{title}</span>
        <span className="flex items-center gap-2.5">
          {badge && <span className="font-mono text-[10.5px] text-ink-3">{badge}</span>}
          <span aria-hidden className="text-ink-3">
            {open ? "−" : "+"}
          </span>
        </span>
      </button>
      {open && <div className="border-t border-rule p-3.5">{children}</div>}
    </div>
  );
}
