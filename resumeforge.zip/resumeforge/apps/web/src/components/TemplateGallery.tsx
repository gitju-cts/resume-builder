"use client";

import { useEffect, useState } from "react";
import { Button, Notice, Panel } from "@/components/ui/primitives";
import type { AtsReport, TemplateManifest } from "@/lib/docsvc";
import type { Resume } from "@/lib/schema";

/**
 * Template gallery.
 *
 * Grades are shown, not hidden. Every competitor labels all of its templates
 * "ATS-friendly"; that claim breaks the first time someone's two-column resume
 * arrives at an employer with the columns interleaved. Showing a grade is less
 * flattering and considerably more useful — and it's honest, because the grade
 * comes from actually re-reading the rendered PDF.
 *
 * Grade A templates are listed first and pre-selected. Someone who wants the
 * prettier layout can have it; they just won't get it by accident.
 */

const GRADE_COPY: Record<string, { label: string; tone: string; note: string }> = {
  A: {
    label: "Safest",
    tone: "text-pass",
    note: "Single column, plain structure. Parses reliably everywhere.",
  },
  B: {
    label: "Some risk",
    tone: "text-ochre",
    note: "Check the score after switching — older systems can mis-read this.",
  },
  C: {
    label: "Higher risk",
    tone: "text-flag",
    note: "Only worth it if a human is definitely reading first.",
  },
};

export function TemplateGallery({
  resume,
  currentTemplateId,
  onSwitched,
}: {
  resume: Resume;
  currentTemplateId: string;
  onSwitched: (next: {
    templateId: string;
    pdfB64: string;
    ats: AtsReport | null;
  }) => void;
}) {
  const [templates, setTemplates] = useState<TemplateManifest[] | null>(null);
  const [switching, setSwitching] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/templates")
      .then((r) => r.json())
      .then((j) => setTemplates(j.templates ?? []))
      .catch(() => setTemplates([]));
  }, []);

  async function pick(id: string) {
    if (id === currentTemplateId) return;
    setSwitching(id);
    setError(null);
    try {
      const res = await fetch("/api/render/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resume, templateId: id }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "That design didn't build.");
      onSwitched({ templateId: id, pdfB64: json.pdfB64, ats: json.ats });
    } catch (e) {
      setError(e instanceof Error ? e.message : "That design didn't build.");
    } finally {
      setSwitching(null);
    }
  }

  if (!templates) {
    return <p className="font-mono text-[11px] text-ink-3">Loading designs…</p>;
  }

  if (!templates.length) {
    return (
      <Notice tone="warn">
        No designs loaded. The document service may not be running — check{" "}
        <span className="font-mono">docker compose ps</span>.
      </Notice>
    );
  }

  // Safe first. Within a grade, keep the order the service returned.
  const ordered = [...templates].sort(
    (a, b) => gradeRank(a.atsGrade) - gradeRank(b.atsGrade)
  );

  const suggested = ordered.filter((t) =>
    t.situations?.includes(resume.meta?.situation ?? "standard")
  );
  const rest = ordered.filter((t) => !suggested.includes(t));

  return (
    <div className="flex flex-col gap-4">
      {error && <Notice tone="error">{error}</Notice>}

      {suggested.length > 0 && (
        <Group
          title={`Suited to your situation`}
          templates={suggested}
          currentId={currentTemplateId}
          switching={switching}
          onPick={pick}
        />
      )}

      {rest.length > 0 && (
        <Group
          title="Everything else"
          templates={rest}
          currentId={currentTemplateId}
          switching={switching}
          onPick={pick}
        />
      )}

      <p className="text-[11.5px] leading-relaxed text-ink-3">
        Grades come from re-reading the built PDF with a separate parser, not from
        how the design looks. Switching keeps all your text — only the layout
        changes.
      </p>
    </div>
  );
}

function Group({
  title,
  templates,
  currentId,
  switching,
  onPick,
}: {
  title: string;
  templates: TemplateManifest[];
  currentId: string;
  switching: string | null;
  onPick: (id: string) => void;
}) {
  return (
    <div>
      <h4 className="field-label mb-2">{title}</h4>
      <div className="flex flex-col gap-2">
        {templates.map((t) => {
          const grade = GRADE_COPY[t.atsGrade] ?? GRADE_COPY.C;
          const active = t.id === currentId;
          return (
            <Panel
              key={t.id}
              className={`p-3 ${active ? "border-stamp bg-stamp/5" : ""}`}
            >
              <div className="flex items-baseline justify-between gap-2">
                <p className="text-[13px] font-semibold text-ink">{t.name}</p>
                <span className={`shrink-0 font-mono text-[10px] uppercase tracking-wide ${grade.tone}`}>
                  {grade.label}
                </span>
              </div>

              <p className="mt-1 text-[12px] leading-relaxed text-ink-2">
                {t.blurb}
              </p>

              <p className="mt-1.5 font-mono text-[10.5px] text-ink-3">
                {t.layout.columns === 1 ? "one column" : `${t.layout.columns} columns`}
                {" · "}
                {t.maxPagesRecommended > 2
                  ? "no page limit"
                  : `${t.maxPagesRecommended} page${t.maxPagesRecommended === 1 ? "" : "s"}`}
              </p>

              {t.atsGrade !== "A" && (
                <p className={`mt-1.5 text-[11.5px] leading-snug ${grade.tone}`}>
                  {grade.note}
                </p>
              )}

              <div className="mt-2.5">
                {active ? (
                  <span className="font-mono text-[10.5px] text-stamp">in use</span>
                ) : (
                  <Button
                    size="sm"
                    variant="secondary"
                    disabled={switching !== null}
                    onClick={() => onPick(t.id)}
                  >
                    {switching === t.id ? "Building…" : "Use this"}
                  </Button>
                )}
              </div>
            </Panel>
          );
        })}
      </div>
    </div>
  );
}

function gradeRank(g: string): number {
  return { A: 0, B: 1, C: 2, F: 3 }[g] ?? 9;
}
