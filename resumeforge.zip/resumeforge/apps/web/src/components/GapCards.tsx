"use client";

import type { GapCard } from "@/lib/schema";

/**
 * Gap cards.
 *
 * This component is the visible half of the no-fabrication rule. When the target
 * role asks for something the person doesn't have, the model is forbidden from
 * writing it in — so this is where that requirement surfaces instead.
 *
 * Tone matters more than usual here. Someone job hunting is reading a list of
 * things they lack, which is a discouraging thing to be handed. So: state it
 * plainly, always name adjacent experience they do have, and never imply they
 * shouldn't apply. The framing is "here's what to prepare for", not "here's why
 * you'll be rejected".
 */
export function GapCards({ gaps }: { gaps: GapCard[] }) {
  if (!gaps.length) return null;

  const mustHaves = gaps.filter((g) => g.severity === "must-have");
  const niceToHaves = gaps.filter((g) => g.severity === "nice-to-have");

  return (
    <div>
      <h3 className="field-label mb-1.5">Not on your resume</h3>
      <p className="mb-3 text-[12px] leading-relaxed text-ink-3">
        This role asks for these. We haven&apos;t added them — only you know what
        you&apos;ve actually done.
      </p>

      <div className="flex flex-col gap-2.5">
        {[...mustHaves, ...niceToHaves].map((gap, i) => (
          <div
            key={i}
            className="rounded-sheet border border-rule bg-paper-raised p-3"
          >
            <div className="flex items-baseline justify-between gap-2">
              <p className="text-[13px] font-semibold leading-snug text-ink">
                {gap.requirement}
              </p>
              <span
                className={`shrink-0 font-mono text-[10px] uppercase tracking-wide ${
                  gap.severity === "must-have" ? "text-ochre" : "text-ink-3"
                }`}
              >
                {gap.severity === "must-have" ? "required" : "preferred"}
              </span>
            </div>

            <p className="mt-1.5 text-[12.5px] leading-relaxed text-ink-2">
              {gap.reason}
            </p>

            {gap.relatedExisting.length > 0 && (
              <div className="mt-2.5 border-t border-rule pt-2">
                <p className="text-[11.5px] leading-relaxed text-ink-2">
                  <span className="font-semibold">Closest thing you have:</span>{" "}
                  {gap.relatedExisting.join(", ")}
                </p>
              </div>
            )}
          </div>
        ))}
      </div>

      {mustHaves.length > 0 && (
        <p className="mt-3 text-[11.5px] leading-relaxed text-ink-3">
          Missing a required item doesn&apos;t disqualify you — most postings
          list more than they hire for. If you do have any of this, add it in the
          Sections tab and it&apos;ll be worked in.
        </p>
      )}
    </div>
  );
}
