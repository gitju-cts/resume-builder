"use client";

import { clsx } from "clsx";
import * as React from "react";

/**
 * Primitives, kept deliberately few. shadcn/ui is copy-paste by design, so
 * rather than pull the whole set we keep the handful this product actually uses,
 * styled to the token system. Radix goes underneath anything that needs real
 * accessibility behaviour (dialog, tabs) rather than being reimplemented.
 */

export function Button({
  variant = "primary",
  size = "md",
  className,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "sm" | "md" | "lg";
}) {
  return (
    <button
      className={clsx(
        "inline-flex items-center justify-center gap-2 rounded-well font-sans font-semibold",
        "transition-colors disabled:pointer-events-none disabled:opacity-45",
        {
          sm: "h-8 px-3 text-[13px]",
          md: "h-10 px-4 text-sm",
          // 52px: comfortable for a thumb on a phone, which is where a lot of
          // this audience actually is.
          lg: "h-[52px] px-7 text-base",
        }[size],
        {
          primary: "bg-ink text-paper hover:bg-ink-2",
          secondary: "border border-rule-strong bg-paper-raised text-ink hover:bg-paper-sunk",
          ghost: "text-ink-2 hover:bg-paper-sunk hover:text-ink",
          danger: "border border-flag/40 bg-transparent text-flag hover:bg-flag/8",
        }[variant],
        className
      )}
      {...props}
    />
  );
}

/** A labelled well. Label is always visible — placeholder-only labels vanish
 *  the moment someone starts typing, which is exactly when they're needed. */
export function Field({
  label,
  hint,
  optional,
  children,
  htmlFor,
}: {
  label: string;
  hint?: string;
  optional?: boolean;
  children: React.ReactNode;
  htmlFor?: string;
}) {
  return (
    <div className="flex min-h-0 flex-col gap-2">
      <div className="flex items-baseline justify-between gap-3">
        <label htmlFor={htmlFor} className="field-label">
          {label}
        </label>
        {optional && <span className="text-[11px] text-ink-3">optional</span>}
      </div>
      {children}
      {hint && <p className="text-[12.5px] leading-snug text-ink-3">{hint}</p>}
    </div>
  );
}

export const Textarea = React.forwardRef<
  HTMLTextAreaElement,
  React.TextareaHTMLAttributes<HTMLTextAreaElement>
>(function Textarea({ className, ...props }, ref) {
  return (
    <textarea
      ref={ref}
      className={clsx(
        "w-full resize-none rounded-well border border-rule bg-paper-sunk px-3.5 py-3",
        "font-sans text-[15px] leading-relaxed text-ink placeholder:text-ink-3",
        "focus:border-stamp focus:bg-paper-raised focus:outline-none",
        className
      )}
      {...props}
    />
  );
});

export const Input = React.forwardRef<
  HTMLInputElement,
  React.InputHTMLAttributes<HTMLInputElement>
>(function Input({ className, ...props }, ref) {
  return (
    <input
      ref={ref}
      className={clsx(
        "h-11 w-full rounded-well border border-rule bg-paper-sunk px-3.5",
        "font-sans text-[15px] text-ink placeholder:text-ink-3",
        "focus:border-stamp focus:bg-paper-raised focus:outline-none",
        className
      )}
      {...props}
    />
  );
});

/** A bordered region. No shadow — the only shadow in the system belongs to the
 *  paper preview, where it carries meaning. */
export function Panel({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={clsx("rounded-sheet border border-rule bg-paper-raised", className)}
      {...props}
    >
      {children}
    </div>
  );
}

/**
 * Errors state what happened and what to do. They don't apologise and they
 * aren't vague — the interface's voice, not a person's.
 */
export function Notice({
  tone = "info",
  children,
}: {
  tone?: "info" | "warn" | "error";
  children: React.ReactNode;
}) {
  return (
    <div
      role={tone === "error" ? "alert" : "status"}
      className={clsx(
        "rounded-well border-l-[3px] px-3.5 py-2.5 text-[13.5px] leading-snug",
        {
          info: "border-l-stamp bg-stamp/6 text-ink-2",
          warn: "border-l-ochre bg-ochre/8 text-ink-2",
          error: "border-l-flag bg-flag/8 text-ink",
        }[tone]
      )}
    >
      {children}
    </div>
  );
}

/** Loading copy that says what is happening, in order, rather than spinning
 *  silently. Users abandon silent waits. */
export function ProgressLog({ steps, active }: { steps: string[]; active: number }) {
  return (
    <ol className="flex flex-col gap-1.5" aria-live="polite">
      {steps.map((s, i) => (
        <li
          key={s}
          className={clsx(
            "flex items-center gap-2.5 font-mono text-[12.5px]",
            i < active && "text-ink-3",
            i === active && "text-ink",
            i > active && "text-ink-3/50"
          )}
        >
          <span aria-hidden className="w-3">
            {i < active ? "✓" : i === active ? "▸" : "·"}
          </span>
          {s}
        </li>
      ))}
    </ol>
  );
}
