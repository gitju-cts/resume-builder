"use client";

import { signIn } from "next-auth/react";
import { useState } from "react";
import { Button, Field, Input, Notice } from "@/components/ui/primitives";

/**
 * Phone sign-in.
 *
 * The two-step shape (number, then code) is the real flow, so swapping the stub
 * for an SMS provider is a backend change only — this component doesn't move.
 *
 * The development banner is deliberately loud and ugly. A stub that looks
 * finished is a stub that ships.
 */
export function PhoneSignIn({ redirectTo = "/dashboard" }: { redirectTo?: string }) {
  const [stage, setStage] = useState<"phone" | "code">("phone");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [devCode, setDevCode] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function requestCode() {
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Couldn't send a code.");
      setDevCode(json.devCode ?? null);
      setStage("code");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Couldn't send a code.");
    } finally {
      setBusy(false);
    }
  }

  async function verify() {
    setBusy(true);
    setError(null);
    try {
      const res = await signIn("phone-otp", {
        phone,
        code,
        redirect: false,
      });
      if (res?.error) {
        setError("That code isn't right. Check it and try again.");
        return;
      }
      window.location.href = redirectTo;
    } catch {
      setError("Couldn't sign you in. Try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-3">
      {devCode && (
        <div className="rounded-well border-2 border-dashed border-flag bg-flag/8 px-3 py-2.5">
          <p className="font-mono text-[11px] font-bold uppercase tracking-wide text-flag">
            Development stub
          </p>
          <p className="mt-1 text-[12.5px] leading-snug text-ink">
            Any phone number works. The code is{" "}
            <span className="font-mono font-bold">{devCode}</span>. This is not
            real authentication and must not be exposed publicly.
          </p>
        </div>
      )}

      {stage === "phone" ? (
        <>
          <Field label="Phone number" htmlFor="phone" hint="We'll text you a code.">
            <Input
              id="phone"
              type="tel"
              inputMode="numeric"
              autoComplete="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="98765 43210"
            />
          </Field>
          <Button
            onClick={requestCode}
            disabled={busy || phone.replace(/\D/g, "").length < 10}
          >
            {busy ? "Sending…" : "Send me a code"}
          </Button>
        </>
      ) : (
        <>
          <Field
            label="Enter the code"
            htmlFor="code"
            hint={`Sent to ${phone.replace(/\D/g, "").slice(-4).padStart(8, "•")}`}
          >
            <Input
              id="code"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
              placeholder="123456"
              className="font-mono text-lg tracking-[0.3em]"
            />
          </Field>
          <Button onClick={verify} disabled={busy || code.length < 4}>
            {busy ? "Checking…" : "Sign in"}
          </Button>
          <button
            onClick={() => {
              setStage("phone");
              setCode("");
              setError(null);
            }}
            className="self-start text-[12.5px] text-ink-2 underline decoration-rule-strong hover:text-ink"
          >
            Use a different number
          </button>
        </>
      )}

      {error && <Notice tone="error">{error}</Notice>}
    </div>
  );
}
