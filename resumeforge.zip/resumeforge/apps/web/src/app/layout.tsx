import type { Metadata, Viewport } from "next";
import { Archivo, Bricolage_Grotesque } from "next/font/google";
import "./globals.css";

/**
 * Archivo carries the UI: a grotesque with signage and form lineage, which is
 * the right register for a product about paperwork. Bricolage Grotesque appears
 * only in display sizes — it has real character and would be exhausting at body
 * size. Numerals come from the system mono, because a score is data.
 */
const sans = Archivo({
  subsets: ["latin"],
  variable: "--font-sans",
  weight: ["400", "500", "600", "700", "800"],
  display: "swap",
});

const display = Bricolage_Grotesque({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["500", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "ResumeForge — a resume built to clear the scanner",
  description:
    "Paste the job description, upload whatever you already have, and get an ATS-safe PDF and an editable Word file.",
};

export const viewport: Viewport = {
  themeColor: "#F0F1EC",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${sans.variable} ${display.variable}`}>
      <body className="min-h-dvh font-sans antialiased">{children}</body>
    </html>
  );
}
