"use client";

import { useRouter } from "next/navigation";
import { useCallback, useRef, useState } from "react";
import {
  Button,
  Field,
  Notice,
  Panel,
  ProgressLog,
  Textarea,
} from "@/components/ui/primitives";
import { setDraft } from "@/lib/draft";

/**
 * One entry screen.
 *
 * The original wireframe had two side-by-side screens — "create" and "modify" —
 * that looked almost identical. That is the confusion this product exists to
 * avoid, and people don't know which one they need before they start. So: one
 * screen, three optional inputs, and the mode is *inferred*. A file means
 * tailor; no file means build from scratch. Nobody has to classify themselves.
 *
 * All three inputs are optional and say so. Any one of them is enough to start.
 */

const STEPS = [
  "Reading your document",
  "Understanding the role",
  "Matching your experience",
  "Typesetting the page",
  "Checking it against a scanner",
];

const ACCEPT = ".pdf,.docx,.doc,.rtf,.odt,.txt,.jpg,.jpeg,.png,.webp,.heic";

export default function EntryScreen() {
  const router = useRouter();
  const fileInput = useRef<HTMLInputElement>(null);

  const [file, setFile] = useState<File | null>(null);
  const [dragging, setDragging] = useState(false);
  const [jdText, setJdText] = useState("");
  const [jdUrl, setJdUrl] = useState("");
  const [instruction, setInstruction] = useState("");
  const [busy, setBusy] = useState(false);
  const [step, setStep] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const ready = !!file || jdText.trim().length > 0 || instruction.trim().length > 0;

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const dropped = e.dataTransfer.files?.[0];
    if (dropped) setFile(dropped);
  }, []);

  async function build() {
    if (!ready || busy) return;
    setBusy(true);
    setError(null);
    setStep(file ? 0 : 1);

    // Advance the log on a timer. The server does these stages in one request,
    // so this is honest about order but not about exact timing — which is the
    // right trade for not leaving someone staring at a silent spinner.
    const tick = setInterval(() => setStep((s) => Math.min(s + 1, STEPS.length - 1)), 2600);

    try {
      let resolvedJd = jdText.trim();

      if (!resolvedJd && jdUrl.trim()) {
        const jdRes = await fetch("/api/jd", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: jdUrl.trim() }),
        });
        const jdJson = await jdRes.json();
        if (!jdRes.ok) throw new Error(jdJson.error ?? "Couldn't read that link.");
        resolvedJd = jdJson.rawText ?? "";
      }

      const form = new FormData();
      if (file) form.append("file", file);
      if (resolvedJd) form.append("jdText", resolvedJd);
      if (instruction.trim()) form.append("instruction", instruction.trim());

      const res = await fetch("/api/tailor", { method: "POST", body: form });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Something went wrong.");

      setDraft(json);
      router.push("/editor");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong.");
      setBusy(false);
    } finally {
      clearInterval(tick);
    }
  }

  return (
    <main className="mx-auto flex min-h-dvh max-w-shell flex-col px-5 sm:px-8">
      <header className="flex items-center justify-between py-5">
        <span className="font-display text-[17px] font-bold tracking-tight">
          ResumeForge
        </span>
        <span className="hidden font-mono text-[11px] text-ink-3 sm:block">
          PDF · DOCX · LaTeX
        </span>
      </header>

      <div className="hairline" />

      {/* Hero as thesis: state the actual mechanic of the world this product
          operates in, rather than a slogan about AI. */}
      <section className="max-w-prose py-11 sm:py-16">
        <h1 className="font-display text-display-lg font-bold">
          Most resumes are read by software before a person sees them.
        </h1>
        <p className="mt-5 text-[17px] leading-relaxed text-ink-2">
          This one is built to survive that, then convince the person on the
          other side. Give us anything you have — a resume, a bio-data, a photo
          of one, or nothing at all.
        </p>
      </section>

      <div className="grid gap-5 pb-6 md:grid-cols-2">
        {/* ---------------------------------------------------------- upload */}
        <Panel className="p-5">
          <Field
            label="What you have now"
            optional
            hint="Resume, CV, or bio-data. PDF, Word, or a photo from your phone."
          >
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragging(true);
              }}
              onDragLeave={() => setDragging(false)}
              onDrop={onDrop}
              className={`form-grid flex min-h-[168px] flex-col items-center justify-center gap-3 rounded-well border border-dashed px-4 py-6 text-center transition-colors ${
                dragging ? "border-stamp bg-stamp/6" : "border-rule-strong"
              }`}
            >
              {file ? (
                <>
                  <p className="max-w-full truncate font-mono text-[13px] text-ink">
                    {file.name}
                  </p>
                  <p className="font-mono text-[11px] text-ink-3">
                    {(file.size / 1024).toFixed(0)} KB
                  </p>
                  <Button variant="ghost" size="sm" onClick={() => setFile(null)}>
                    Remove
                  </Button>
                </>
              ) : (
                <>
                  <p className="text-[14px] text-ink-2">
                    Drop a file here, or
                  </p>
                  <div className="flex flex-wrap justify-center gap-2">
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => fileInput.current?.click()}
                    >
                      Choose file
                    </Button>
                    {/* Separate camera entry point. On a phone this opens the
                        camera directly, which is the whole cyber-cafe path. */}
                    <label className="inline-flex h-8 cursor-pointer items-center rounded-well border border-rule-strong bg-paper-raised px-3 text-[13px] font-semibold hover:bg-paper-sunk sm:hidden">
                      Take a photo
                      <input
                        type="file"
                        accept="image/*"
                        capture="environment"
                        className="sr-only"
                        onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                      />
                    </label>
                  </div>
                  <p className="text-[12px] text-ink-3">
                    Don&apos;t have one? Skip this.
                  </p>
                </>
              )}
              <input
                ref={fileInput}
                type="file"
                accept={ACCEPT}
                className="sr-only"
                onChange={(e) => setFile(e.target.files?.[0] ?? null)}
              />
            </div>
          </Field>
        </Panel>

        {/* -------------------------------------------------------------- jd */}
        <Panel className="p-5">
          <Field
            label="Where you're applying"
            optional
            hint="Paste the description, or a link to the posting."
            htmlFor="jd"
          >
            <Textarea
              id="jd"
              rows={5}
              value={jdText}
              onChange={(e) => setJdText(e.target.value)}
              placeholder="Paste the job description here…"
            />
            <div className="mt-1 flex items-center gap-2">
              <span className="font-mono text-[11px] text-ink-3">or link</span>
              <input
                type="text"
                value={jdUrl}
                onChange={(e) => setJdUrl(e.target.value)}
                placeholder="https://…"
                className="h-9 min-w-0 flex-1 rounded-well border border-rule bg-paper-sunk px-3 font-mono text-[12.5px] placeholder:text-ink-3 focus:border-stamp focus:outline-none"
              />
            </div>
          </Field>
        </Panel>
      </div>

      {/* ------------------------------------------------------------ prompt */}
      <Panel className="p-5">
        <Field
          label="In your own words"
          optional
          hint="Any language is fine — we'll write the resume in English."
          htmlFor="instruction"
        >
          <Textarea
            id="instruction"
            rows={3}
            value={instruction}
            onChange={(e) => setInstruction(e.target.value)}
            placeholder="I want to apply for a shop helper job near me — please update my bio-data"
          />
        </Field>
      </Panel>

      {/* ------------------------------------------------------------ action */}
      <div className="flex flex-col gap-4 py-7">
        {error && <Notice tone="error">{error}</Notice>}

        {busy ? (
          <Panel className="p-5">
            <ProgressLog steps={STEPS} active={step} />
          </Panel>
        ) : (
          <div className="flex flex-col items-start gap-3 sm:flex-row sm:items-center">
            <Button size="lg" onClick={build} disabled={!ready} className="w-full sm:w-auto">
              Build my resume
            </Button>
            <p className="text-[13px] text-ink-3">
              {ready
                ? "No account needed. You'll see the resume before anything else."
                : "Add a file, a job description, or a sentence about what you need."}
            </p>
          </div>
        )}
      </div>

      <div className="hairline" />

      {/* Explain the differentiator plainly, and be honest that two-column
          designs carry risk rather than claiming everything is equally safe. */}
      <section className="grid gap-7 py-10 sm:grid-cols-3">
        {[
          {
            h: "We measure it, not claim it",
            p: "Every resume is re-read by a separate parser after we build it. If your phone number doesn't survive, we tell you instead of hoping.",
          },
          {
            h: "We won't invent experience",
            p: "The wording changes; the facts don't. If a role needs something you don't have, you get told about the gap — not a sentence claiming you have it.",
          },
          {
            h: "Editable three ways",
            p: "Fill in sections, ask in plain language, or take over the LaTeX yourself. The Word file opens and edits anywhere.",
          },
        ].map((c) => (
          <div key={c.h} className="flex flex-col gap-2">
            <h2 className="font-display text-[16px] font-bold">{c.h}</h2>
            <p className="text-[13.5px] leading-relaxed text-ink-2">{c.p}</p>
          </div>
        ))}
      </section>

      <footer className="hairline mt-auto flex flex-wrap items-center justify-between gap-3 py-5 font-mono text-[11px] text-ink-3">
        <span>ResumeForge</span>
        <span>ATS grades A–F are measured per document, not per template.</span>
      </footer>
    </main>
  );
}
