import { Suspense } from "react";
import { EditorClient } from "@/components/EditorClient";

/**
 * Suspense boundary for the editor.
 *
 * `useSearchParams` in a client component forces Next 15 to bail out of static
 * rendering unless the component sits inside a Suspense boundary — without this
 * the build errors rather than warning. Splitting the page is the fix rather
 * than opting the whole route out of static rendering.
 */
export default function EditorPage() {
  return (
    <Suspense
      fallback={
        <main className="flex min-h-dvh items-center justify-center">
          <p className="font-mono text-[12px] text-ink-3">Opening your resume…</p>
        </main>
      }
    >
      <EditorClient />
    </Suspense>
  );
}
