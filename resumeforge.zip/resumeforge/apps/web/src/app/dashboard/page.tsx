import Link from "next/link";
import { auth } from "@/lib/auth";
import { currentOwner } from "@/lib/session";
import { resumes } from "@/lib/db/repos";
import { Button, Notice, Panel } from "@/components/ui/primitives";

/**
 * Saved resumes.
 *
 * Works for anonymous owners too — that's the point of ownership being a pair.
 * Someone who saved without signing in sees their resumes here and sees the
 * expiry date, rather than discovering the loss a week later.
 */
export default async function DashboardPage() {
  const session = await auth();
  const owner = await currentOwner();
  const docs = owner ? await resumes.list(owner) : [];

  return (
    <main className="mx-auto flex min-h-dvh max-w-shell flex-col px-5 sm:px-8">
      <header className="flex items-center justify-between py-5">
        <Link href="/" className="font-display text-[17px] font-bold tracking-tight">
          ResumeForge
        </Link>
        <span className="font-mono text-[11px] text-ink-3">
          {session?.user ? (session.user.name ?? "signed in") : "not signed in"}
        </span>
      </header>
      <div className="hairline" />

      <section className="py-9">
        <h1 className="font-display text-display-sm font-bold">Your resumes</h1>

        {docs.length === 0 ? (
          <div className="mt-5 flex flex-col items-start gap-4">
            <p className="max-w-prose text-[15px] leading-relaxed text-ink-2">
              Nothing saved yet. Build one and press Save — you don&apos;t need an
              account for that.
            </p>
            <Link href="/">
              <Button>Build a resume</Button>
            </Link>
          </div>
        ) : (
          <div className="mt-5 flex flex-col gap-2.5">
            {owner?.kind === "anon" && (
              <Notice tone="warn">
                These are saved to this browser only and will expire. Signing in
                keeps them permanently and makes them reachable from your phone.
              </Notice>
            )}

            {docs.map((d) => (
              <Panel key={String(d._id)} className="flex flex-wrap items-center gap-x-5 gap-y-2 p-4">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[14px] font-semibold">{d.title}</p>
                  <p className="mt-0.5 font-mono text-[11px] text-ink-3">
                    {d.templateId} · {d.seq} change{d.seq === 1 ? "" : "s"}
                    {d.mode === "latex" && " · hand-edited LaTeX"}
                    {d.expiresAt && ` · expires ${d.expiresAt.toDateString()}`}
                  </p>
                </div>

                {d.atsReport && (
                  <span
                    className={`font-mono text-sm font-bold ${
                      d.atsReport.grade === "A"
                        ? "text-pass"
                        : d.atsReport.grade === "B"
                          ? "text-ochre"
                          : "text-flag"
                    }`}
                  >
                    {d.atsReport.score}
                  </span>
                )}

                <Link href={`/editor?id=${String(d._id)}`}>
                  <Button size="sm" variant="secondary">Open</Button>
                </Link>
              </Panel>
            ))}
          </div>
        )}
      </section>

      {!session?.user && docs.length > 0 && (
        <div className="pb-9">
          <Link href="/signin">
            <Button>Keep these permanently</Button>
          </Link>
        </div>
      )}
    </main>
  );
}
