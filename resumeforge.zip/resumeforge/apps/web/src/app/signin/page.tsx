import { redirect } from "next/navigation";
import { auth, authConfigured, signIn, staticOtpEnabled } from "@/lib/auth";
import { PhoneSignIn } from "@/components/PhoneSignIn";
import { Button, Field, Input, Notice, Panel } from "@/components/ui/primitives";

/**
 * Sign-in.
 *
 * Framed as permanence, not access — because that's what it actually buys. The
 * resume is already saved by the time anyone lands here, so promising "sign in
 * to save your work" would be a lie and would also make the anonymous path feel
 * like a trap.
 */
export default async function SignInPage() {
  const session = await auth();
  if (session?.user) redirect("/dashboard");

  return (
    <main className="mx-auto flex min-h-dvh max-w-prose flex-col justify-center gap-7 px-6 py-16">
      <div>
        <h1 className="font-display text-display-sm font-bold">
          Keep your resume permanently
        </h1>
        <p className="mt-3 text-[15px] leading-relaxed text-ink-2">
          Your resume is already saved. An account stops it expiring and lets you
          open it from another device.
        </p>
      </div>

      {!authConfigured ? (
        <Notice tone="warn">
          No sign-in method is configured on this deployment. Add
          <span className="font-mono"> AUTH_GOOGLE_ID</span> or
          <span className="font-mono"> AUTH_RESEND_KEY</span> to the environment,
          then restart. Anonymous saving works either way.
        </Notice>
      ) : (
        <div className="flex flex-col gap-5">
          {/* Phone first: for this audience it is the likeliest path. */}
          {staticOtpEnabled && <PhoneSignIn />}

          {staticOtpEnabled && (process.env.AUTH_GOOGLE_ID || process.env.AUTH_RESEND_KEY) && (
            <div className="flex items-center gap-3">
              <div className="h-px flex-1 bg-rule" />
              <span className="font-mono text-[11px] text-ink-3">or</span>
              <div className="h-px flex-1 bg-rule" />
            </div>
          )}

          {process.env.AUTH_GOOGLE_ID && (
            <form
              action={async () => {
                "use server";
                await signIn("google", { redirectTo: "/dashboard" });
              }}
            >
              <Button size="lg" className="w-full" type="submit">
                Continue with Google
              </Button>
            </form>
          )}

          {process.env.AUTH_GOOGLE_ID && process.env.AUTH_RESEND_KEY && (
            <div className="flex items-center gap-3">
              <div className="h-px flex-1 bg-rule" />
              <span className="font-mono text-[11px] text-ink-3">or</span>
              <div className="h-px flex-1 bg-rule" />
            </div>
          )}

          {process.env.AUTH_RESEND_KEY && (
            <form
              action={async (formData: FormData) => {
                "use server";
                await signIn("resend", {
                  email: String(formData.get("email") ?? ""),
                  redirectTo: "/dashboard",
                });
              }}
              className="flex flex-col gap-3"
            >
              <Field label="Email" htmlFor="email" hint="We'll send a link. No password to remember.">
                <Input id="email" name="email" type="email" required placeholder="you@example.com" />
              </Field>
              <Button variant="secondary" type="submit" className="w-full">
                Send me a link
              </Button>
            </form>
          )}
        </div>
      )}

      <Panel className="p-3.5">
        <p className="text-[12.5px] leading-relaxed text-ink-2">
          A resume is a personal document. We keep yours to show it back to you
          and nothing else — it isn&apos;t shown to employers or recruiters, and
          you can delete it at any time.
        </p>
      </Panel>

      <a href="/" className="text-[13px] text-ink-2 underline decoration-rule-strong hover:text-ink">
        Back to the resume
      </a>
    </main>
  );
}
