import { NextRequest, NextResponse } from "next/server";
import { docsvc } from "@/lib/docsvc";
import { ResumeStrict } from "@/lib/schema";

export const runtime = "nodejs";
export const maxDuration = 90;

/**
 * Render and download.
 *
 * PDF and DOCX are produced by two independent renderers from the same JSON.
 * The DOCX is deliberately plainer than the PDF — that's not a bug and the UI
 * says so before the user downloads it.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const resume = ResumeStrict.parse(body.resume);
    const format = body.format === "docx" ? "docx" : body.format === "tex" ? "tex" : "pdf";
    const templateId = String(body.templateId ?? "ats-classic-single");
    const templateVersion = body.templateVersion ? String(body.templateVersion) : undefined;
    const options = (body.options ?? {}) as Record<string, unknown>;

    const args = { resume, templateId, templateVersion, options };

    if (format === "tex") {
      const { tex } = await docsvc.renderTex(args);
      return new NextResponse(tex, {
        headers: {
          "Content-Type": "application/x-tex; charset=utf-8",
          "Content-Disposition": `attachment; filename="${safeName(resume.basics.name)}.tex"`,
        },
      });
    }

    const result =
      format === "docx"
        ? await docsvc.renderDocx(args)
        : await docsvc.renderPdf({ ...args, runLint: false });

    const bytes = Buffer.from(result.artifactB64, "base64");
    const ext = format === "docx" ? "docx" : "pdf";
    const mime =
      format === "docx"
        ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        : "application/pdf";

    return new NextResponse(bytes, {
      headers: {
        "Content-Type": mime,
        "Content-Disposition": `attachment; filename="${safeName(resume.basics.name)}.${ext}"`,
        "Content-Length": String(bytes.length),
      },
    });
  } catch (e) {
    console.error("[render]", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Couldn't build that file." },
      { status: 500 }
    );
  }
}

function safeName(name: string): string {
  const clean = name.replace(/[^\w\s-]/g, "").trim().replace(/\s+/g, "_");
  return (clean || "Resume") + "_Resume";
}
