import { NextRequest, NextResponse } from "next/server";
import { docsvc } from "@/lib/docsvc";
import { ResumeStrict } from "@/lib/schema";

export const runtime = "nodejs";
export const maxDuration = 60;

/**
 * Preview render: returns base64 PDF plus a fresh ATS report as JSON.
 *
 * Separate from /api/render (which streams a file download) because the editor
 * needs the score alongside the document, and because a preview should never
 * trigger a browser download. Lint runs here and not on download — the score is
 * a thing you act on while editing, not while saving.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const resume = ResumeStrict.parse(body.resume);
    const templateId = String(body.templateId ?? "ats-classic-single");

    const result = await docsvc.renderPdf({
      resume,
      templateId,
      templateVersion: body.templateVersion ? String(body.templateVersion) : undefined,
      options: (body.options ?? {}) as Record<string, unknown>,
      runLint: true,
    });

    return NextResponse.json({
      pdfB64: result.artifactB64,
      ats: result.ats,
      renderMs: result.durationMs,
    });
  } catch (e) {
    console.error("[render/preview]", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Couldn't rebuild the page." },
      { status: 500 }
    );
  }
}
