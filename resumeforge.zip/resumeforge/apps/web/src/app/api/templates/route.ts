import { NextResponse } from "next/server";
import { docsvc } from "@/lib/docsvc";

export const runtime = "nodejs";
export const revalidate = 300;

/**
 * GET /api/templates — the catalogue, straight from the manifests.
 *
 * The gallery and the design-options panel both render themselves from this,
 * which is what makes "drop a folder in templates/" the whole process for
 * adding a design. No UI change, no code change, no deploy coupling.
 */
export async function GET() {
  const templates = await docsvc.templates();
  return NextResponse.json({ templates, count: templates.length });
}
