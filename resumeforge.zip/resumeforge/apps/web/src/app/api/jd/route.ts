import { NextRequest, NextResponse } from "next/server";
import { parseJD } from "@/lib/ai/operations";

export const runtime = "nodejs";
export const maxDuration = 45;

/**
 * JD ingestion: paste, or a URL.
 *
 * Tiered on purpose. Greenhouse, Lever, Ashby and Workable expose predictable
 * public JSON for a posting, which is clean, fast, and legitimate. Everything
 * else gets an HTML fetch. JS-rendered boards (Workday, Taleo, SuccessFactors)
 * will not yield to a plain fetch, so rather than pretending, we fail fast and
 * ask the person to paste — which always works and takes them five seconds.
 *
 * No LinkedIn scraping. They block it and litigate it, and the paste path makes
 * it unnecessary.
 */

const ATS_PATTERNS: Array<{
  test: RegExp;
  build: (m: RegExpMatchArray) => string;
}> = [
  {
    // boards.greenhouse.io/acme/jobs/12345
    test: /greenhouse\.io\/(?:embed\/job_app\?for=)?([\w-]+)\/jobs\/(\d+)/,
    build: (m) => `https://boards-api.greenhouse.io/v1/boards/${m[1]}/jobs/${m[2]}`,
  },
  {
    // jobs.lever.co/acme/uuid
    test: /jobs\.lever\.co\/([\w-]+)\/([\w-]+)/,
    build: (m) => `https://api.lever.co/v0/postings/${m[1]}/${m[2]}`,
  },
  {
    // jobs.ashbyhq.com/acme/uuid
    test: /jobs\.ashbyhq\.com\/([\w-]+)\/([\w-]+)/,
    build: (m) => `https://api.ashbyhq.com/posting-api/job-board/${m[1]}?jobId=${m[2]}`,
  },
];

const BLOCKED_HOSTS = ["linkedin.com", "www.linkedin.com"];

const UA = "ResumeForgeBot/0.1 (+https://resumeforge.dev/bot)";

function stripHtml(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<nav[\s\S]*?<\/nav>/gi, " ")
    .replace(/<footer[\s\S]*?<\/footer>/gi, " ")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(p|div|li|h[1-6])>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

async function fetchJdText(url: string): Promise<{ text: string; via: string }> {
  const parsed = new URL(url);
  if (BLOCKED_HOSTS.includes(parsed.hostname)) {
    throw new Error(
      "That site doesn't allow automated reading. Copy the description and paste it instead."
    );
  }

  for (const p of ATS_PATTERNS) {
    const m = url.match(p.test);
    if (m) {
      const apiUrl = p.build(m);
      const res = await fetch(apiUrl, {
        headers: { "User-Agent": UA, Accept: "application/json" },
        signal: AbortSignal.timeout(12_000),
      });
      if (res.ok) {
        const json = await res.json();
        const raw = [
          json.title,
          json.text ?? json.content ?? json.descriptionPlain ?? json.description,
          Array.isArray(json.lists)
            ? json.lists.map((l: { text: string; content: string }) => `${l.text}\n${l.content}`).join("\n")
            : "",
        ]
          .filter(Boolean)
          .join("\n\n");
        return { text: stripHtml(String(raw)), via: "ats-api" };
      }
    }
  }

  const res = await fetch(url, {
    headers: { "User-Agent": UA, Accept: "text/html" },
    signal: AbortSignal.timeout(15_000),
    redirect: "follow",
  });
  if (!res.ok) {
    throw new Error(
      "We couldn't open that page. Copy the job description and paste it instead."
    );
  }

  const text = stripHtml(await res.text());
  if (text.length < 400) {
    // Almost certainly a JS-rendered shell. Say so honestly.
    throw new Error(
      "That page loads its content with JavaScript, so we can't read it. Paste the description instead — it only takes a moment."
    );
  }
  return { text, via: "html" };
}

export async function POST(req: NextRequest) {
  try {
    const { text, url } = await req.json();

    let raw = String(text ?? "").trim();
    let via = "paste";

    if (!raw && url) {
      const fetched = await fetchJdText(String(url));
      raw = fetched.text;
      via = fetched.via;
    }

    if (!raw) {
      return NextResponse.json(
        { error: "Paste the job description, or give us a link to it." },
        { status: 400 }
      );
    }

    const parsed = await parseJD(raw);
    return NextResponse.json({ parsed, rawText: raw.slice(0, 40_000), via });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Couldn't read that job description." },
      { status: 400 }
    );
  }
}
