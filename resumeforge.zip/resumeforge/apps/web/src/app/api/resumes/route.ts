import { NextRequest, NextResponse } from "next/server";
import { docsvc } from "@/lib/docsvc";
import { rateLimit, resumes } from "@/lib/db/repos";
import { currentOwner, ownerForWrite, rateLimitKey } from "@/lib/session";
import { ResumeStrict } from "@/lib/schema";

export const runtime = "nodejs";

/**
 * POST /api/resumes — Save.
 *
 * This is the endpoint the save-triggered auth flow depends on, and the ordering
 * inside it is the whole point: it writes the resume first, under an anonymous
 * owner if nobody is signed in, and only then does the client offer to sign in.
 *
 * Doing it the other way round loses work. An OAuth redirect navigates away from
 * the page and takes the in-memory draft with it, so anyone who signed in at the
 * prompt would come back to nothing. Persist, then authenticate, then claim.
 */
export async function POST(req: NextRequest) {
  try {
    const key = await rateLimitKey(req, "save");
    const limit = await rateLimit(key, 40, 3600);
    if (!limit.allowed) {
      return NextResponse.json(
        { error: "That's a lot of saves in one hour. Try again shortly." },
        { status: 429, headers: { "Retry-After": String(limit.retryAfter) } }
      );
    }

    const body = await req.json();
    const resume = ResumeStrict.parse(body.resume);
    const templateId = String(body.templateId ?? "ats-classic-single");

    const owner = await ownerForWrite();

    const doc = await resumes.create({
      owner,
      resume,
      templateId,
      templateVersion: body.templateVersion ? String(body.templateVersion) : undefined,
      templateOptions: (body.templateOptions ?? {}) as Record<string, unknown>,
      atsReport: body.ats ?? null,
      jdId: body.jdId ? String(body.jdId) : undefined,
      title: body.title ? String(body.title) : undefined,
    });

    return NextResponse.json({
      id: String(doc._id),
      // The client uses this to decide whether to show the sign-in prompt.
      ownerKind: owner.kind,
      savedAt: doc.updatedAt,
      // Honest about the expiry rather than letting someone assume permanence.
      expiresAt: doc.expiresAt ?? null,
    });
  } catch (e) {
    console.error("[resumes:POST]", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Couldn't save that." },
      { status: 500 }
    );
  }
}

/** GET /api/resumes — the person's saved resumes. */
export async function GET() {
  const owner = await currentOwner();
  if (!owner) return NextResponse.json({ resumes: [], ownerKind: null });

  const docs = await resumes.list(owner);

  return NextResponse.json({
    ownerKind: owner.kind,
    resumes: docs.map((d) => ({
      id: String(d._id),
      title: d.title,
      templateId: d.templateId,
      mode: d.mode,
      score: d.atsReport?.score ?? null,
      grade: d.atsReport?.grade ?? null,
      versions: d.seq,
      updatedAt: d.updatedAt,
      expiresAt: d.expiresAt ?? null,
    })),
  });
}

/** Kept alongside so the docsvc template list has one caller path. */
export async function OPTIONS() {
  const templates = await docsvc.templates();
  return NextResponse.json({ templates });
}
