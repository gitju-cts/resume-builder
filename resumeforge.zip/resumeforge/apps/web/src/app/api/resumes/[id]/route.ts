import { NextRequest, NextResponse } from "next/server";
import { docsvc } from "@/lib/docsvc";
import { resumes } from "@/lib/db/repos";
import { currentOwner } from "@/lib/session";
import { ResumeStrict } from "@/lib/schema";

export const runtime = "nodejs";
export const maxDuration = 90;

type Ctx = { params: Promise<{ id: string }> };

/** GET — load a saved resume and rebuild its preview. */
export async function GET(_req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  const owner = await currentOwner();
  if (!owner) return NextResponse.json({ error: "Not found." }, { status: 404 });

  const doc = await resumes.get(id, owner);
  if (!doc) return NextResponse.json({ error: "Not found." }, { status: 404 });

  // Render on load rather than storing the PDF. A stored artifact goes stale
  // the moment a template is fixed, and rendering is cheap next to storing
  // millions of near-identical PDFs.
  let pdfB64: string | null = null;
  let ats = doc.atsReport ?? null;
  try {
    const rendered = await docsvc.renderPdf({
      resume: doc.canonical,
      templateId: doc.templateId,
      templateVersion: doc.templateVersion,
      options: doc.templateOptions,
      runLint: true,
    });
    pdfB64 = rendered.artifactB64;
    ats = rendered.ats ?? ats;
  } catch (e) {
    console.warn("[resumes:GET] render failed, returning data only", e);
  }

  return NextResponse.json({
    id: String(doc._id),
    resume: doc.canonical,
    templateId: doc.templateId,
    templateVersion: doc.templateVersion,
    templateOptions: doc.templateOptions,
    mode: doc.mode,
    latexSource: doc.latexSource ?? null,
    seq: doc.seq,
    ownerKind: doc.ownerKind,
    expiresAt: doc.expiresAt ?? null,
    pdfB64,
    ats,
  });
}

/**
 * PATCH — record a change.
 *
 * The caller sends the full next document; the repository diffs it against
 * what's stored and appends the patch plus its inverse. Computing the diff
 * server-side means undo is always correct even when the change came from a
 * model, which is the least trustworthy possible source for an inverse patch.
 */
export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const owner = await currentOwner();
    if (!owner) return NextResponse.json({ error: "Not found." }, { status: 404 });

    const body = await req.json();
    const next = ResumeStrict.parse(body.resume);

    const result = await resumes.applyChange({
      id,
      owner,
      next,
      authoredBy: body.authoredBy === "ai" ? "ai" : "user",
      prompt: body.prompt ? String(body.prompt) : undefined,
      note: body.note ? String(body.note) : undefined,
      atsReport: body.ats ?? null,
      templateId: body.templateId ? String(body.templateId) : undefined,
      templateOptions: body.templateOptions as Record<string, unknown> | undefined,
    });

    if (!result) return NextResponse.json({ error: "Not found." }, { status: 404 });

    return NextResponse.json({ id, seq: result.seq, savedAt: new Date() });
  } catch (e) {
    console.error("[resumes:PATCH]", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Couldn't save that change." },
      { status: 500 }
    );
  }
}

/** DELETE — soft delete, so it stays recoverable. */
export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  const owner = await currentOwner();
  if (!owner) return NextResponse.json({ error: "Not found." }, { status: 404 });

  const removed = await resumes.remove(id, owner);
  if (!removed) return NextResponse.json({ error: "Not found." }, { status: 404 });

  return NextResponse.json({ ok: true });
}
