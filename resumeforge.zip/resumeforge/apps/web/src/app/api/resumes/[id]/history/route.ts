import { NextRequest, NextResponse } from "next/server";
import { applyPatch, type Operation } from "fast-json-patch";
import { docsvc } from "@/lib/docsvc";
import { resumes, versions } from "@/lib/db/repos";
import { currentOwner } from "@/lib/session";
import { ResumeStrict } from "@/lib/schema";

export const runtime = "nodejs";
export const maxDuration = 90;

type Ctx = { params: Promise<{ id: string }> };

/** GET — the change log, newest first. Snapshots are projected out; nobody
 *  scrolling history needs a megabyte of embedded documents. */
export async function GET(_req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  const owner = await currentOwner();
  if (!owner) return NextResponse.json({ error: "Not found." }, { status: 404 });

  const doc = await resumes.get(id, owner);
  if (!doc) return NextResponse.json({ error: "Not found." }, { status: 404 });

  const log = await versions.list(id);

  return NextResponse.json({
    seq: doc.seq,
    versions: log.map((v) => ({
      seq: v.seq,
      authoredBy: v.authoredBy,
      prompt: v.prompt ?? null,
      note: v.note ?? null,
      changeCount: v.patch.length,
      createdAt: v.createdAt,
      // Only the most recent version can be undone in one step; older ones
      // need a revert-to, which is a different operation.
      undoable: v.seq === doc.seq && v.seq > 0,
    })),
  });
}

/**
 * POST — undo the most recent change.
 *
 * Applies the stored inverse patch rather than replaying history from a
 * snapshot. That keeps undo O(1) and, more importantly, keeps it correct: the
 * inverse was computed from the actual before/after pair at write time, not
 * reconstructed later from an assumption about what the change meant.
 *
 * The undo is itself recorded as a new version. History is append-only — we
 * never rewrite it, so "undo" is a forward step that happens to reverse one.
 */
export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const { id } = await ctx.params;
    const owner = await currentOwner();
    if (!owner) return NextResponse.json({ error: "Not found." }, { status: 404 });

    const doc = await resumes.get(id, owner);
    if (!doc) return NextResponse.json({ error: "Not found." }, { status: 404 });

    const body = await req.json().catch(() => ({}));
    const targetSeq = typeof body.seq === "number" ? body.seq : doc.seq;

    if (targetSeq <= 0) {
      return NextResponse.json(
        { error: "This is the original version — there's nothing to undo." },
        { status: 400 }
      );
    }

    const inverse = await versions.inverseOf(id, targetSeq);
    if (!inverse) {
      return NextResponse.json({ error: "That version isn't in the log." }, { status: 404 });
    }

    let reverted;
    try {
      const applied = applyPatch(
        structuredClone(doc.canonical),
        inverse as Operation[],
        true,
        false
      );
      reverted = ResumeStrict.parse(applied.newDocument);
    } catch (e) {
      console.error("[history:POST] inverse did not apply", e);
      return NextResponse.json(
        {
          error:
            "That change can't be undone cleanly — the document has moved on since. Edit the section directly instead.",
        },
        { status: 409 }
      );
    }

    const rendered = await docsvc
      .renderPdf({
        resume: reverted,
        templateId: doc.templateId,
        templateVersion: doc.templateVersion,
        options: doc.templateOptions,
        runLint: true,
      })
      .catch(() => null);

    const result = await resumes.applyChange({
      id,
      owner,
      next: reverted,
      authoredBy: "user",
      note: `Undid change #${targetSeq}`,
      atsReport: rendered?.ats ?? null,
    });

    return NextResponse.json({
      id,
      seq: result?.seq ?? doc.seq,
      resume: reverted,
      pdfB64: rendered?.artifactB64 ?? null,
      ats: rendered?.ats ?? null,
    });
  } catch (e) {
    console.error("[history:POST]", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Couldn't undo that." },
      { status: 500 }
    );
  }
}
