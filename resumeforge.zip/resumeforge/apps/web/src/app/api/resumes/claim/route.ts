import { NextResponse } from "next/server";
import { anonSessions } from "@/lib/db/repos";
import { auth } from "@/lib/auth";
import { clearAnonCookie, pendingAnonId } from "@/lib/session";

export const runtime = "nodejs";

/**
 * POST /api/resumes/claim — idempotent retry for the ownership transfer.
 *
 * The sign-in event already attempts this. This endpoint exists because that
 * event runs inside an OAuth callback, where cookie access can fail depending on
 * provider and redirect shape, and a silently failed claim would strand
 * someone's resume in an anonymous session they can no longer reach.
 *
 * Safe to call on every page load: with no anonymous cookie, or one already
 * claimed, it moves nothing and reports zero.
 */
export async function POST() {
  const session = await auth();
  if (!session?.user?.id) {
    return NextResponse.json({ claimed: 0, reason: "not-signed-in" });
  }

  const anonId = await pendingAnonId();
  if (!anonId) return NextResponse.json({ claimed: 0, reason: "nothing-pending" });

  const claimed = await anonSessions.claim(anonId, session.user.id);
  if (claimed > 0) await clearAnonCookie();

  return NextResponse.json({ claimed });
}
