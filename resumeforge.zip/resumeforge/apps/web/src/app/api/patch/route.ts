import { NextRequest, NextResponse } from "next/server";
import { applyPatch, type Operation } from "fast-json-patch";
import { docsvc } from "@/lib/docsvc";
import { promptToPatch } from "@/lib/ai/operations";
import { Resume, ResumeStrict } from "@/lib/schema";

export const runtime = "nodejs";
export const maxDuration = 60;

/**
 * Prompt editing.
 *
 * The model never regenerates the document — it emits a JSON Patch, we validate
 * it, apply it to a clone, re-validate against the schema, and return both the
 * proposed document and the patch. The client shows a diff; the user accepts or
 * rejects. That is what makes undo free and makes AI edits auditable.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const resume = ResumeStrict.parse(body.resume);
    const instruction = String(body.instruction ?? "").trim();
    const templateId = String(body.templateId ?? "ats-classic-single");

    if (!instruction) {
      return NextResponse.json({ error: "Tell us what to change." }, { status: 400 });
    }

    const result = await promptToPatch({ resume, instruction });

    if (result.refused) {
      return NextResponse.json({
        refused: true,
        reason:
          result.refusalReason ??
          "That would mean adding experience you don't have. I can help you present what you do have more effectively instead.",
        patch: [],
      });
    }

    if (!result.patch.length) {
      return NextResponse.json({
        refused: false,
        noop: true,
        explanation: result.explanation || "Nothing needed changing for that.",
        patch: [],
      });
    }

    // Apply to a clone. validate:true throws on a malformed pointer rather than
    // silently corrupting the document.
    let proposed: Resume;
    try {
      const clone = structuredClone(resume);
      const applied = applyPatch(
        clone,
        result.patch as Operation[],
        /* validateOperation */ true,
        /* mutateDocument */ false
      );
      proposed = ResumeStrict.parse(applied.newDocument);
    } catch (e) {
      console.error("[patch] rejected", e, result.patch);
      return NextResponse.json(
        {
          error:
            "That edit didn't come out cleanly. Try describing it a different way, or edit the section directly.",
        },
        { status: 422 }
      );
    }

    const rendered = await docsvc.renderPdf({ resume: proposed, templateId });

    return NextResponse.json({
      refused: false,
      patch: result.patch,
      explanation: result.explanation,
      resume: proposed,
      pdfB64: rendered.artifactB64,
      ats: rendered.ats,
    });
  } catch (e) {
    console.error("[patch]", e);
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "Something went wrong." },
      { status: 500 }
    );
  }
}
