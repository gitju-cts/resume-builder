import { NextRequest, NextResponse } from "next/server";
import { requestOtp, staticOtpEnabled } from "@/lib/auth-phone";

export const runtime = "nodejs";

/**
 * POST /api/auth/otp — issue a phone code.
 *
 * Verification is not here: it goes through the Auth.js `phone-otp` Credentials
 * provider so a successful code creates a real session. This endpoint only
 * mints the challenge.
 *
 * In dev it returns the code in the response body so the UI can display it,
 * because there is no SMS provider. That field is named `devCode` rather than
 * `code` so it is obvious in every call site that this must not survive the
 * switch to real delivery.
 */
export async function POST(req: NextRequest) {
  try {
    if (!staticOtpEnabled) {
      return NextResponse.json(
        {
          error:
            "Phone sign-in isn't available on this deployment. Use Google or an email link.",
        },
        { status: 503 }
      );
    }

    const { phone } = await req.json();
    const result = await requestOtp(String(phone ?? ""));

    if (!result.ok) {
      return NextResponse.json({ error: result.error }, { status: 400 });
    }

    return NextResponse.json({
      phone: result.phone,
      expiresInSeconds: result.expiresInSeconds,
      devCode: result.devCode,
      // Surfaced so the UI can be explicit rather than implying a real SMS was sent.
      devMode: result.devCode !== null,
    });
  } catch (e) {
    console.error("[otp]", e);
    return NextResponse.json({ error: "Couldn't send a code." }, { status: 500 });
  }
}
