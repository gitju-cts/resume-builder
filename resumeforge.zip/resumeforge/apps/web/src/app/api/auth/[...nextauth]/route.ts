import { handlers } from "@/lib/auth";

/** Auth.js v5 exposes both verbs from one handler pair. */
export const { GET, POST } = handlers;
