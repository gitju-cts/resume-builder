import { NextRequest, NextResponse } from "next/server";
import { docsvc } from "@/lib/docsvc";
import { extractResume, parseJD, tailorResume } from "@/lib/ai/operations";
import { Resume, ResumeStrict } from "@/lib/schema";
import { pickTemplate } from "@/lib/templatePicker";

export const runtime = "nodejs";
export const maxDuration = 120;

/**
 * The core loop, in one request.
 *
 *   upload? -> ingest -> extract      \
 *                                      -> tailor -> render -> lint -> respond
 *   jd text/url? -> parse             /
 *
 * Deliberately one round trip: the entry screen has one button, so the API has
 * one endpoint. Anything the user waits on happens behind a single spinner with
 * honest progress copy rather than four sequential loading states.
 */
export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();

    const file = form.get("file") as File | null;
    const jdText = (form.get("jdText") as string | null)?.trim() || "";
    const instruction = (form.get("instruction") as string | null)?.trim() || "";
    const existingResumeRaw = form.get("resume") as string | null;

    if (!file && !jdText && !instruction && !existingResumeRaw) {
      return NextResponse.json(
        { error: "Add a resume, a job description, or tell us what you need." },
        { status: 400 }
      );
    }

    // ---------------------------------------------------------------- 1. resume
    let resume: Resume | null = null;
    let extractionNotes: string[] = [];
    let detectedFormat = "unclear";
    let lowConfidence: string[] = [];

    if (existingResumeRaw) {
      resume = ResumeStrict.parse(JSON.parse(existingResumeRaw));
    } else if (file) {
      const ingested = await docsvc.ingest(file);
      if (ingested.error) {
        return NextResponse.json({ error: ingested.error }, { status: 400 });
      }

      const extraction = ingested.needsVision
        ? await extractResume({
            image: {
              mimeType: file.type || "image/jpeg",
              base64: Buffer.from(await file.arrayBuffer()).toString("base64"),
            },
            hint: instruction,
          })
        : await extractResume({ text: ingested.text, hint: instruction });

      resume = extraction.resume;
      detectedFormat = extraction.detectedFormat;
      lowConfidence = extraction.confidence.lowConfidenceFields;
      extractionNotes = ingested.notes;
    } else {
      // No file: the person is describing themselves in the prompt box.
      const extraction = await extractResume({
        text: instruction,
        hint: "This is a person describing themselves in their own words, not a formal document.",
      });
      resume = extraction.resume;
      lowConfidence = extraction.confidence.lowConfidenceFields;
    }

    // ---------------------------------------------------------------- 2. jd
    let jd = null;
    let gaps: unknown[] = [];
    let changeNotes: string[] = [];

    if (jdText) {
      jd = await parseJD(jdText);
      const tailored = await tailorResume({ resume, jd, instruction });
      resume = tailored.resume;
      gaps = tailored.gaps;
      changeNotes = tailored.changeNotes;
      resume.meta.targetRole = jd.title;
    }

    // ---------------------------------------------------------------- 3. render
    const templateId = pickTemplate(resume, await docsvc.templates());
    const rendered = await docsvc.renderPdf({ resume, templateId });

    return NextResponse.json({
      resume,
      jd,
      gaps,
      changeNotes,
      templateId,
      pdfB64: rendered.artifactB64,
      ats: rendered.ats,
      meta: {
        detectedFormat,
        lowConfidence,
        notes: extractionNotes,
        renderMs: rendered.durationMs,
      },
    });
  } catch (e) {
    const message = e instanceof Error ? e.message : "Something went wrong.";
    console.error("[tailor]", e);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
