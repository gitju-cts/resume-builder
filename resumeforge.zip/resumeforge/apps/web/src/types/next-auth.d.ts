import type { DefaultSession } from "next-auth";

/**
 * Auth.js ships no `id` on `session.user` by default, but every write path in
 * this app keys ownership off it (see lib/session.ts). Declaring it here is what
 * makes `{ kind: "user", id: session.user.id }` typecheck.
 */
declare module "next-auth" {
  interface Session {
    user: {
      id: string;
    } & DefaultSession["user"];
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    /** Set in the jwt callback; read in the session callback. */
    uid?: string;
  }
}
