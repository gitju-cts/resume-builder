import NextAuth from "next-auth";
import Google from "next-auth/providers/google";
import Resend from "next-auth/providers/resend";
import { MongoDBAdapter } from "@auth/mongodb-adapter";
import { getMongoClientPromise } from "./db/client";
import { anonSessions } from "./db/repos";
import { PhoneOtpProvider, staticOtpEnabled } from "./auth-phone";

/**
 * Auth.
 *
 * Three providers, ordered by how this audience actually signs in:
 *
 * - Phone OTP, the best fit for the cyber-cafe and small-job personas, many of
 *   whom have a phone number and no email they check. Currently a STATIC-CODE
 *   STUB — see lib/auth-phone.ts, and read the guard before deploying.
 * - Google, because students and early-career applicants overwhelmingly have an
 *   account already and it's one tap on a phone.
 * - Email link, because a meaningful share of this market has neither, and an
 *   OAuth-only wall would silently exclude them.
 *
 * Every provider is optional. With none configured the app still works end to
 * end, including saving — anonymous ownership is real ownership that expires.
 * See docs/AUTH.md.
 */

const providers = [];

// Phone first: for this audience it is the most likely path, and putting it
// first in the array puts it first in the UI.
// NOTE: currently a static-code stub. See lib/auth-phone.ts.
if (staticOtpEnabled) providers.push(PhoneOtpProvider);

if (process.env.AUTH_GOOGLE_ID && process.env.AUTH_GOOGLE_SECRET) {
  providers.push(
    Google({
      clientId: process.env.AUTH_GOOGLE_ID,
      clientSecret: process.env.AUTH_GOOGLE_SECRET,
      allowDangerousEmailAccountLinking: true,
    })
  );
}

if (process.env.AUTH_RESEND_KEY) {
  providers.push(
    Resend({
      apiKey: process.env.AUTH_RESEND_KEY,
      from: process.env.AUTH_EMAIL_FROM ?? "noreply@resumeforge.dev",
    })
  );
}


export const { handlers, auth, signIn, signOut } = NextAuth({
  adapter: MongoDBAdapter(getMongoClientPromise()),
  providers,
  // JWT rather than database sessions: Auth.js does not create database
  // sessions for Credentials providers, so the phone flow would sign in and
  // then appear signed out on the next request under the database strategy.
  session: { strategy: "jwt", maxAge: 60 * 60 * 24 * 30 },
  pages: { signIn: "/signin" },

  callbacks: {
    async jwt({ token, user }) {
      if (user?.id) token.uid = user.id;
      return token;
    },
    async session({ session, token }) {
      // The whole app keys ownership off user.id, so it must be present.
      if (session.user && token.uid) session.user.id = String(token.uid);
      return session;
    },
  },

  events: {
    /**
     * The claim.
     *
     * This is why Save works before sign-in: the resume already exists, owned by
     * an anonymous session, and signing in just changes who owns it. One field
     * update, no data migration, nothing to lose in transit.
     *
     * Deliberately fault-tolerant. If this throws, the sign-in still succeeds
     * and /api/resumes/claim retries from the client on next page load —
     * because a failed claim that also blocked sign-in would leave someone
     * locked out of work they can see is theirs.
     */
    async signIn({ user }) {
      if (!user.id) return;
      try {
        // Imported lazily: next/headers is only valid inside a request scope,
        // and this event also fires in contexts where it isn't.
        const { pendingAnonId, clearAnonCookie } = await import("./session");
        const anonId = await pendingAnonId();
        if (!anonId) return;

        const moved = await anonSessions.claim(anonId, user.id);
        if (moved > 0) await clearAnonCookie();
      } catch (e) {
        console.warn("[auth] claim deferred to client retry:", e);
      }
    },
  },
});

/** True when at least one provider is configured. The UI checks this so a
 *  half-configured deployment shows an explanation instead of a dead button. */
export const authConfigured = providers.length > 0;
export { staticOtpEnabled };
