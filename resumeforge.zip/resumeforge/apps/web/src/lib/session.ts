import { cookies } from "next/headers";
import { anonSessions, type Owner } from "./db/repos";
import { auth } from "./auth";

/**
 * Owner resolution.
 *
 * Every write path asks one question — "who owns this?" — and gets back an
 * `Owner` whether or not anyone has signed in. That symmetry is the whole trick
 * behind save-triggered auth: Save doesn't need an account, it needs an owner,
 * and an anonymous session is a perfectly good owner that happens to expire.
 */

const ANON_COOKIE = "rf_anon";
const ANON_MAX_AGE = 60 * 60 * 24 * 7; // matches the DB TTL

/**
 * Resolve the current owner, minting an anonymous session if needed.
 *
 * Call this only from routes that are about to write. Read paths should use
 * `currentOwner()` so a stray GET doesn't create a session record for a bot.
 */
export async function ownerForWrite(): Promise<Owner> {
  const session = await auth();
  if (session?.user?.id) {
    return { kind: "user", id: session.user.id };
  }

  const jar = await cookies();
  const existing = jar.get(ANON_COOKIE)?.value;

  if (existing) {
    const id = anonSessions.idFromToken(existing);
    // The DB row may have expired out from under a still-valid cookie.
    if (await anonSessions.exists(id)) return { kind: "anon", id };
  }

  const { token, id } = await anonSessions.create();
  jar.set(ANON_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: ANON_MAX_AGE,
  });

  return { kind: "anon", id };
}

/** Resolve the owner without creating anything. Returns null when there is
 *  genuinely nobody — no session, no cookie. */
export async function currentOwner(): Promise<Owner | null> {
  const session = await auth();
  if (session?.user?.id) return { kind: "user", id: session.user.id };

  const jar = await cookies();
  const token = jar.get(ANON_COOKIE)?.value;
  if (!token) return null;

  const id = anonSessions.idFromToken(token);
  return (await anonSessions.exists(id)) ? { kind: "anon", id } : null;
}

/** Read the pending anonymous session id, if any. Used by the claim step. */
export async function pendingAnonId(): Promise<string | null> {
  const jar = await cookies();
  const token = jar.get(ANON_COOKIE)?.value;
  return token ? anonSessions.idFromToken(token) : null;
}

/** After a successful claim the cookie is dead weight and should not linger —
 *  it would let a shared machine's next user inherit an empty session. */
export async function clearAnonCookie(): Promise<void> {
  const jar = await cookies();
  jar.delete(ANON_COOKIE);
}

/** Stable-ish key for rate limiting. Prefers the real user, falls back to the
 *  anonymous session, then to the forwarded IP. */
export async function rateLimitKey(req: Request, bucket: string): Promise<string> {
  const owner = await currentOwner();
  if (owner) return `${bucket}:${owner.kind}:${owner.id}`;

  const fwd = req.headers.get("x-forwarded-for") ?? "";
  const ip = fwd.split(",")[0]?.trim() || "unknown";
  return `${bucket}:ip:${ip}`;
}
