import type { Resume } from "./schema";

/**
 * Client for the Python document service.
 *
 * Only ever called from the server side — docsvc holds no auth of its own and
 * must never be reachable from a browser.
 */

const BASE = process.env.DOCSVC_URL ?? "http://localhost:8000";
const TOKEN = process.env.DOCSVC_TOKEN ?? "";

export type LintFinding = {
  code: string;
  severity: "error" | "warning" | "info";
  message: string;
  field?: string | null;
};

export type AtsReport = {
  score: number;
  grade: "A" | "B" | "C" | "F";
  fieldRecovery: number;
  readingOrderOk: boolean;
  findings: LintFinding[];
  recoveredTextChars: number;
};

export type RenderResult = {
  format: "pdf" | "docx" | "tex";
  artifactB64: string;
  durationMs: number;
  ats?: AtsReport | null;
  compileLogExcerpt?: string | null;
};

export type TemplateManifest = {
  id: string;
  version: string;
  name: string;
  blurb: string;
  layout: { columns: number; style: string; photo: boolean };
  atsGrade: "A" | "B" | "C";
  categories: string[];
  situations: string[];
  seniority: string[];
  maxPagesRecommended: number;
  /** Hint for the tailoring step. Never applied at render time. */
  recommendedOrder?: string[];
  /** Present when a template carries a known parsing risk worth surfacing. */
  atsNote?: string;
  options: Record<
    string,
    {
      type: "color" | "enum" | "boolean" | "number";
      label: string;
      help?: string;
      default: unknown;
      values?: string[];
      labels?: string[];
    }
  >;
};

class DocsvcError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly detail?: unknown
  ) {
    super(message);
  }
}

async function call<T>(path: string, body: unknown, timeoutMs = 45_000): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(`${BASE}${path}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(TOKEN ? { "X-Service-Token": TOKEN } : {}),
      },
      body: JSON.stringify(body),
      signal: controller.signal,
      cache: "no-store",
    });

    if (!res.ok) {
      let detail: unknown;
      try {
        detail = (await res.json())?.detail;
      } catch {
        detail = await res.text();
      }
      throw new DocsvcError(
        typeof detail === "string" ? detail : "The document service rejected that.",
        res.status,
        detail
      );
    }

    return (await res.json()) as T;
  } catch (e) {
    if (e instanceof DocsvcError) throw e;
    if ((e as Error).name === "AbortError") {
      throw new DocsvcError("Building the document took too long. Try again.", 504);
    }
    throw new DocsvcError("Couldn't reach the document service.", 502, e);
  } finally {
    clearTimeout(timer);
  }
}

export type RenderArgs = {
  resume: Resume;
  templateId: string;
  templateVersion?: string;
  options?: Record<string, unknown>;
  runLint?: boolean;
};

export const docsvc = {
  renderPdf: (args: RenderArgs) =>
    call<RenderResult>("/render/pdf", {
      resume: args.resume,
      templateId: args.templateId,
      templateVersion: args.templateVersion,
      options: args.options ?? {},
      runLint: args.runLint ?? true,
    }),

  renderDocx: (args: RenderArgs) =>
    call<RenderResult>("/render/docx", {
      resume: args.resume,
      templateId: args.templateId,
      templateVersion: args.templateVersion,
      options: args.options ?? {},
      runLint: false,
    }),

  renderTex: (args: RenderArgs) =>
    call<{ tex: string; templateId: string; templateVersion: string }>("/render/tex", {
      resume: args.resume,
      templateId: args.templateId,
      templateVersion: args.templateVersion,
      options: args.options ?? {},
    }),

  compileTex: (tex: string, templateId = "ats-classic-single") =>
    call<RenderResult>("/compile/tex", { tex, templateId }),

  lint: (resume: Resume, pdfB64: string) =>
    call<AtsReport>("/lint", { resume, pdfB64 }),

  async templates(): Promise<TemplateManifest[]> {
    const res = await fetch(`${BASE}/templates`, {
      headers: TOKEN ? { "X-Service-Token": TOKEN } : {},
      next: { revalidate: 300 },
    });
    if (!res.ok) return [];
    return (await res.json()).templates ?? [];
  },

  async ingest(file: File): Promise<{
    kind: string;
    text: string;
    needsVision: boolean;
    pageCount: number;
    notes: string[];
    error?: string;
  }> {
    const form = new FormData();
    form.append("file", file);
    const res = await fetch(`${BASE}/ingest`, {
      method: "POST",
      headers: TOKEN ? { "X-Service-Token": TOKEN } : {},
      body: form,
      cache: "no-store",
    });
    if (!res.ok) {
      throw new DocsvcError("Couldn't read that file.", res.status);
    }
    return res.json();
  },
};

export { DocsvcError };
