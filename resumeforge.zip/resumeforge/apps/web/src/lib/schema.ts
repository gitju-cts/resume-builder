import { z } from "zod";

/**
 * Mirrors schema/resume.schema.json.
 *
 * Do not hand-edit divergences into this file. Run `pnpm schema:gen` to
 * regenerate from the JSON Schema; CI fails the build if this drifts.
 */

export const Origin = z.enum(["user", "extracted", "ai-rewritten"]);
export type Origin = z.infer<typeof Origin>;

/**
 * Bullet is a plain object on purpose.
 *
 * It is tempting to hang the no-fabrication rule off a `.refine()` here, but
 * this schema is also handed to Gemini as `responseSchema`. A refinement turns
 * the type into a ZodEffects, which has no JSON Schema representation — the
 * conversion either fails or quietly drops the constraint, so the guarantee
 * would evaporate exactly where it matters.
 *
 * The rule is enforced instead by `ResumeStrict` below, applied at every trust
 * boundary, and by `enforceProvenance()` on model output. Same guarantee, in a
 * place that survives serialisation.
 */
export const Bullet = z.object({
  id: z.string(),
  text: z.string(),
  origin: Origin,
  sourceId: z.string().optional(),
  sourceText: z.string().optional(),
  /** Set by enforceProvenance when a rewrite couldn't be traced to a source. */
  needsReview: z.boolean().optional(),
});
export type Bullet = z.infer<typeof Bullet>;

export const DateRange = z.object({
  start: z.string().regex(/^\d{4}(-\d{2})?$/, "Use YYYY or YYYY-MM"),
  end: z.string().optional(),
});
export type DateRange = z.infer<typeof DateRange>;

export const ExperienceItem = z.object({
  id: z.string(),
  role: z.string(),
  org: z.string(),
  location: z.string().optional(),
  dates: DateRange,
  bullets: z.array(Bullet).default([]),
});

export const EducationItem = z.object({
  id: z.string(),
  degree: z.string(),
  field: z.string().optional(),
  institution: z.string(),
  location: z.string().optional(),
  dates: DateRange.optional(),
  score: z.string().optional(),
  details: z.array(Bullet).default([]),
});

export const SkillGroup = z.object({
  label: z.string(),
  items: z.array(z.string()),
});

export const GenericItem = z.object({
  id: z.string(),
  title: z.string(),
  subtitle: z.string().optional(),
  org: z.string().optional(),
  dates: DateRange.optional(),
  url: z.string().optional(),
  bullets: z.array(Bullet).default([]),
});

export const Section = z.discriminatedUnion("kind", [
  z.object({
    id: z.string(),
    kind: z.literal("experience"),
    heading: z.string().default("Work Experience"),
    items: z.array(ExperienceItem),
  }),
  z.object({
    id: z.string(),
    kind: z.literal("education"),
    heading: z.string().default("Education"),
    items: z.array(EducationItem),
  }),
  z.object({
    id: z.string(),
    kind: z.literal("skills"),
    heading: z.string().default("Skills"),
    groups: z.array(SkillGroup),
  }),
  z.object({
    id: z.string(),
    kind: z.enum([
      "projects",
      "certifications",
      "publications",
      "awards",
      "languages",
      "volunteering",
      "extracurricular",
      "custom",
    ]),
    heading: z.string(),
    items: z.array(GenericItem),
  }),
]);
export type Section = z.infer<typeof Section>;

/** Captured on ingest, never rendered. See schema docs for why. */
export const LegacyBiodata = z.object({
  photoUrl: z.string().optional(),
  fatherName: z.string().optional(),
  motherName: z.string().optional(),
  dob: z.string().optional(),
  maritalStatus: z.string().optional(),
  nationality: z.string().optional(),
  gender: z.string().optional(),
  religion: z.string().optional(),
  caste: z.string().optional(),
  fullAddress: z.string().optional(),
});
export type LegacyBiodata = z.infer<typeof LegacyBiodata>;

export const SITUATIONS = [
  "career-switcher",
  "returning-after-gap",
  "biodata-upgrade",
  "academic-cv",
  "internship-seeker",
  "first-job-no-experience",
  "standard",
] as const;

export const SENIORITY = [
  "fresher",
  "entry",
  "mid",
  "senior",
  "lead",
  "executive",
] as const;

export const Resume = z.object({
  schemaVersion: z.literal("1.0"),
  meta: z
    .object({
      locale: z.string().default("en-IN"),
      targetRole: z.string().optional(),
      jdId: z.string().optional(),
      situation: z.enum(SITUATIONS).default("standard"),
      roleFamily: z.string().optional(),
      seniority: z.enum(SENIORITY).optional(),
    })
    .default({ locale: "en-IN", situation: "standard" }),
  basics: z.object({
    name: z.string().min(1),
    headline: z.string().optional(),
    email: z.string().optional(),
    phone: z.string().optional(),
    location: z.string().optional(),
    links: z.array(z.object({ label: z.string(), url: z.string() })).default([]),
    legacy: LegacyBiodata.optional(),
  }),
  summary: z.object({ text: z.string(), origin: Origin }).optional(),
  sections: z.array(Section).default([]),
});
export type Resume = z.infer<typeof Resume>;

/** Walk every bullet in a document, whatever section shape holds it. */
export function eachBullet(resume: Resume): Array<{ bullet: Bullet; path: string }> {
  const out: Array<{ bullet: Bullet; path: string }> = [];
  resume.sections.forEach((sec, si) => {
    if (sec.kind === "skills") return;
    sec.items.forEach((item, ii) => {
      const lists: Array<[string, Bullet[] | undefined]> = [
        ["bullets", (item as { bullets?: Bullet[] }).bullets],
        ["details", (item as { details?: Bullet[] }).details],
      ];
      for (const [key, list] of lists) {
        list?.forEach((bullet, bi) => {
          out.push({ bullet, path: `/sections/${si}/items/${ii}/${key}/${bi}` });
        });
      }
    });
  });
  return out;
}

/**
 * Resume plus the provenance rule.
 *
 * Use this — not `Resume` — anywhere a document arrives from outside: request
 * bodies, stored documents, model output after `enforceProvenance`. `Resume`
 * alone is the wire shape and is what Gemini receives as a response schema.
 *
 * The rule: a bullet claiming to be an AI rewrite must name the bullet it was
 * rewritten from. Without that link there is no way to distinguish rephrasing
 * from invention, which is the one thing this product must never get wrong.
 */
export const ResumeStrict = Resume.superRefine((resume, ctx) => {
  for (const { bullet, path } of eachBullet(resume)) {
    if (bullet.origin === "ai-rewritten" && !bullet.sourceId) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: path.split("/").filter(Boolean),
        message:
          "A bullet marked ai-rewritten must carry sourceId. The model may rephrase what exists; it may not create experience.",
      });
    }
  }
});

// ---------------------------------------------------------------------------
// Job description
// ---------------------------------------------------------------------------

export const ParsedJD = z.object({
  title: z.string(),
  company: z.string().optional(),
  seniority: z.enum(SENIORITY).optional(),
  location: z.string().optional(),
  mustHaves: z.array(z.string()).default([]),
  niceToHaves: z.array(z.string()).default([]),
  keywords: z.array(z.string()).default([]),
  responsibilities: z.array(z.string()).default([]),
});
export type ParsedJD = z.infer<typeof ParsedJD>;

// ---------------------------------------------------------------------------
// Gap cards: what we tell the user instead of fabricating
// ---------------------------------------------------------------------------

export const GapCard = z.object({
  requirement: z.string(),
  severity: z.enum(["must-have", "nice-to-have"]),
  reason: z.string(),
  relatedExisting: z.array(z.string()).default([]),
});
export type GapCard = z.infer<typeof GapCard>;

export const TailorResult = z.object({
  resume: Resume,
  gaps: z.array(GapCard).default([]),
  changeNotes: z.array(z.string()).default([]),
});
export type TailorResult = z.infer<typeof TailorResult>;
