import type { Resume } from "./schema";
import type { TemplateManifest } from "./docsvc";

/**
 * Category taxonomy and template selection.
 *
 * Two independent axes plus a situation tag, never collapsed into one list: a
 * Java fresher and a Java architect share a role family but need different
 * templates, and an academic CV needs different *rules* (no page limit,
 * publications first), not just a different look.
 */

export const ROLE_FAMILIES = [
  // Engineering & tech
  "cs-engineer-fresher", "software-engineer", "senior-dev-manager",
  "java-backend", "dotnet-backend", "frontend-web", "fullstack",
  "mobile-android-ios", "devops-sre-cloud", "qa-automation",
  "ai-ml-engineer", "data-scientist", "data-analyst-bi",
  "cybersecurity", "embedded-vlsi", "database-admin",
  // Core engineering
  "mechanical-engineer", "civil-engineer", "electrical-electronics",
  "chemical-engineer", "production-industrial",
  // Design & creative
  "uiux-designer", "graphic-designer", "video-editor-motion",
  "content-writer", "artist-portfolio", "photographer",
  // Business & commerce
  "commerce-accounting", "ca-cs-cma", "finance-analyst", "banking-bfsi",
  "mba-marketing", "sales-bd", "hr-recruiter", "operations-supplychain",
  "product-manager", "business-analyst",
  // Academia & education
  "professor-lecturer", "school-teacher", "research-scholar-phd",
  "academic-administrator",
  // Sciences, health, agriculture
  "agriculture-agronomy", "biotech-lifesciences", "pharmacy",
  "nursing-paramedical", "doctor-mbbs", "lab-technician",
  // Public sector & services
  "govt-employee", "defence-services", "legal-advocate",
  "hospitality-hotel", "logistics-driver", "retail-frontline",
  "skilled-trades", "bpo-customer-support",
  // Catch-all
  "fresher-any-stream",
] as const;

export type RoleFamily = (typeof ROLE_FAMILIES)[number];

/**
 * Situation changes prompt strategy and layout rules, not just appearance.
 * Keep this in sync with the `situation` enum in the canonical schema.
 */
export const SITUATION_RULES: Record<
  string,
  { maxPages: number; leadWith?: string; note?: string }
> = {
  standard: { maxPages: 1 },
  "career-switcher": {
    maxPages: 1,
    leadWith: "skills",
    note: "Transferable skills come before chronological history.",
  },
  "returning-after-gap": {
    maxPages: 1,
    leadWith: "skills",
    note: "Skills first so the gap isn't the first thing read.",
  },
  "biodata-upgrade": {
    maxPages: 1,
    note: "Legacy personal fields excluded; plainest template preferred.",
  },
  "academic-cv": {
    maxPages: 99,
    leadWith: "publications",
    note: "No page limit. Publications lead.",
  },
  "internship-seeker": { maxPages: 1, leadWith: "education" },
  "first-job-no-experience": { maxPages: 1, leadWith: "projects" },
};

/**
 * Pick the best template for a resume.
 *
 * Bias is toward grade A. Given a tie between a prettier grade-B template and a
 * plain grade-A one, the plain one wins — the user's goal is getting read, not
 * getting complimented on typography.
 */
export function pickTemplate(
  resume: Resume,
  templates: TemplateManifest[],
  preferredId?: string
): string {
  if (!templates.length) return "ats-classic-single";
  if (preferredId && templates.some((t) => t.id === preferredId)) return preferredId;

  const situation = resume.meta?.situation ?? "standard";
  const family = resume.meta?.roleFamily;
  const seniority = resume.meta?.seniority;

  const scored = templates.map((t) => {
    let score = 0;

    // Grade dominates. A grade-B template must be a much better content fit to win.
    score += t.atsGrade === "A" ? 40 : t.atsGrade === "B" ? 15 : 0;

    if (situation && t.situations?.includes(situation)) score += 25;
    if (family && t.categories?.includes(family)) score += 20;
    if (seniority && t.seniority?.includes(seniority)) score += 10;

    // Academic CVs need a template that can run long.
    const rules = SITUATION_RULES[situation] ?? SITUATION_RULES.standard;
    if (rules.maxPages > 1 && t.maxPagesRecommended > 1) score += 15;
    if (rules.maxPages === 1 && t.maxPagesRecommended === 1) score += 5;

    // Single column is the safe default when nothing else distinguishes.
    if (t.layout?.columns === 1) score += 8;

    return { id: t.id, score };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored[0].id;
}

/** Human-facing label for a grade, used in the template gallery. */
/**
 * A template's `recommendedOrder` is a hint for the tailoring step, not a render
 * instruction. The document's own section order is user-controlled and always
 * wins at render time — a template that silently hoisted skills above experience
 * would undo a choice the person made, with no way for them to see why.
 */
export function recommendedOrderFor(
  templateId: string,
  templates: Array<TemplateManifest & { recommendedOrder?: string[] }>
): string[] | null {
  return templates.find((t) => t.id === templateId)?.recommendedOrder ?? null;
}

export function gradeLabel(grade: "A" | "B" | "C" | "F"): string {
  switch (grade) {
    case "A":
      return "Safest for automated screening";
    case "B":
      return "Some risk — check the score before sending";
    case "C":
      return "Higher risk with older systems";
    default:
      return "Not recommended";
  }
}
