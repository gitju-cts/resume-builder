import Credentials from "next-auth/providers/credentials";
import { createHash } from "node:crypto";
import { getDb } from "./db/client";

/**
 * Phone sign-in — DEVELOPMENT STUB.
 *
 * ┌──────────────────────────────────────────────────────────────────────────┐
 * │  THIS ACCEPTS A FIXED CODE. IT IS A COMPLETE AUTHENTICATION BYPASS.      │
 * │  Anyone who knows the code can sign in as any phone number.              │
 * └──────────────────────────────────────────────────────────────────────────┘
 *
 * It exists so the phone flow can be built and tested now, before committing to
 * an SMS provider. The real implementation swaps `verifyCode()` for a provider
 * call and deletes `STATIC_CODE` — nothing else in the app changes, because the
 * provider surface stays identical.
 *
 * Three guardrails, because a stub like this is exactly the kind of thing that
 * gets forgotten and shipped:
 *
 *  1. Refuses to load in production unless ALLOW_STATIC_OTP_IN_PROD is set to
 *     the literal string "i-understand-this-is-insecure".
 *  2. Logs a warning banner on every single verification.
 *  3. Records `authProvider: "phone-static"` on the user, so a production
 *     database can be audited for accounts created this way.
 */

const STATIC_CODE = process.env.STATIC_OTP_CODE ?? "123456";
const PROD_OVERRIDE = "i-understand-this-is-insecure";

export const staticOtpEnabled = (() => {
  if (process.env.NODE_ENV !== "production") return true;
  if (process.env.ALLOW_STATIC_OTP_IN_PROD === PROD_OVERRIDE) {
    console.error(
      "\n" +
        "!".repeat(74) +
        "\n!! STATIC OTP IS ENABLED IN PRODUCTION." +
        "\n!! Any caller who knows the fixed code can sign in as any phone number." +
        "\n!! Remove ALLOW_STATIC_OTP_IN_PROD and implement a real SMS provider." +
        "\n" +
        "!".repeat(74) +
        "\n"
    );
    return true;
  }
  return false;
})();

/** Digits only, so "+91 98765 43210" and "09876543210" resolve to one identity
 *  instead of three accounts for the same person. */
export function normalisePhone(raw: string): string | null {
  const digits = String(raw).replace(/\D/g, "");
  if (digits.length < 10) return null;
  // Keep the last 10 as the local number; most Indian numbers arrive with or
  // without the 91 prefix depending on how the person types it.
  return digits.slice(-10);
}

/**
 * The single function the real implementation replaces.
 *
 * Production version: look up the code issued for this phone, check it hasn't
 * expired, check the attempt counter, delete it on success (single use).
 */
async function verifyCode(phone: string, code: string): Promise<boolean> {
  console.warn(
    `[auth] STATIC OTP accepted for ${phone.slice(0, 2)}••••${phone.slice(-2)} — ` +
      "this is a development stub, not real authentication."
  );
  return code.trim() === STATIC_CODE;
}

/**
 * "Send" a code. The stub sends nothing and returns the code so the UI can
 * display it — which is only acceptable because the code is already public.
 * The real version returns nothing and the UI shows no code.
 */
export async function requestOtp(rawPhone: string): Promise<
  | { ok: true; hint: string; devCode: string | null }
  | { ok: false; error: string }
> {
  const phone = normalisePhone(rawPhone);
  if (!phone) {
    return { ok: false, error: "That doesn't look like a full phone number." };
  }
  return {
    ok: true,
    hint: `••••${phone.slice(-4)}`,
    // Returned only while the stub is in use. The real flow returns null here.
    devCode: staticOtpEnabled ? STATIC_CODE : null,
  };
}

export const PhoneOtpProvider = Credentials({
  id: "phone-otp",
  name: "Phone number",
  credentials: {
    phone: { label: "Phone", type: "tel" },
    code: { label: "Code", type: "text" },
  },

  async authorize(credentials) {
    if (!staticOtpEnabled) return null;

    const phone = normalisePhone(String(credentials?.phone ?? ""));
    const code = String(credentials?.code ?? "");
    if (!phone || !code) return null;

    if (!(await verifyCode(phone, code))) return null;

    // Find or create the user. Auth.js's adapter is email-centric, so phone
    // users get a synthetic local address that can never collide with a real
    // one and is never emailed.
    const db = await getDb();
    const syntheticEmail = `phone-${createHash("sha256").update(phone).digest("hex").slice(0, 16)}@phone.local`;

    const existing = await db.collection("users").findOne({ phone });
    if (existing) {
      await db
        .collection("users")
        .updateOne({ _id: existing._id }, { $set: { lastSeenAt: new Date() } });
      return {
        id: String(existing._id),
        name: existing.name ?? `••••${phone.slice(-4)}`,
        email: existing.email ?? syntheticEmail,
      };
    }

    const res = await db.collection("users").insertOne({
      phone,
      email: syntheticEmail,
      emailVerified: null,
      name: `••••${phone.slice(-4)}`,
      // Auditable marker: a production database can be searched for accounts
      // created through the stub.
      authProvider: "phone-static",
      createdAt: new Date(),
      lastSeenAt: new Date(),
    });

    return {
      id: String(res.insertedId),
      name: `••••${phone.slice(-4)}`,
      email: syntheticEmail,
    };
  },
});
