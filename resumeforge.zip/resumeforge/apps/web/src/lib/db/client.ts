import { MongoClient, type Db } from "mongodb";

/**
 * Mongo connection.
 *
 * Next's dev server hot-reloads modules, which would open a new pool on every
 * edit and exhaust connections within minutes. Caching on `globalThis` is the
 * standard workaround and is intentionally dev-only in effect — in production
 * the module is evaluated once.
 */

const uri = process.env.MONGODB_URI;

declare global {
  // eslint-disable-next-line no-var
  var _mongo: { client: MongoClient; promise: Promise<MongoClient> } | undefined;
}

function makeClient(): { client: MongoClient; promise: Promise<MongoClient> } {
  if (!uri) {
    throw new Error(
      "MONGODB_URI is not set. Copy .env.example to .env.local and point it at a database."
    );
  }
  const client = new MongoClient(uri, {
    maxPoolSize: 10,
    retryWrites: true,
    // A save must not hang the request forever if the primary is unreachable.
    serverSelectionTimeoutMS: 6000,
  });
  return { client, promise: client.connect() };
}

export async function getDb(): Promise<Db> {
  if (!global._mongo) global._mongo = makeClient();
  const client = await global._mongo.promise;
  return client.db();
}

/** Also exported for the Auth.js MongoDB adapter, which wants the client. */
export function getMongoClientPromise(): Promise<MongoClient> {
  if (!global._mongo) global._mongo = makeClient();
  return global._mongo.promise;
}

let indexesReady: Promise<void> | null = null;

/**
 * Idempotent index creation, run once per process on first DB touch.
 *
 * The TTL index on anonSessions is the load-bearing one: anonymous drafts are
 * someone's resume, held without them having asked us to hold it, so they must
 * expire on their own rather than accumulating indefinitely.
 */
export async function ensureIndexes(): Promise<void> {
  if (indexesReady) return indexesReady;

  indexesReady = (async () => {
    const db = await getDb();

    await db.collection("anonSessions").createIndexes([
      { key: { expiresAt: 1 }, expireAfterSeconds: 0, name: "ttl_expiry" },
      { key: { claimedByUserId: 1 }, name: "by_claimer", sparse: true },
    ]);

    await db.collection("resumes").createIndexes([
      { key: { ownerKind: 1, ownerId: 1, updatedAt: -1 }, name: "by_owner_recent" },
      { key: { ownerKind: 1, ownerId: 1, deletedAt: 1 }, name: "by_owner_live" },
      // Anonymous resumes expire with their session; owned ones never do.
      { key: { expiresAt: 1 }, expireAfterSeconds: 0, name: "ttl_anon", sparse: true },
    ]);

    await db.collection("resumeVersions").createIndexes([
      { key: { resumeId: 1, seq: -1 }, name: "by_resume_seq", unique: true },
    ]);

    await db.collection("jobDescriptions").createIndexes([
      { key: { urlHash: 1 }, name: "by_url", unique: true, sparse: true },
      { key: { textHash: 1 }, name: "by_text", unique: true, sparse: true },
      // JD content goes stale; a cached posting older than a fortnight is worse
      // than refetching it.
      { key: { fetchedAt: 1 }, expireAfterSeconds: 60 * 60 * 24 * 14, name: "ttl_jd" },
    ]);

    await db.collection("rateLimit").createIndexes([
      { key: { key: 1, at: 1 }, name: "by_key_time" },
      { key: { at: 1 }, expireAfterSeconds: 3600, name: "ttl_window" },
    ]);
  })();

  return indexesReady;
}
