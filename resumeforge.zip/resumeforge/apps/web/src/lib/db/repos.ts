import { compare, type Operation } from "fast-json-patch";
import { createHash, randomBytes } from "node:crypto";
import { ObjectId } from "mongodb";
import { ensureIndexes, getDb } from "./client";
import type { AtsReport } from "../docsvc";
import type { ParsedJD, Resume } from "../schema";

/**
 * Data access.
 *
 * Two design decisions worth knowing before reading:
 *
 * 1. Ownership is a pair, not an id. A resume belongs to `{ownerKind, ownerId}`
 *    where ownerKind is "anon" or "user". Anonymous ownership is real ownership
 *    with an expiry, not a special case — which is what lets Save work before
 *    anyone has signed in, and lets the claim step be a single field update
 *    rather than a migration.
 *
 * 2. Version history is an append-only patch log, not snapshots. Each version
 *    stores the forward patch and its inverse, so undo is applying the inverse
 *    and needs no diffing at read time. A full snapshot is written every
 *    SNAPSHOT_EVERY versions so replay stays bounded.
 */

const SNAPSHOT_EVERY = 20;
const ANON_TTL_DAYS = 7;

export type OwnerKind = "anon" | "user";
export type Owner = { kind: OwnerKind; id: string };

export type ResumeDoc = {
  _id: ObjectId;
  ownerKind: OwnerKind;
  ownerId: string;
  title: string;
  mode: "structured" | "latex";
  canonical: Resume;
  latexSource?: string;
  templateId: string;
  templateVersion?: string;
  templateOptions: Record<string, unknown>;
  jdId?: string;
  atsReport?: AtsReport | null;
  seq: number;
  createdAt: Date;
  updatedAt: Date;
  deletedAt?: Date | null;
  /** Present only while anonymous. Removed on claim so the record stops expiring. */
  expiresAt?: Date | null;
};

export type VersionDoc = {
  _id: ObjectId;
  resumeId: ObjectId;
  seq: number;
  patch: Operation[];
  inverse: Operation[];
  authoredBy: "user" | "ai";
  prompt?: string;
  note?: string;
  /** Written every SNAPSHOT_EVERY versions to bound replay cost. */
  snapshot?: Resume;
  createdAt: Date;
};

const sha256 = (s: string) => createHash("sha256").update(s).digest("hex");

// ---------------------------------------------------------------------------
// Anonymous sessions
// ---------------------------------------------------------------------------

export const anonSessions = {
  /** The raw token goes in an httpOnly cookie; only its hash is stored, so a
   *  database leak doesn't hand anyone else's drafts to an attacker. */
  async create(): Promise<{ token: string; id: string }> {
    await ensureIndexes();
    const db = await getDb();
    const token = randomBytes(32).toString("base64url");
    const id = sha256(token);
    const now = new Date();

    await db.collection("anonSessions").insertOne({
      _id: id as unknown as ObjectId,
      createdAt: now,
      expiresAt: new Date(now.getTime() + ANON_TTL_DAYS * 864e5),
      claimedByUserId: null,
    });

    return { token, id };
  },

  idFromToken(token: string): string {
    return sha256(token);
  },

  async exists(id: string): Promise<boolean> {
    const db = await getDb();
    return (
      (await db.collection("anonSessions").countDocuments({ _id: id as never }, { limit: 1 })) > 0
    );
  },

  /**
   * Move every resume owned by an anonymous session to a real user.
   *
   * Idempotent by design — it runs both from the sign-in event and from a
   * client-side retry, because a claim that silently fails would strand
   * someone's work behind an account they can't see it from.
   */
  async claim(anonId: string, userId: string): Promise<number> {
    const db = await getDb();

    const result = await db.collection<ResumeDoc>("resumes").updateMany(
      { ownerKind: "anon", ownerId: anonId },
      {
        $set: { ownerKind: "user", ownerId: userId, updatedAt: new Date() },
        // Drop the TTL field: an owned resume must never expire.
        $unset: { expiresAt: "" },
      }
    );

    await db
      .collection("anonSessions")
      .updateOne({ _id: anonId as never }, { $set: { claimedByUserId: userId } });

    return result.modifiedCount;
  },
};

// ---------------------------------------------------------------------------
// Resumes
// ---------------------------------------------------------------------------

export const resumes = {
  async create(input: {
    owner: Owner;
    resume: Resume;
    templateId: string;
    templateVersion?: string;
    templateOptions?: Record<string, unknown>;
    atsReport?: AtsReport | null;
    jdId?: string;
    title?: string;
  }): Promise<ResumeDoc> {
    await ensureIndexes();
    const db = await getDb();
    const now = new Date();

    const doc: Omit<ResumeDoc, "_id"> = {
      ownerKind: input.owner.kind,
      ownerId: input.owner.id,
      title:
        input.title ??
        input.resume.meta?.targetRole ??
        `${input.resume.basics.name} — Resume`,
      mode: "structured",
      canonical: input.resume,
      templateId: input.templateId,
      templateVersion: input.templateVersion,
      templateOptions: input.templateOptions ?? {},
      jdId: input.jdId,
      atsReport: input.atsReport ?? null,
      seq: 0,
      createdAt: now,
      updatedAt: now,
      deletedAt: null,
      expiresAt:
        input.owner.kind === "anon"
          ? new Date(now.getTime() + ANON_TTL_DAYS * 864e5)
          : null,
    };

    const res = await db.collection<ResumeDoc>("resumes").insertOne(doc as ResumeDoc);

    // Seq 0 carries the initial snapshot so history always has a base to
    // replay from, even if every later version is a patch.
    await db.collection<VersionDoc>("resumeVersions").insertOne({
      resumeId: res.insertedId,
      seq: 0,
      patch: [],
      inverse: [],
      authoredBy: "user",
      note: "Created",
      snapshot: input.resume,
      createdAt: now,
    } as VersionDoc);

    return { ...doc, _id: res.insertedId } as ResumeDoc;
  },

  async get(id: string, owner: Owner): Promise<ResumeDoc | null> {
    if (!ObjectId.isValid(id)) return null;
    const db = await getDb();
    return db.collection<ResumeDoc>("resumes").findOne({
      _id: new ObjectId(id),
      ownerKind: owner.kind,
      ownerId: owner.id,
      deletedAt: null,
    });
  },

  async list(owner: Owner, limit = 30): Promise<ResumeDoc[]> {
    const db = await getDb();
    return db
      .collection<ResumeDoc>("resumes")
      .find({ ownerKind: owner.kind, ownerId: owner.id, deletedAt: null })
      .sort({ updatedAt: -1 })
      .limit(limit)
      .toArray();
  },

  /**
   * Record a change as a patch, appending to the log.
   *
   * The inverse is computed here rather than trusted from the caller, because a
   * wrong inverse silently corrupts undo — and the caller (an LLM, in the prompt
   * path) is the least trustworthy source for it.
   */
  async applyChange(input: {
    id: string;
    owner: Owner;
    next: Resume;
    authoredBy: "user" | "ai";
    prompt?: string;
    note?: string;
    atsReport?: AtsReport | null;
    templateId?: string;
    templateOptions?: Record<string, unknown>;
  }): Promise<{ doc: ResumeDoc; seq: number } | null> {
    const db = await getDb();
    const current = await resumes.get(input.id, input.owner);
    if (!current) return null;

    const forward = compare(current.canonical as object, input.next as object);
    const inverse = compare(input.next as object, current.canonical as object);

    // A no-op edit should not create a history entry to scroll past.
    if (forward.length === 0) return { doc: current, seq: current.seq };

    const seq = current.seq + 1;
    const now = new Date();

    await db.collection<VersionDoc>("resumeVersions").insertOne({
      resumeId: current._id,
      seq,
      patch: forward,
      inverse,
      authoredBy: input.authoredBy,
      prompt: input.prompt,
      note: input.note,
      snapshot: seq % SNAPSHOT_EVERY === 0 ? input.next : undefined,
      createdAt: now,
    } as VersionDoc);

    const set: Partial<ResumeDoc> = {
      canonical: input.next,
      seq,
      updatedAt: now,
      atsReport: input.atsReport ?? current.atsReport,
    };
    if (input.templateId) set.templateId = input.templateId;
    if (input.templateOptions) set.templateOptions = input.templateOptions;

    await db
      .collection<ResumeDoc>("resumes")
      .updateOne({ _id: current._id }, { $set: set });

    return { doc: { ...current, ...set } as ResumeDoc, seq };
  },

  /** Soft delete. A resume is worth keeping recoverable for a while. */
  async remove(id: string, owner: Owner): Promise<boolean> {
    if (!ObjectId.isValid(id)) return false;
    const db = await getDb();
    const res = await db.collection<ResumeDoc>("resumes").updateOne(
      { _id: new ObjectId(id), ownerKind: owner.kind, ownerId: owner.id },
      { $set: { deletedAt: new Date() } }
    );
    return res.modifiedCount > 0;
  },

  /** Switching to hand-written LaTeX is one-way — see docs. Recorded explicitly
   *  so the UI can stop offering the structured editors. */
  async ejectToLatex(id: string, owner: Owner, latexSource: string): Promise<boolean> {
    if (!ObjectId.isValid(id)) return false;
    const db = await getDb();
    const res = await db.collection<ResumeDoc>("resumes").updateOne(
      { _id: new ObjectId(id), ownerKind: owner.kind, ownerId: owner.id },
      { $set: { mode: "latex", latexSource, updatedAt: new Date() } }
    );
    return res.modifiedCount > 0;
  },
};

// ---------------------------------------------------------------------------
// Version history
// ---------------------------------------------------------------------------

export const versions = {
  async list(resumeId: string, limit = 60): Promise<VersionDoc[]> {
    if (!ObjectId.isValid(resumeId)) return [];
    const db = await getDb();
    return db
      .collection<VersionDoc>("resumeVersions")
      .find(
        { resumeId: new ObjectId(resumeId) },
        // Snapshots are large and the list view never needs them.
        { projection: { snapshot: 0 } }
      )
      .sort({ seq: -1 })
      .limit(limit)
      .toArray();
  },

  /** Undo one step by applying the stored inverse. Cheaper and more reliable
   *  than replaying from a snapshot, and it works even mid-history. */
  async inverseOf(resumeId: string, seq: number): Promise<Operation[] | null> {
    if (!ObjectId.isValid(resumeId)) return null;
    const db = await getDb();
    const v = await db
      .collection<VersionDoc>("resumeVersions")
      .findOne({ resumeId: new ObjectId(resumeId), seq });
    return v?.inverse ?? null;
  },
};

// ---------------------------------------------------------------------------
// JD cache — pure function of its input, so cache it globally
// ---------------------------------------------------------------------------

export const jobDescriptions = {
  async findCached(opts: { url?: string; text?: string }) {
    await ensureIndexes();
    const db = await getDb();
    const query = opts.url
      ? { urlHash: sha256(opts.url) }
      : opts.text
        ? { textHash: sha256(opts.text.trim()) }
        : null;
    if (!query) return null;
    return db.collection("jobDescriptions").findOne(query);
  },

  async put(input: {
    url?: string;
    rawText: string;
    parsed: ParsedJD;
    via: string;
  }): Promise<string> {
    await ensureIndexes();
    const db = await getDb();
    const now = new Date();
    const doc = {
      urlHash: input.url ? sha256(input.url) : undefined,
      textHash: sha256(input.rawText.trim()),
      sourceUrl: input.url,
      company: input.parsed.company,
      rawText: input.rawText.slice(0, 40_000),
      parsed: input.parsed,
      via: input.via,
      fetchedAt: now,
    };

    const res = await db
      .collection("jobDescriptions")
      .findOneAndUpdate(
        { textHash: doc.textHash },
        { $set: doc },
        { upsert: true, returnDocument: "after" }
      );

    return String(res?._id ?? "");
  },
};

// ---------------------------------------------------------------------------
// Rate limiting
// ---------------------------------------------------------------------------

/**
 * Sliding-window limiter on Mongo.
 *
 * OFF BY DEFAULT — set RATE_LIMIT_ENABLED=true to turn it on.
 *
 * Left in place rather than deleted because the call sites are already correct
 * and it costs nothing while disabled. Turn it on before the app is reachable by
 * anyone but you: the build path spends several Gemini calls plus a LaTeX
 * compile per request, so an open endpoint is an open invitation to spend your
 * API budget.
 */
export async function rateLimit(
  key: string,
  limit: number,
  windowSeconds: number
): Promise<{ allowed: boolean; remaining: number; retryAfter: number }> {
  if (process.env.RATE_LIMIT_ENABLED !== "true") {
    return { allowed: true, remaining: limit, retryAfter: 0 };
  }
  await ensureIndexes();
  const db = await getDb();
  const now = new Date();
  const since = new Date(now.getTime() - windowSeconds * 1000);
  const coll = db.collection("rateLimit");

  const used = await coll.countDocuments({ key, at: { $gte: since } });

  if (used >= limit) {
    const oldest = await coll.find({ key, at: { $gte: since } }).sort({ at: 1 }).limit(1).next();
    const retryAfter = oldest
      ? Math.max(1, Math.ceil((oldest.at.getTime() + windowSeconds * 1000 - now.getTime()) / 1000))
      : windowSeconds;
    return { allowed: false, remaining: 0, retryAfter };
  }

  await coll.insertOne({ key, at: now });
  return { allowed: true, remaining: limit - used - 1, retryAfter: 0 };
}
