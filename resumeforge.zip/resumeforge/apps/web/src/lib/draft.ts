import type { AtsReport } from "./docsvc";
import type { GapCard, ParsedJD, Resume } from "./schema";

/**
 * Draft handoff between the entry screen and the editor.
 *
 * Deliberately in-memory for the anonymous path. The whole point of "no signup
 * before the first result" is that we haven't asked who this person is yet, so
 * we have nowhere legitimate to persist their resume — and a resume is about the
 * most personally identifying document there is. Once they choose to save, the
 * document moves to MongoDB under a real user and this module stops being used.
 *
 * The cost is that a hard refresh loses the draft. That's handled explicitly in
 * the editor rather than papered over: it sends them back to the start with an
 * honest message instead of showing an empty editor.
 */

export type Draft = {
  resume: Resume;
  jd: ParsedJD | null;
  gaps: GapCard[];
  changeNotes: string[];
  templateId: string;
  pdfB64: string;
  ats: AtsReport | null;
  meta: {
    detectedFormat: string;
    lowConfidence: string[];
    notes: string[];
    renderMs: number;
  };
};

let current: Draft | null = null;
const listeners = new Set<() => void>();

export function setDraft(d: Draft): void {
  current = d;
  listeners.forEach((fn) => fn());
}

export function getDraft(): Draft | null {
  return current;
}

export function patchDraft(partial: Partial<Draft>): void {
  if (!current) return;
  current = { ...current, ...partial };
  listeners.forEach((fn) => fn());
}

export function clearDraft(): void {
  current = null;
  listeners.forEach((fn) => fn());
}

export function subscribeDraft(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

/** Turn a base64 PDF into an object URL for the preview iframe.
 *  Callers must revoke the previous URL or the tab leaks a few MB per edit. */
export function pdfObjectUrl(b64: string): string {
  const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
  return URL.createObjectURL(new Blob([bytes], { type: "application/pdf" }));
}
