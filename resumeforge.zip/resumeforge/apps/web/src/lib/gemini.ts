import { GoogleGenAI } from "@google/genai";
import { z } from "zod";

/**
 * Gemini access layer.
 *
 * Model routing is deliberate: extraction and JD parsing are high-volume and
 * mechanical, so they run on Flash-Lite. Tailoring and patch generation are
 * what the user actually judges the product on, so they run on the newest
 * Flash. Nothing here uses Pro by default — it is reserved for retries on
 * hard documents, because at $2/$12 per million it would dominate unit cost.
 */

const MODELS = {
  extract: process.env.GEMINI_MODEL_EXTRACT ?? "gemini-3.5-flash-lite",
  jd: process.env.GEMINI_MODEL_JD ?? "gemini-3.5-flash-lite",
  tailor: process.env.GEMINI_MODEL_TAILOR ?? "gemini-3.7-flash",
  patch: process.env.GEMINI_MODEL_PATCH ?? "gemini-3.7-flash",
  vision: process.env.GEMINI_MODEL_VISION ?? "gemini-3.7-flash",
  hard: process.env.GEMINI_MODEL_HARD ?? "gemini-3.1-pro",
} as const;

let client: GoogleGenAI | null = null;

function ai(): GoogleGenAI {
  if (!client) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error(
        "GEMINI_API_KEY is not set. Copy .env.example to .env.local and add your key."
      );
    }
    client = new GoogleGenAI({ apiKey });
  }
  return client;
}

/** Zod-typed structured call. The SDK accepts Zod directly for responseSchema. */
export async function generateStructured<T extends z.ZodTypeAny>({
  model,
  system,
  prompt,
  schema,
  parts,
  temperature = 0.2,
}: {
  model: string;
  system: string;
  prompt: string;
  schema: T;
  parts?: Array<{ inlineData: { mimeType: string; data: string } }>;
  temperature?: number;
}): Promise<z.infer<T>> {
  const contents = parts?.length
    ? [{ role: "user" as const, parts: [...parts, { text: prompt }] }]
    : prompt;

  const response = await ai().models.generateContent({
    model,
    contents,
    config: {
      systemInstruction: system,
      temperature,
      responseMimeType: "application/json",
      responseSchema: schema,
    },
  });

  const text = response.text;
  if (!text) throw new Error("Empty response from Gemini.");

  // Schema-constrained output should already be clean, but a stray fence is a
  // cheap failure to guard against.
  const cleaned = text.trim().replace(/^```(?:json)?\s*/i, "").replace(/```$/, "");
  return schema.parse(JSON.parse(cleaned));
}

export { MODELS };
