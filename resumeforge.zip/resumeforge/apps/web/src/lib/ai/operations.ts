import { z } from "zod";
import { MODELS, generateStructured } from "../gemini";
import { ParsedJD, Resume, TailorResult, eachBullet, type GapCard } from "../schema";
import { nanoid } from "nanoid";

/**
 * The three AI operations. Every one returns schema-valid data or throws — no
 * prose parsing, no regex over model output.
 */

// ---------------------------------------------------------------------------
// Shared rule. This paragraph is the product's integrity guarantee, so it is
// defined once and injected into every prompt that can touch resume content.
// ---------------------------------------------------------------------------

const NO_FABRICATION = `
ABSOLUTE RULE — you may not invent experience.

You may: rephrase, reorder, re-emphasise, tighten, correct grammar, translate,
split or merge, and infer obvious structure (a date range from "2021 to 2023").

You may NOT: add a job, employer, degree, certification, tool, language, or
skill that is not evidenced in the source material. You may not inflate a
number, invent a metric, add a team size, or claim a scope the source does not
support. If the target role requires something the person does not have, do not
write it in. Report it as a gap instead.

Every bullet you rewrite must set origin to "ai-rewritten" and sourceId to the
id of the bullet it came from. Bullets carried through unchanged keep their
original origin. If you cannot trace a statement to the source, do not emit it.

A fabricated resume gets the person rejected in interview or fired later. Being
accurate matters more than sounding impressive.
`.trim();

// ---------------------------------------------------------------------------
// 1. Extraction: unstructured document -> canonical Resume
// ---------------------------------------------------------------------------

const ExtractionResult = z.object({
  resume: Resume,
  confidence: z
    .object({
      overall: z.number().min(0).max(1),
      lowConfidenceFields: z.array(z.string()).default([]),
    })
    .default({ overall: 0.5, lowConfidenceFields: [] }),
  detectedFormat: z
    .enum(["modern-resume", "indian-biodata", "academic-cv", "plain-text", "unclear"])
    .default("unclear"),
  sourceLanguage: z.string().default("en"),
});

const EXTRACT_SYSTEM = `
You convert documents into a structured resume record.

${NO_FABRICATION}

Extraction guidance:
- Everything you pull from the document has origin "extracted".
- Give every item and bullet a short unique id (e.g. "exp-1", "exp-1-b2").
- Dates as YYYY-MM where the month is known, YYYY otherwise. Current roles get
  end: "present". Never guess a month that isn't in the source.
- Indian bio-data conventions are common. Photo, father's/mother's name, date of
  birth, marital status, nationality, gender, religion and caste belong in
  basics.legacy — capture them, never in a body section.
- Scores stay as written: "8.4 CGPA", "76%", "First Class". Do not convert.
- If the source is not English, extract into English but record sourceLanguage.
  Preserve proper nouns (institution names, employer names) as written.
- List anything you had to guess in confidence.lowConfidenceFields using dotted
  paths, e.g. "basics.email", "sections.0.items.1.dates.start".
- Prefer omitting a field to inventing one.
`.trim();

export async function extractResume(input: {
  text?: string;
  image?: { mimeType: string; base64: string };
  hint?: string;
}) {
  const isVision = !!input.image;

  const prompt = [
    input.hint ? `The person says: ${input.hint}` : "",
    isVision
      ? "Read the attached document image and extract the resume record."
      : `Document text follows.\n\n---\n${input.text ?? ""}\n---`,
  ]
    .filter(Boolean)
    .join("\n\n");

  return generateStructured({
    model: isVision ? MODELS.vision : MODELS.extract,
    system: EXTRACT_SYSTEM,
    prompt,
    schema: ExtractionResult,
    parts: input.image
      ? [{ inlineData: { mimeType: input.image.mimeType, data: input.image.base64 } }]
      : undefined,
    temperature: 0.1,
  });
}

// ---------------------------------------------------------------------------
// 2. JD parsing
// ---------------------------------------------------------------------------

const JD_SYSTEM = `
You read a job posting and extract its requirements.

- mustHaves: stated as required, essential, or minimum qualifications.
- niceToHaves: stated as preferred, bonus, plus, or desirable.
- keywords: concrete nouns an automated screen would match — technologies,
  tools, certifications, domain terms. Not soft skills, not filler like
  "team player" or "fast-paced environment".
- Do not invent requirements the posting does not state. If the posting is
  vague, return few items rather than padding the list.
- Strip boilerplate: benefits, EEO statements, company history, application
  instructions.
`.trim();

export async function parseJD(rawText: string) {
  return generateStructured({
    model: MODELS.jd,
    system: JD_SYSTEM,
    prompt: `Job posting:\n\n---\n${rawText.slice(0, 60_000)}\n---`,
    schema: ParsedJD,
    temperature: 0.1,
  });
}

// ---------------------------------------------------------------------------
// 3. Tailoring: resume + JD -> tailored resume + honest gaps
// ---------------------------------------------------------------------------

const TAILOR_SYSTEM = `
You tailor an existing resume toward a specific job, without fabricating.

${NO_FABRICATION}

How to tailor legitimately:
- Reorder sections and bullets so the most relevant material comes first.
- Rewrite bullets to lead with action and outcome, using the vocabulary of the
  target role where the underlying work genuinely matches. If the person wrote
  "made screens in React" and the role wants "component development", that
  rewrite is fair. If the role wants Kubernetes and they have never used it,
  that is a gap, not a rewrite.
- Surface real metrics already present in the source. Never add new ones.
- Drop material irrelevant to this role rather than padding.
- Write or rewrite the summary to target this role, grounded only in evidence
  from the resume. Mark it origin "ai-rewritten".
- Keep to roughly one page of content unless meta.situation is "academic-cv".

Gap reporting is a required part of the output, not an afterthought. For every
must-have the person cannot support, emit a gap card explaining what is missing
and naming any genuinely adjacent experience they do have. Be plain and kind:
the person is job hunting and this is useful information, not a rejection.

changeNotes: one short plain-language line per meaningful change, so the person
can see what you did. Write for someone non-technical.
`.trim();

export async function tailorResume(args: {
  resume: Resume;
  jd: ParsedJD;
  instruction?: string;
}) {
  const prompt = [
    `Current resume:\n${JSON.stringify(args.resume, null, 1)}`,
    `Target role requirements:\n${JSON.stringify(args.jd, null, 1)}`,
    args.instruction ? `Additional instruction from the person: ${args.instruction}` : "",
  ]
    .filter(Boolean)
    .join("\n\n");

  const result = await generateStructured({
    model: MODELS.tailor,
    system: TAILOR_SYSTEM,
    prompt,
    schema: TailorResult,
    temperature: 0.35,
  });

  return enforceProvenance(result, args.resume);
}

// ---------------------------------------------------------------------------
// 4. Prompt editing -> JSON Patch
// ---------------------------------------------------------------------------

const PatchOp = z.object({
  op: z.enum(["add", "remove", "replace", "move", "copy"]),
  path: z.string(),
  from: z.string().optional(),
  value: z.unknown().optional(),
});

const PatchResult = z.object({
  patch: z.array(PatchOp),
  explanation: z.string(),
  refused: z.boolean().default(false),
  refusalReason: z.string().optional(),
});
export type PatchResult = z.infer<typeof PatchResult>;

const PATCH_SYSTEM = `
You translate a plain-language editing request into an RFC 6902 JSON Patch
against a resume document.

${NO_FABRICATION}

Rules:
- Emit the smallest patch that satisfies the request. Never replace the whole
  document, never touch sections the request did not concern.
- Paths are JSON Pointers into the resume, e.g.
  "/sections/1/items/0/bullets/2/text".
- Array indices must reflect the document as given. To append, use "/-".
- When you rewrite bullet text, also replace that bullet's origin with
  "ai-rewritten" and set sourceId, in the same patch.
- If the request asks you to add experience the person does not have, set
  refused true and explain plainly why in refusalReason. Emit an empty patch.
  Do it kindly — suggest what they could legitimately do instead.
- explanation is one or two sentences a non-technical person would understand.
`.trim();

export async function promptToPatch(args: { resume: Resume; instruction: string }) {
  return generateStructured({
    model: MODELS.patch,
    system: PATCH_SYSTEM,
    prompt: [
      `Resume document:\n${JSON.stringify(args.resume, null, 1)}`,
      `Request: ${args.instruction}`,
    ].join("\n\n"),
    schema: PatchResult,
    temperature: 0.15,
  });
}

// ---------------------------------------------------------------------------
// Provenance enforcement — belt and braces over the prompt rule
// ---------------------------------------------------------------------------

/**
 * Verify the model actually obeyed the no-fabrication rule.
 *
 * The prompt states it; this proves it. A bullet claiming to be a rewrite of a
 * source that doesn't exist in the original document is invented content. We
 * don't drop it silently (the person may want it) and we don't accept it
 * silently either — it gets flagged for explicit confirmation.
 *
 * This runs before ResumeStrict validation, because ResumeStrict would reject
 * the document outright and the person would get an error instead of a resume
 * with three lines to check.
 */
export function enforceProvenance(
  result: z.infer<typeof TailorResult>,
  original: Resume
): z.infer<typeof TailorResult> {
  const knownIds = new Set(eachBullet(original).map(({ bullet }) => bullet.id));
  const orphaned: string[] = [];

  for (const { bullet } of eachBullet(result.resume)) {
    if (bullet.origin === "ai-rewritten" && !knownIds.has(bullet.sourceId ?? "")) {
      orphaned.push(bullet.text.slice(0, 80));
      // Downgrade rather than delete: the claim becomes the person's to confirm,
      // and it can no longer masquerade as a traced rewrite.
      bullet.origin = "user";
      bullet.needsReview = true;
      delete bullet.sourceId;
    }
  }

  if (orphaned.length) {
    result.changeNotes.push(
      `${orphaned.length} line${orphaned.length === 1 ? "" : "s"} couldn't be traced back to your original resume. They're marked for you to confirm or delete.`
    );
  }

  return result;
}

export function newId(prefix: string): string {
  return `${prefix}-${nanoid(6)}`;
}

export type { GapCard };
