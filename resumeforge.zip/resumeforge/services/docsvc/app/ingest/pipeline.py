"""Upload -> text + layout hints.

Routing matters more than any single library here. The hardest input in this
product is not a developer's LaTeX resume — it's a phone photo of a hand-typed
bio-data from a cyber cafe. That path decides whether the product works for the
users who need it most.

Strategy:
  PDF with a text layer  -> Docling (reading order) with PyMuPDF fallback
  PDF without text layer -> flag for vision; do not OCR blindly
  DOCX / DOC / RTF / ODT  -> Docling
  Image                   -> flag for vision, return no text
  Plain text              -> passthrough

We return `needs_vision` rather than OCR-ing here. For low-quality handwritten
or photographed documents a vision model beats OCR-then-parse, because layout
survives. The web app owns model credentials, so it makes that call.
"""

from __future__ import annotations

import io
import logging
import re
from typing import Any

log = logging.getLogger(__name__)

TEXT_DENSITY_FLOOR = 120  # chars/page below this, assume it's a scan

IMAGE_TYPES = {"image/jpeg", "image/png", "image/webp", "image/heic", "image/tiff"}
DOC_EXTS = {".docx", ".doc", ".odt", ".rtf"}


def ingest_file(data: bytes, filename: str, content_type: str) -> dict[str, Any]:
    lower = filename.lower()

    if content_type in IMAGE_TYPES or lower.endswith((".jpg", ".jpeg", ".png", ".webp", ".heic")):
        return {
            "kind": "image",
            "text": "",
            "needsVision": True,
            "pageCount": 1,
            "notes": ["Image upload — route to a vision model, not OCR."],
        }

    if lower.endswith(".pdf") or content_type == "application/pdf":
        return _ingest_pdf(data)

    if lower.endswith(tuple(DOC_EXTS)):
        return _ingest_doc(data, filename)

    if lower.endswith((".txt", ".md")) or content_type.startswith("text/"):
        return {
            "kind": "text",
            "text": data.decode("utf-8", "replace"),
            "needsVision": False,
            "pageCount": 1,
            "notes": [],
        }

    # Unknown extension: try PDF sniffing, then give up cleanly.
    if data[:5] == b"%PDF-":
        return _ingest_pdf(data)

    return {
        "kind": "unknown",
        "text": "",
        "needsVision": False,
        "pageCount": 0,
        "notes": ["Unsupported file type."],
        "error": "We can't read that file type. Try a PDF, Word file, or a photo.",
    }


def _ingest_pdf(data: bytes) -> dict[str, Any]:
    import fitz  # PyMuPDF

    notes: list[str] = []
    doc = fitz.open(stream=data, filetype="pdf")
    pages = doc.page_count
    raw = "\n".join(p.get_text("text") for p in doc)
    doc.close()

    density = len(raw.strip()) / max(pages, 1)
    if density < TEXT_DENSITY_FLOOR:
        return {
            "kind": "pdf-scanned",
            "text": raw.strip(),
            "needsVision": True,
            "pageCount": pages,
            "notes": ["Little or no text layer — likely a scan or photo export."],
        }

    # Text layer is real. Prefer Docling for reading order on multi-column
    # documents; its output is markdown, which preserves heading structure the
    # extraction model can use.
    text = raw
    try:
        text = _docling_text(data, "resume.pdf") or raw
    except Exception as e:  # noqa: BLE001 — never fail ingest on a parser hiccup
        log.warning("Docling unavailable or failed, using PyMuPDF text: %s", e)
        notes.append("Used basic extraction.")

    return {
        "kind": "pdf",
        "text": _tidy(text),
        "needsVision": False,
        "pageCount": pages,
        "notes": notes,
    }


def _ingest_doc(data: bytes, filename: str) -> dict[str, Any]:
    try:
        text = _docling_text(data, filename)
        if text:
            return {"kind": "doc", "text": _tidy(text), "needsVision": False,
                    "pageCount": 1, "notes": []}
    except Exception as e:  # noqa: BLE001
        log.warning("Docling failed on %s: %s", filename, e)

    # Fallback for .docx only; .doc and .rtf without Docling are not worth
    # hand-rolling, so we ask the user for a different format.
    if filename.lower().endswith(".docx"):
        try:
            from docx import Document

            d = Document(io.BytesIO(data))
            parts = [p.text for p in d.paragraphs]
            # Layout tables are common in Word resumes and their text is not in
            # `paragraphs`, so pull cells too or half the resume disappears.
            for table in d.tables:
                for row in table.rows:
                    parts.append(" | ".join(c.text.strip() for c in row.cells))
            return {"kind": "doc", "text": _tidy("\n".join(parts)),
                    "needsVision": False, "pageCount": 1,
                    "notes": ["Used basic Word extraction."]}
        except Exception as e:  # noqa: BLE001
            log.warning("python-docx fallback failed: %s", e)

    return {
        "kind": "doc", "text": "", "needsVision": False, "pageCount": 0,
        "notes": [], "error": "We couldn't read that document. A PDF usually works better.",
    }


def _docling_text(data: bytes, filename: str) -> str:
    """Docling gives a structured document with reconstructed reading order,
    exported as markdown so headings survive into the extraction prompt."""
    from docling.datamodel.base_models import DocumentStream
    from docling.document_converter import DocumentConverter

    converter = DocumentConverter()
    stream = DocumentStream(name=filename, stream=io.BytesIO(data))
    result = converter.convert(stream)
    return result.document.export_to_markdown()


_BLANKS = re.compile(r"\n{3,}")
_TRAILING = re.compile(r"[ \t]+$", re.MULTILINE)


def _tidy(text: str) -> str:
    text = _TRAILING.sub("", text)
    text = _BLANKS.sub("\n\n", text)
    return text.strip()[:200_000]
