"""docsvc — the document pipeline.

Owns everything that needs a real filesystem, a TeX engine, or Python's
document-parsing ecosystem: ingestion, LaTeX compilation, DOCX generation, and
ATS validation. The Next.js app owns everything else and calls in over HTTP.

Deliberately stateless: no database, no user model, no auth of its own. It
trusts a signed service token from the web app and nothing else.
"""

from __future__ import annotations

import base64
import json
import logging
import os
import time
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI, File, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .atslint.engine import lint
from .ingest.pipeline import ingest_file
from .models import RenderRequest, RenderResponse, Resume
from .render.docx import render_docx
from .render.latex_env import TEMPLATES_ROOT
from .render.pdf import (
    CompileError,
    UnsafeSourceError,
    compile_pdf,
    load_template,
    render_pdf,
    render_tex,
    resolve_options,
)

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
log = logging.getLogger("docsvc")

SERVICE_TOKEN = os.getenv("DOCSVC_TOKEN", "")
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_MB", "12")) * 1024 * 1024

_TEMPLATE_CACHE: dict[str, dict] = {}


def _scan_templates() -> dict[str, dict]:
    found: dict[str, dict] = {}
    if not TEMPLATES_ROOT.is_dir():
        return found
    for d in sorted(TEMPLATES_ROOT.iterdir()):
        # Directories starting with _ hold shared partials, not templates.
        if not d.is_dir() or d.name.startswith("_"):
            continue
        manifest = d / "template.json"
        if manifest.is_file():
            try:
                found[d.name] = json.loads(manifest.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                log.error("Bad manifest, skipping: %s", manifest)
    return found


@asynccontextmanager
async def lifespan(app: FastAPI):
    _TEMPLATE_CACHE.update(_scan_templates())
    log.info("Loaded %d template(s): %s",
             len(_TEMPLATE_CACHE), ", ".join(_TEMPLATE_CACHE))
    yield
    _TEMPLATE_CACHE.clear()


app = FastAPI(title="ResumeForge docsvc", version="0.1.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o for o in os.getenv("ALLOWED_ORIGINS", "").split(",") if o],
    allow_methods=["POST", "GET"],
    allow_headers=["*"],
)


async def require_token(x_service_token: str = Header(default="")) -> None:
    """The service is never exposed to browsers directly. Only the Next.js
    server calls it, so a shared secret is sufficient and simpler than JWT."""
    if not SERVICE_TOKEN:
        return  # local dev
    if x_service_token != SERVICE_TOKEN:
        raise HTTPException(status_code=401, detail="Bad service token")


@app.get("/health")
async def health() -> dict:
    return {"ok": True, "templates": len(_TEMPLATE_CACHE)}


@app.get("/templates", dependencies=[Depends(require_token)])
async def templates() -> dict:
    """The web app renders its template gallery and its design-options panel
    entirely from these manifests, so adding a template needs no UI change."""
    return {"templates": list(_TEMPLATE_CACHE.values())}


@app.post("/render/pdf", dependencies=[Depends(require_token)])
async def render_pdf_endpoint(req: RenderRequest) -> RenderResponse:
    try:
        pdf, tex, log_excerpt, ms = render_pdf(
            req.resume, req.template_id, req.template_version, req.options
        )
    except UnsafeSourceError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except CompileError as e:
        raise HTTPException(
            status_code=422,
            detail={"message": str(e), "log": e.log_excerpt},
        )
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))

    report = lint(req.resume, pdf) if req.run_lint else None

    return RenderResponse(
        format="pdf",
        artifactB64=base64.b64encode(pdf).decode(),
        durationMs=ms,
        ats=report,
        compileLogExcerpt=log_excerpt or None,
    )


@app.post("/render/docx", dependencies=[Depends(require_token)])
async def render_docx_endpoint(req: RenderRequest) -> RenderResponse:
    started = time.monotonic()
    try:
        spec = load_template(req.template_id, req.template_version)
        opts = resolve_options(spec, req.options)
    except FileNotFoundError:
        opts = {"accentColor": "#111111", "sectionRule": True, "showSummary": True}

    data = render_docx(req.resume, opts)
    return RenderResponse(
        format="docx",
        artifactB64=base64.b64encode(data).decode(),
        durationMs=int((time.monotonic() - started) * 1000),
        ats=None,  # DOCX ATS-safety is structural and asserted by the renderer
    )


@app.post("/render/tex", dependencies=[Depends(require_token)])
async def render_tex_endpoint(req: RenderRequest) -> dict:
    """Hand the user the LaTeX source when they eject to the manual editor."""
    try:
        tex, spec = render_tex(
            req.resume, req.template_id, req.template_version, req.options
        )
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return {"tex": tex, "templateId": spec.id, "templateVersion": spec.version}


@app.post("/compile/tex", dependencies=[Depends(require_token)])
async def compile_raw_tex(payload: dict) -> RenderResponse:
    """Compile user-authored LaTeX from the manual editor.

    This is the highest-risk endpoint in the system: arbitrary user LaTeX. It
    relies on assert_safe_tex plus the container sandbox described in
    SECURITY.md. Never enable this on a host that also holds secrets.
    """
    source = payload.get("tex", "")
    if not isinstance(source, str) or not source.strip():
        raise HTTPException(status_code=400, detail="No LaTeX source provided.")
    if len(source) > 400_000:
        raise HTTPException(status_code=413, detail="Source too large.")

    spec = load_template(payload.get("templateId", "ats-classic-single"))
    try:
        pdf, excerpt, ms = compile_pdf(source, spec)
    except UnsafeSourceError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except CompileError as e:
        raise HTTPException(status_code=422,
                            detail={"message": str(e), "log": e.log_excerpt})

    return RenderResponse(
        format="pdf",
        artifactB64=base64.b64encode(pdf).decode(),
        durationMs=ms,
        compileLogExcerpt=excerpt or None,
    )


@app.post("/lint", dependencies=[Depends(require_token)])
async def lint_endpoint(payload: dict) -> dict:
    """Score an existing PDF against a canonical resume. Also powers the
    standalone 'analyse my current resume' entry point."""
    try:
        resume = Resume.model_validate(payload["resume"])
        pdf = base64.b64decode(payload["pdfB64"])
    except (KeyError, ValueError) as e:
        raise HTTPException(status_code=400, detail=f"Bad payload: {e}")
    return lint(resume, pdf).model_dump(by_alias=True)


@app.post("/ingest", dependencies=[Depends(require_token)])
async def ingest_endpoint(file: UploadFile = File(...)) -> JSONResponse:
    """Upload -> text + layout hints + confidence.

    Returns raw material only. Turning it into a Resume is the web app's job,
    because that step needs the LLM and this service has no model credentials.
    """
    data = await file.read()
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File is too large.")
    if not data:
        raise HTTPException(status_code=400, detail="File is empty.")

    result = ingest_file(data, file.filename or "upload", file.content_type or "")
    return JSONResponse(result)
