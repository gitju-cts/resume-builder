r"""Jinja2 environment for LaTeX templating, plus escaping.

Two things break every naive LaTeX-templating pipeline, and both are handled here:

1. Jinja's default `{{ }}` and `{% %}` collide with TeX braces. We remap all
   delimiters to `\VAR{}` / `\BLOCK{}` which are unambiguous inside .tex.

2. Unescaped user text. "Ernst & Young" or "C#" or a 100% claim will hard-fail
   the compiler. `autoescape` is HTML-only and useless here, so escaping is a
   filter that MUST be applied to every interpolation. Templates are linted for
   raw `\VAR{x}` without a filter (see tests/test_templates.py).
"""

from __future__ import annotations

import re
from pathlib import Path

import jinja2

TEMPLATES_ROOT = Path(__file__).resolve().parents[2] / "templates"

# Order matters: backslash first, or we double-escape our own replacements.
_ESCAPES: list[tuple[str, str]] = [
    ("\\", r"\textbackslash{}"),
    ("&", r"\&"),
    ("%", r"\%"),
    ("$", r"\$"),
    ("#", r"\#"),
    ("_", r"\_"),
    ("{", r"\{"),
    ("}", r"\}"),
    ("~", r"\textasciitilde{}"),
    ("^", r"\textasciicircum{}"),
]

# Characters that routinely arrive from PDF extraction and Word autocorrect.
#
# Split into two passes, and the split is load-bearing. A replacement whose
# output contains a backslash MUST run *after* escaping, or the escape pass
# turns our own "\textrupee{}" into "\textbackslash{}textrupee\{\}". That bug
# is silent — it compiles and renders visible garbage.

# Pass 1, before escaping: output is plain characters only.
_UNICODE_PRE: list[tuple[str, str]] = [
    ("\u2018", "`"), ("\u2019", "'"),           # curly single quotes
    ("\u201c", "``"), ("\u201d", "''"),         # curly double quotes
    ("\u2013", "--"), ("\u2014", "---"),        # en/em dash -> TeX ligatures
    ("\u00a0", " "), ("\u202f", " "),           # nbsp, narrow nbsp
    ("\u2022", ""), ("\u25cf", ""), ("\u25aa", ""),  # stray bullet glyphs
    ("\ufb01", "fi"), ("\ufb02", "fl"),         # ligatures that break extraction
    ("\ufb03", "ffi"), ("\ufb04", "ffl"),
    ("\u200b", ""), ("\u200c", ""), ("\u200d", ""), ("\ufeff", ""),  # zero-width
    ("\u2011", "-"),                            # non-breaking hyphen
]

# Pass 2, after escaping: output contains LaTeX commands. None of these source
# characters are in _ESCAPES, so they survive the escape pass untouched and are
# safe to replace here.
_UNICODE_POST: list[tuple[str, str]] = [
    ("\u2026", r"\ldots{}"),                    # ellipsis
    ("\u20b9", r"\textrupee{}"),                # ₹ (textcomp)
    ("\u20ac", r"\texteuro{}"),                 # €
    ("\u00a3", r"\pounds{}"),                   # £
    ("\u00b0", r"\textdegree{}"),               # °
    ("\u2192", r"\textrightarrow{}"),           # →
    ("\u00d7", r"\texttimes{}"),                # ×
    ("\u2265", r"$\geq$"), ("\u2264", r"$\leq$"),
    ("\u00ae", r"\textregistered{}"),
    ("\u2122", r"\texttrademark{}"),
]

_MULTISPACE = re.compile(r"[ \t]{2,}")


def latex_escape(value: object) -> str:
    """Escape arbitrary user text for safe LaTeX interpolation."""
    if value is None:
        return ""
    text = str(value)

    # 1. plain-text normalisation
    for bad, good in _UNICODE_PRE:
        text = text.replace(bad, good)

    # 2. escape TeX specials
    for bad, good in _ESCAPES:
        text = text.replace(bad, good)

    # 3. only now insert LaTeX commands, so step 2 can't mangle them
    for bad, good in _UNICODE_POST:
        text = text.replace(bad, good)

    text = _MULTISPACE.sub(" ", text)
    return text.strip()


def latex_url(value: object) -> str:
    """Escape a URL for \\href. Percent and hash must survive as-is inside the
    href target, so this is deliberately weaker than latex_escape and must only
    ever be used in a URL position."""
    if value is None:
        return ""
    text = str(value).strip()
    for bad, good in [("\\", ""), ("{", ""), ("}", ""), ("%", r"\%"), ("#", r"\#")]:
        text = text.replace(bad, good)
    return text


_MONTHS = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
]


def fmt_month(value: str | None) -> str:
    """YYYY-MM -> 'Mar 2024'. YYYY -> '2024'. 'present' -> 'Present'.

    One consistent, parseable date format across every template. ATS parsers
    key off recognisable month tokens; '03/2024' and '2024.03' both parse worse.
    """
    if not value:
        return ""
    v = str(value).strip()
    if v.lower() in {"present", "current", "now", "till date", "ongoing"}:
        return "Present"
    parts = v.split("-")
    if len(parts) == 1:
        return parts[0]
    try:
        month = _MONTHS[int(parts[1]) - 1]
    except (ValueError, IndexError):
        return parts[0]
    return f"{month} {parts[0]}"


def fmt_range(dates: object) -> str:
    """Render a DateRange as 'Mar 2022 -- Present'."""
    if dates is None:
        return ""
    start = getattr(dates, "start", None) or (dates.get("start") if isinstance(dates, dict) else None)
    end = getattr(dates, "end", None) or (dates.get("end") if isinstance(dates, dict) else None)
    left = fmt_month(start)
    right = fmt_month(end)
    if left and right:
        return f"{left} -- {right}"
    return left or right or ""


def build_env(template_dir: Path | None = None) -> jinja2.Environment:
    """Jinja2 configured so nothing collides with TeX syntax.

    The search path always includes the templates root so a template can do
    `\BLOCK{ extends '_shared/base.tex.j2' }`. Twelve templates that each carry
    their own copy of the preamble would be twelve places to fix the next
    escaping bug; one base plus twelve overrides is one place.
    """
    search = [str(TEMPLATES_ROOT)]
    if template_dir:
        search.insert(0, str(template_dir))
    loader = jinja2.FileSystemLoader(search)
    env = jinja2.Environment(
        loader=loader,
        block_start_string=r"\BLOCK{",
        block_end_string="}",
        variable_start_string=r"\VAR{",
        variable_end_string="}",
        comment_start_string=r"\#{",
        comment_end_string="}",
        line_statement_prefix="%%JINJA",
        trim_blocks=True,
        lstrip_blocks=True,
        autoescape=False,          # HTML escaping would be actively wrong here
        undefined=jinja2.StrictUndefined,  # fail loudly, never render "None"
    )
    env.filters["tex"] = latex_escape
    env.filters["texurl"] = latex_url
    env.filters["month"] = fmt_month
    env.filters["daterange"] = fmt_range
    return env
