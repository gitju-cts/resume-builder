"""Resume JSON -> LaTeX -> PDF.

Compilation runs as an untrusted subprocess. Even for our own templates the
input is user text, and once the LaTeX editor panel ships the *source itself*
is user-controlled. LaTeX is Turing-complete and can read and write files, so
every compile is treated as hostile code execution. See SECURITY.md.
"""

from __future__ import annotations

import json
import logging
import os
import re
import resource
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

from ..models import Resume, TemplateOptions
from .latex_env import TEMPLATES_ROOT, build_env

log = logging.getLogger(__name__)

COMPILE_TIMEOUT_S = int(os.getenv("COMPILE_TIMEOUT_S", "20"))
COMPILE_MEM_BYTES = int(os.getenv("COMPILE_MEM_MB", "512")) * 1024 * 1024
MAX_OUTPUT_BYTES = int(os.getenv("MAX_OUTPUT_MB", "10")) * 1024 * 1024
TECTONIC_BIN = os.getenv("TECTONIC_BIN", "tectonic")

# Rejected before we ever hand source to the engine. Belt-and-braces alongside
# the container sandbox, never instead of it.
FORBIDDEN_TEX = [
    re.compile(r"\\write18"),
    re.compile(r"\\immediate\s*\\write"),
    re.compile(r"\\openout"),
    re.compile(r"\\openin"),
    re.compile(r"\\input\s*\{?\s*/"),
    re.compile(r"\\include\s*\{?\s*/"),
    re.compile(r"\\catcode\s*`?\\?\\\\"),
    re.compile(r"\\directlua"),
    re.compile(r"\\shellescape"),
    re.compile(r"\\usepackage\s*\{\s*shellesc\s*\}"),
    re.compile(r"\\ShellEscape"),
    re.compile(r"\.\./"),
]


class CompileError(RuntimeError):
    def __init__(self, message: str, log_excerpt: str = ""):
        super().__init__(message)
        self.log_excerpt = log_excerpt


class UnsafeSourceError(ValueError):
    pass


@dataclass
class TemplateSpec:
    id: str
    version: str
    dir: Path
    manifest: dict

    @property
    def entry(self) -> str:
        return "main.tex.j2"


def load_template(template_id: str, version: str | None = None) -> TemplateSpec:
    tdir = TEMPLATES_ROOT / template_id
    manifest_path = tdir / "template.json"
    if not manifest_path.is_file():
        raise FileNotFoundError(f"Unknown template: {template_id}")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if version and manifest.get("version") != version:
        # Resumes are version-pinned. A silent upgrade would change a document
        # the user already downloaded and approved.
        raise FileNotFoundError(
            f"Template {template_id} v{version} not available "
            f"(have v{manifest.get('version')}). Pinned versions must be kept."
        )
    return TemplateSpec(template_id, manifest["version"], tdir, manifest)


# --- option resolution ------------------------------------------------------

# Referenced by _shared/base.tex.j2. A manifest may override any of these, but
# the base must never hit StrictUndefined because a template chose not to expose
# a control.
_UNIVERSAL_DEFAULTS: dict = {
    "accentColor": "#111111",
    "fontFamily": "charter",
    "sectionRule": True,
    "density": "normal",
    "showSummary": True,
    "headingCase": "upper",     # upper | title
    "nameSize": "LARGE",        # Large | LARGE | huge
    "nameAlign": "left",        # left | center
    "contactStyle": "pipes",    # pipes | lines
    "ruleWeight": 0.6,
    "sectionSpread": False,     # heading on its own line, wide tracking
    "bulletChar": "textbullet",  # textbullet | textendash | none
    "twoColumn": False,
    "leftRailWidth": 0.32,
    "pageLimitHint": 1,
}

_DENSITY = {
    "airy":    dict(margin=20, fontsize=11, sectionSpaceBefore=2.6, sectionSpaceAfter=1.1,
                    listTopSep=0.5, listItemSep=0.45, entryGap=1.2),
    "normal":  dict(margin=16, fontsize=10, sectionSpaceBefore=2.0, sectionSpaceAfter=0.8,
                    listTopSep=0.3, listItemSep=0.25, entryGap=0.9),
    "compact": dict(margin=13, fontsize=10, sectionSpaceBefore=1.5, sectionSpaceAfter=0.5,
                    listTopSep=0.15, listItemSep=0.1,  entryGap=0.6),
}


def resolve_options(spec: TemplateSpec, user_opts: TemplateOptions) -> dict:
    """Merge user choices over manifest defaults, then expand derived values.

    The manifest is authoritative for what options exist, so a template can add
    a control without any code change here.
    """
    declared = spec.manifest.get("options", {})
    supplied = user_opts.model_dump(by_alias=True, exclude_none=True)

    # Layer order: universal defaults, then manifest fixed values, then the
    # manifest's declared option defaults, then what the user actually chose.
    resolved: dict = dict(_UNIVERSAL_DEFAULTS)
    resolved.update(spec.manifest.get("fixed", {}))

    for key, meta in declared.items():
        value = supplied.get(key, meta.get("default"))
        if meta.get("type") == "enum" and value not in meta.get("values", []):
            value = meta.get("default")
        resolved[key] = value

    density = _DENSITY.get(resolved.get("density", "normal"), _DENSITY["normal"])
    # Manifest density overrides win over the density preset, so a template can
    # pin a tighter margin than any preset offers.
    for k, v in density.items():
        resolved.setdefault(k, v)
    for k, v in spec.manifest.get("fixed", {}).items():
        resolved[k] = v

    accent = str(resolved.get("accentColor", "#111111")).lstrip("#")
    if not re.fullmatch(r"[0-9A-Fa-f]{6}", accent):
        accent = "111111"
    resolved["accentHex"] = accent.upper()

    return resolved


# --- tex generation ---------------------------------------------------------

def render_tex(resume: Resume, template_id: str, version: str | None,
               options: TemplateOptions) -> tuple[str, TemplateSpec]:
    spec = load_template(template_id, version)
    env = build_env(spec.dir)
    template = env.get_template(spec.entry)
    opt = resolve_options(spec, options)

    tex = template.render(resume=resume, opt=opt)
    assert_safe_tex(tex)
    return tex, spec


def assert_safe_tex(source: str) -> None:
    for pattern in FORBIDDEN_TEX:
        if pattern.search(source):
            raise UnsafeSourceError(
                "This document uses a LaTeX command we don't allow "
                "(file or shell access). Remove it and compile again."
            )


# --- compilation ------------------------------------------------------------

def _limits() -> None:
    """Applied in the child process, after fork, before exec."""
    resource.setrlimit(resource.RLIMIT_CPU, (COMPILE_TIMEOUT_S, COMPILE_TIMEOUT_S))
    resource.setrlimit(resource.RLIMIT_AS, (COMPILE_MEM_BYTES, COMPILE_MEM_BYTES))
    resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_OUTPUT_BYTES, MAX_OUTPUT_BYTES))
    resource.setrlimit(resource.RLIMIT_NPROC, (32, 32))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))


def compile_pdf(tex: str, spec: TemplateSpec) -> tuple[bytes, str, int]:
    """Compile in a scratch dir that is destroyed afterwards.

    Returns (pdf_bytes, log_excerpt, duration_ms).
    """
    assert_safe_tex(tex)
    started = time.monotonic()

    workdir = Path(tempfile.mkdtemp(prefix="rf-compile-", dir=os.getenv("COMPILE_TMPDIR", "/tmp")))
    try:
        (workdir / "main.tex").write_text(tex, encoding="utf-8")

        cmd = [
            TECTONIC_BIN,
            "-X", "compile", "main.tex",
            "--outdir", str(workdir),
            "--keep-logs",
            "--untrusted",          # refuses shell-escape and \write18 outright
            "--chatter", "minimal",
        ]
        if os.getenv("TECTONIC_BUNDLE"):
            cmd += ["--bundle", os.environ["TECTONIC_BUNDLE"]]

        env = {
            "PATH": "/usr/local/bin:/usr/bin:/bin",
            "HOME": str(workdir),
            "TEXMFHOME": str(workdir / "texmf"),
            "TECTONIC_CACHE_DIR": os.getenv("TECTONIC_CACHE_DIR", "/opt/tectonic-cache"),
            "SOURCE_DATE_EPOCH": "1700000000",  # reproducible output
        }

        try:
            proc = subprocess.run(
                cmd,
                cwd=workdir,
                capture_output=True,
                timeout=COMPILE_TIMEOUT_S,
                preexec_fn=_limits,
                env=env,
                check=False,
            )
        except subprocess.TimeoutExpired:
            raise CompileError(
                "The document took too long to build. This usually means a very "
                "long entry or an unclosed brace in custom LaTeX."
            )

        raw_log = (proc.stderr or b"").decode("utf-8", "replace")
        excerpt = friendly_log(raw_log)

        pdf_path = workdir / "main.pdf"
        if proc.returncode != 0 or not pdf_path.is_file():
            raise CompileError("The document failed to build.", excerpt)

        pdf = pdf_path.read_bytes()
        if len(pdf) > MAX_OUTPUT_BYTES:
            raise CompileError("The generated file is unexpectedly large.")

        return pdf, excerpt, int((time.monotonic() - started) * 1000)
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


_PATH_LEAK = re.compile(r"(/[\w./-]*(?:tmp|home|opt|usr)[\w./-]*)")


def friendly_log(raw: str) -> str:
    """Never surface raw engine logs — they leak container paths and confuse
    non-technical users. Keep only the error lines, scrub paths."""
    keep = [
        line for line in raw.splitlines()
        if line.startswith("!") or "Error" in line or "Undefined control sequence" in line
    ]
    text = "\n".join(keep[:12]) or "No specific error reported by the engine."
    return _PATH_LEAK.sub("[path]", text)[:2000]


def render_pdf(resume: Resume, template_id: str, version: str | None,
               options: TemplateOptions) -> tuple[bytes, str, str, int]:
    """Full path. Returns (pdf, tex, log_excerpt, duration_ms)."""
    tex, spec = render_tex(resume, template_id, version, options)
    pdf, excerpt, ms = compile_pdf(tex, spec)
    return pdf, tex, excerpt, ms
