"""Resume JSON -> DOCX, rendered independently of the LaTeX path.

This file deliberately does NOT convert the LaTeX output. Every LaTeX->DOCX
converter emits text boxes and irregular spacing, and text boxes are among the
structures ATS parsers handle worst — converting would turn a safe document
into an unsafe one. So: one data model, two independent renderers.

Constraints enforced here, all of them for parser reasons:
  - real Heading styles, so section detection works
  - single column, linear flow: no tables, no text boxes, no columns
  - contact details in the body, never in a header (parsers skip headers)
  - real list styles, not typed bullet glyphs
  - one date format, matching the PDF renderer exactly
  - widely available fonts only, no icon fonts
"""

from __future__ import annotations

import io

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

from ..models import Resume
from .latex_env import fmt_range

BODY_FONT = "Calibri"
HEADING_FONT = "Calibri"
INK = RGBColor(0x11, 0x11, 0x11)
MUTED = RGBColor(0x44, 0x44, 0x44)


def _configure_styles(doc: Document, accent: RGBColor) -> None:
    normal = doc.styles["Normal"]
    normal.font.name = BODY_FONT
    normal.font.size = Pt(10.5)
    normal.font.color.rgb = INK
    # East-Asian font mapping, or Word substitutes unpredictably
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), BODY_FONT)
    pf = normal.paragraph_format
    pf.space_before = Pt(0)
    pf.space_after = Pt(2)
    pf.line_spacing = 1.08

    for name, size, color, before in (
        ("Heading 1", 20, accent, 0),
        ("Heading 2", 12, accent, 10),
        ("Heading 3", 10.5, INK, 6),
    ):
        st = doc.styles[name]
        st.font.name = HEADING_FONT
        st.font.size = Pt(size)
        st.font.bold = True
        st.font.color.rgb = color
        st.font.all_caps = name == "Heading 2"
        st.paragraph_format.space_before = Pt(before)
        st.paragraph_format.space_after = Pt(2)
        st.paragraph_format.keep_with_next = True


def _bottom_border(paragraph, hex_color: str = "111111") -> None:
    """A paragraph border, not a table and not a drawn line — a border is
    invisible to text extraction, a table is not."""
    p_pr = paragraph._p.get_or_add_pPr()
    borders = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), hex_color)
    borders.append(bottom)
    p_pr.append(borders)


def _tab_right(paragraph, position_twips: int = 9360) -> None:
    """Right-aligned tab stop so 'Role .......... Dates' needs no table."""
    p_pr = paragraph._p.get_or_add_pPr()
    tabs = OxmlElement("w:tabs")
    tab = OxmlElement("w:tab")
    tab.set(qn("w:val"), "right")
    tab.set(qn("w:pos"), str(position_twips))
    tabs.append(tab)
    p_pr.append(tabs)


def _entry_line(doc: Document, left_bold: str, right: str,
                sub_left: str = "", sub_right: str = "") -> None:
    p = doc.add_paragraph()
    p.paragraph_format.keep_with_next = True
    _tab_right(p)
    run = p.add_run(left_bold)
    run.bold = True
    if right:
        p.add_run("\t" + right)

    if sub_left or sub_right:
        q = doc.add_paragraph()
        q.paragraph_format.keep_with_next = True
        _tab_right(q)
        r = q.add_run(sub_left)
        r.italic = True
        if sub_right:
            r2 = q.add_run("\t" + sub_right)
            r2.italic = True
            r2.font.color.rgb = MUTED


def _bullets(doc: Document, texts: list[str]) -> None:
    for t in texts:
        if not t.strip():
            continue
        p = doc.add_paragraph(t.strip(), style="List Bullet")
        p.paragraph_format.space_after = Pt(1)


def _section_heading(doc: Document, text: str, rule: bool, accent_hex: str) -> None:
    h = doc.add_heading(text, level=2)
    if rule:
        _bottom_border(h, accent_hex)


def render_docx(resume: Resume, options: dict | None = None) -> bytes:
    options = options or {}
    accent_hex = str(options.get("accentColor", "#111111")).lstrip("#") or "111111"
    if len(accent_hex) != 6:
        accent_hex = "111111"
    accent = RGBColor.from_string(accent_hex.upper())
    rule = bool(options.get("sectionRule", True))

    doc = Document()
    _configure_styles(doc, accent)

    for s in doc.sections:
        s.top_margin = s.bottom_margin = Pt(40)
        s.left_margin = s.right_margin = Pt(46)

    b = resume.basics

    # --- header, in the body ------------------------------------------------
    name_p = doc.add_paragraph()
    name_p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    name_run = name_p.add_run(b.name)
    name_run.font.size = Pt(20)
    name_run.bold = True
    name_run.font.color.rgb = accent

    if b.headline:
        hp = doc.add_paragraph(b.headline)
        hp.runs[0].font.size = Pt(11)

    contact_bits = [x for x in (b.location, b.phone, b.email) if x]
    contact_bits += [f"{l.label}: {l.url}" for l in b.links]
    if contact_bits:
        cp = doc.add_paragraph(" | ".join(contact_bits))
        cp.runs[0].font.size = Pt(9.5)
        cp.runs[0].font.color.rgb = MUTED
        cp.paragraph_format.space_after = Pt(6)

    # --- summary -----------------------------------------------------------
    if resume.summary and options.get("showSummary", True):
        _section_heading(doc, "Summary", rule, accent_hex)
        doc.add_paragraph(resume.summary.text)

    # --- body sections, in canonical order ---------------------------------
    for sec in resume.sections:
        if sec.kind == "experience" and sec.items:
            _section_heading(doc, sec.heading, rule, accent_hex)
            for item in sec.items:
                _entry_line(
                    doc,
                    item.role,
                    fmt_range(item.dates),
                    item.org,
                    item.location or "",
                )
                _bullets(doc, [x.text for x in item.bullets])

        elif sec.kind == "education" and sec.items:
            _section_heading(doc, sec.heading, rule, accent_hex)
            for item in sec.items:
                degree = item.degree + (f", {item.field}" if item.field else "")
                _entry_line(
                    doc,
                    degree,
                    fmt_range(item.dates) if item.dates else "",
                    item.institution,
                    item.location or "",
                )
                if item.score:
                    sp = doc.add_paragraph(item.score)
                    sp.runs[0].font.size = Pt(9.5)
                _bullets(doc, [x.text for x in item.details])

        elif sec.kind == "skills" and sec.groups:
            _section_heading(doc, sec.heading, rule, accent_hex)
            for g in sec.groups:
                p = doc.add_paragraph()
                lab = p.add_run(f"{g.label}: ")
                lab.bold = True
                p.add_run(", ".join(g.items))

        elif getattr(sec, "items", None):
            _section_heading(doc, sec.heading, rule, accent_hex)
            for item in sec.items:
                title = item.title + (f" — {item.org}" if item.org else "")
                _entry_line(
                    doc,
                    title,
                    fmt_range(item.dates) if item.dates else "",
                    item.subtitle or "",
                    "",
                )
                if item.url:
                    up = doc.add_paragraph(item.url)
                    up.runs[0].font.size = Pt(9)
                    up.runs[0].font.color.rgb = MUTED
                _bullets(doc, [x.text for x in item.bullets])

    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()
