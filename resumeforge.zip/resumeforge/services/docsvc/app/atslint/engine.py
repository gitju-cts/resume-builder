"""ATS validation by round-trip.

The claim "ATS-friendly" is worthless unless measured. So: render the PDF, then
re-extract it with a parser that had no part in building it, and diff what came
back against the canonical JSON. Field recovery rate is the score.

This is deliberately adversarial toward our own renderer. A template that looks
beautiful and loses the phone number should score badly and say so.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field

import fitz  # PyMuPDF

from ..models import AtsReport, LintFinding, Resume

# Weights sum to 100. Contact details and employment history are what an ATS
# actually populates its database from, so they carry the most.
W_CONTACT = 30
W_EMPLOYMENT = 30
W_EDUCATION = 15
W_SKILLS = 10
W_STRUCTURE = 15


@dataclass
class Extraction:
    text: str
    blocks: list[tuple[float, float, str]] = field(default_factory=list)
    page_count: int = 0
    fonts_embedded: bool = True
    has_text_layer: bool = True


def extract(pdf_bytes: bytes) -> Extraction:
    """Independent re-extraction. PyMuPDF in 'text' mode approximates what a
    mainstream parser sees, including its reading-order guess."""
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    chunks: list[str] = []
    blocks: list[tuple[float, float, str]] = []
    embedded = True

    for page in doc:
        chunks.append(page.get_text("text"))
        for b in page.get_text("blocks"):
            x0, y0, _x1, _y1, btext = b[0], b[1], b[2], b[3], b[4]
            if btext.strip():
                blocks.append((y0, x0, btext.strip()))
        for fontinfo in page.get_fonts(full=True):
            # index 3 is the basefont name; a null xref means not embedded
            if fontinfo[0] == 0:
                embedded = False

    text = "\n".join(chunks)
    result = Extraction(
        text=text,
        blocks=blocks,
        page_count=doc.page_count,
        fonts_embedded=embedded,
        has_text_layer=len(text.strip()) > 50,
    )
    doc.close()
    return result


def _norm(s: str) -> str:
    """Fold for comparison: strip accents, collapse whitespace, lowercase.
    Extraction routinely mangles spacing, and we care whether the *information*
    survived, not whether the bytes match."""
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = re.sub(r"[\s\u00a0]+", " ", s)
    return s.strip().lower()


def _present(needle: str, haystack: str, min_len: int = 3) -> bool:
    n = _norm(needle)
    if len(n) < min_len:
        return False
    if n in haystack:
        return True
    # Extraction sometimes injects spaces mid-token; retry with spaces removed.
    return n.replace(" ", "") in haystack.replace(" ", "")


PHONE_RE = re.compile(r"(?:\+?\d[\d\s\-()]{7,}\d)")
EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+")


def lint(resume: Resume, pdf_bytes: bytes) -> AtsReport:
    ex = extract(pdf_bytes)
    hay = _norm(ex.text)
    findings: list[LintFinding] = []

    # ---------------------------------------------------------------- 1. text layer
    if not ex.has_text_layer:
        findings.append(LintFinding(
            code="NO_TEXT_LAYER", severity="error",
            message="This PDF has no readable text — an ATS would see a blank page.",
        ))
        return AtsReport(score=0, grade="F", fieldRecovery=0.0,
                         readingOrderOk=False, findings=findings,
                         recoveredTextChars=0)

    # ---------------------------------------------------------------- 2. contact
    contact_checks: list[tuple[str, str | None]] = [
        ("name", resume.basics.name),
        ("email", resume.basics.email),
        ("phone", resume.basics.phone),
    ]
    contact_hits = 0
    contact_total = 0
    for label, value in contact_checks:
        if not value:
            continue
        contact_total += 1
        if _present(value, hay):
            contact_hits += 1
        else:
            findings.append(LintFinding(
                code=f"LOST_{label.upper()}", severity="error",
                message=f"Your {label} didn't survive extraction. "
                        f"An ATS may file this application with no {label}.",
                field=f"basics.{label}",
            ))

    if resume.basics.email and not EMAIL_RE.search(ex.text):
        findings.append(LintFinding(
            code="EMAIL_NOT_PATTERN", severity="error",
            message="Your email came out broken across characters, so automatic "
                    "detection will miss it.",
            field="basics.email",
        ))
    if resume.basics.phone and not PHONE_RE.search(ex.text):
        findings.append(LintFinding(
            code="PHONE_NOT_PATTERN", severity="warning",
            message="Your phone number came out in a form automatic detection may miss.",
            field="basics.phone",
        ))

    contact_score = W_CONTACT * (contact_hits / contact_total) if contact_total else W_CONTACT

    # ---------------------------------------------------------------- 3. employment
    emp_hits = emp_total = 0
    exp = resume.section("experience")
    if exp:
        for item in exp.items:  # type: ignore[union-attr]
            for label, value in (("role", item.role), ("org", item.org)):
                emp_total += 1
                if _present(value, hay):
                    emp_hits += 1
                else:
                    findings.append(LintFinding(
                        code="LOST_EMPLOYMENT_FIELD", severity="error",
                        message=f"'{value}' didn't survive extraction.",
                        field=f"experience.{label}",
                    ))
            for b in item.bullets:
                emp_total += 1
                # First six words is enough to know the line survived intact.
                head = " ".join(b.text.split()[:6])
                if _present(head, hay, min_len=8):
                    emp_hits += 1
    emp_score = W_EMPLOYMENT * (emp_hits / emp_total) if emp_total else W_EMPLOYMENT

    # ---------------------------------------------------------------- 4. education
    edu_hits = edu_total = 0
    edu = resume.section("education")
    if edu:
        for item in edu.items:  # type: ignore[union-attr]
            for value in (item.degree, item.institution):
                edu_total += 1
                if _present(value, hay):
                    edu_hits += 1
    edu_score = W_EDUCATION * (edu_hits / edu_total) if edu_total else W_EDUCATION

    # ---------------------------------------------------------------- 5. skills
    sk_hits = sk_total = 0
    sk = resume.section("skills")
    if sk:
        for g in sk.groups:  # type: ignore[union-attr]
            for s in g.items:
                sk_total += 1
                if _present(s, hay, min_len=2):
                    sk_hits += 1
    sk_score = W_SKILLS * (sk_hits / sk_total) if sk_total else W_SKILLS
    if sk_total and sk_hits / sk_total < 0.9:
        findings.append(LintFinding(
            code="SKILLS_LOSSY", severity="warning",
            message="Some skills didn't extract cleanly. Skills in columns or "
                    "tables are the most common cause.",
            field="skills",
        ))

    # ---------------------------------------------------------------- 6. structure
    structure_score = float(W_STRUCTURE)
    order_ok = reading_order_ok(ex)
    if not order_ok:
        structure_score -= 8
        findings.append(LintFinding(
            code="READING_ORDER", severity="error",
            message="Text comes out in a jumbled order. Multi-column layouts do "
                    "this. A single-column template will fix it.",
        ))

    if not ex.fonts_embedded:
        structure_score -= 3
        findings.append(LintFinding(
            code="FONTS_NOT_EMBEDDED", severity="warning",
            message="Some fonts aren't embedded, which can garble characters "
                    "on other machines.",
        ))

    if ex.page_count > 2:
        structure_score -= 2
        findings.append(LintFinding(
            code="LONG_DOCUMENT", severity="info",
            message=f"{ex.page_count} pages. Most recruiters read one or two.",
        ))

    if _has_conventional_headings(hay) is False:
        structure_score -= 4
        findings.append(LintFinding(
            code="UNCONVENTIONAL_HEADINGS", severity="warning",
            message="Section names aren't the standard ones. Parsers look for "
                    "'Experience', 'Education', 'Skills'.",
        ))

    if resume.basics.legacy and any(
        getattr(resume.basics.legacy, f) for f in ("photo_url", "dob", "marital_status")
    ):
        findings.append(LintFinding(
            code="LEGACY_FIELDS_EXCLUDED", severity="info",
            message="We've left out your photo and personal details like date of "
                    "birth. Hiring software can't read photos, and many employers "
                    "must discard applications containing these.",
        ))

    structure_score = max(0.0, structure_score)

    # ---------------------------------------------------------------- total
    total = contact_score + emp_score + edu_score + sk_score + structure_score
    score = int(round(total))

    all_hits = contact_hits + emp_hits + edu_hits + sk_hits
    all_total = contact_total + emp_total + edu_total + sk_total
    recovery = (all_hits / all_total) if all_total else 1.0

    return AtsReport(
        score=score,
        grade=grade_for(score, findings),
        fieldRecovery=round(recovery, 4),
        readingOrderOk=order_ok,
        findings=findings,
        recoveredTextChars=len(ex.text),
    )


def reading_order_ok(ex: Extraction) -> bool:
    """Detect column interleaving.

    In a single-column document, blocks sorted by natural extraction order are
    already sorted top-to-bottom. If sorting by y changes the sequence a lot,
    the extractor was jumping between columns.
    """
    if len(ex.blocks) < 4:
        return True
    natural = list(range(len(ex.blocks)))
    by_y = sorted(natural, key=lambda i: (round(ex.blocks[i][0], 1), ex.blocks[i][1]))
    inversions = sum(1 for a, b in zip(natural, by_y) if a != b)
    return (inversions / len(natural)) < 0.25


CONVENTIONAL = [
    "experience", "employment", "work history",
    "education", "qualification",
    "skills", "technical skills",
]


def _has_conventional_headings(hay: str) -> bool:
    return sum(1 for c in CONVENTIONAL if c in hay) >= 2


def grade_for(score: int, findings: list[LintFinding]) -> str:
    """An error-level finding caps the grade regardless of score. Losing the
    phone number is not something a high score elsewhere should paper over."""
    has_error = any(f.severity == "error" for f in findings)
    if has_error:
        return "C" if score >= 70 else "F"
    if score >= 93:
        return "A"
    if score >= 82:
        return "B"
    if score >= 70:
        return "C"
    return "F"
