"""Pydantic mirror of schema/resume.schema.json.

Regenerate with `make schema` (datamodel-code-generator). CI fails on drift
against the TypeScript side — one schema, two languages, no divergence.
"""

from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, ConfigDict, Field, model_validator

Origin = Literal["user", "extracted", "ai-rewritten"]

Situation = Literal[
    "career-switcher",
    "returning-after-gap",
    "biodata-upgrade",
    "academic-cv",
    "internship-seeker",
    "first-job-no-experience",
    "standard",
]

Seniority = Literal["fresher", "entry", "mid", "senior", "lead", "executive"]


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Bullet(Strict):
    id: str
    text: str
    origin: Origin
    source_id: str | None = Field(default=None, alias="sourceId")
    source_text: str | None = Field(default=None, alias="sourceText")
    # Set by enforceProvenance() in the web app when a claimed rewrite could not
    # be traced to a source. Must exist here too: extra="forbid" means an
    # unknown field is a hard rejection, so omitting it would make the render
    # service 422 on exactly the documents that most need rendering.
    needs_review: bool | None = Field(default=None, alias="needsReview")

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    @model_validator(mode="after")
    def _rewritten_needs_source(self) -> "Bullet":
        if self.origin == "ai-rewritten" and not self.source_id:
            raise ValueError(
                "ai-rewritten bullets must carry sourceId. The model may "
                "rephrase existing experience; it may not invent it."
            )
        return self


class DateRange(Strict):
    start: str = Field(pattern=r"^\d{4}(-\d{2})?$")
    end: str | None = None


class ExperienceItem(Strict):
    id: str
    role: str
    org: str
    location: str | None = None
    dates: DateRange
    bullets: list[Bullet] = Field(default_factory=list)


class EducationItem(Strict):
    id: str
    degree: str
    field: str | None = None
    institution: str
    location: str | None = None
    dates: DateRange | None = None
    score: str | None = None
    details: list[Bullet] = Field(default_factory=list)


class SkillGroup(Strict):
    label: str
    items: list[str]


class GenericItem(Strict):
    id: str
    title: str
    subtitle: str | None = None
    org: str | None = None
    dates: DateRange | None = None
    url: str | None = None
    bullets: list[Bullet] = Field(default_factory=list)


class ExperienceSection(Strict):
    id: str
    kind: Literal["experience"]
    heading: str = "Work Experience"
    items: list[ExperienceItem]


class EducationSection(Strict):
    id: str
    kind: Literal["education"]
    heading: str = "Education"
    items: list[EducationItem]


class SkillsSection(Strict):
    id: str
    kind: Literal["skills"]
    heading: str = "Skills"
    groups: list[SkillGroup]


class GenericSection(Strict):
    id: str
    kind: Literal[
        "projects",
        "certifications",
        "publications",
        "awards",
        "languages",
        "volunteering",
        "extracurricular",
        "custom",
    ]
    heading: str
    items: list[GenericItem]


Section = Annotated[
    Union[ExperienceSection, EducationSection, SkillsSection, GenericSection],
    Field(discriminator="kind"),
]


class Link(Strict):
    label: str
    url: str


class LegacyBiodata(Strict):
    """Captured so the user's data is never silently dropped, but excluded from
    every ATS template. Photos are unparseable by ATS; DOB, parentage, marital
    status, religion and caste create discrimination-law exposure for the
    employer in most jurisdictions, so many will discard the application."""

    photo_url: str | None = Field(default=None, alias="photoUrl")
    father_name: str | None = Field(default=None, alias="fatherName")
    mother_name: str | None = Field(default=None, alias="motherName")
    dob: str | None = None
    marital_status: str | None = Field(default=None, alias="maritalStatus")
    nationality: str | None = None
    gender: str | None = None
    religion: str | None = None
    caste: str | None = None
    full_address: str | None = Field(default=None, alias="fullAddress")

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class Basics(Strict):
    name: str = Field(min_length=1)
    headline: str | None = None
    email: str | None = None
    phone: str | None = None
    location: str | None = None
    links: list[Link] = Field(default_factory=list)
    legacy: LegacyBiodata | None = None


class Summary(Strict):
    text: str
    origin: Origin


class Meta(Strict):
    locale: str = "en-IN"
    target_role: str | None = Field(default=None, alias="targetRole")
    jd_id: str | None = Field(default=None, alias="jdId")
    situation: Situation = "standard"
    role_family: str | None = Field(default=None, alias="roleFamily")
    seniority: Seniority | None = None

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class Resume(Strict):
    schema_version: Literal["1.0"] = Field(default="1.0", alias="schemaVersion")
    meta: Meta = Field(default_factory=Meta)
    basics: Basics
    summary: Summary | None = None
    sections: list[Section] = Field(default_factory=list)

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    def section(self, kind: str) -> Section | None:
        for s in self.sections:
            if s.kind == kind:
                return s
        return None


# ---------------------------------------------------------------------------
# Render / lint contracts
# ---------------------------------------------------------------------------


class TemplateOptions(Strict):
    accent_color: str | None = Field(default=None, alias="accentColor")
    font_family: str | None = Field(default=None, alias="fontFamily")
    section_rule: bool | None = Field(default=None, alias="sectionRule")
    density: str | None = None

    model_config = ConfigDict(extra="allow", populate_by_name=True)


class RenderRequest(Strict):
    resume: Resume
    template_id: str = Field(alias="templateId")
    template_version: str | None = Field(default=None, alias="templateVersion")
    options: TemplateOptions = Field(default_factory=TemplateOptions)
    run_lint: bool = Field(default=True, alias="runLint")

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class LintFinding(Strict):
    code: str
    severity: Literal["error", "warning", "info"]
    message: str
    field: str | None = None


class AtsReport(Strict):
    score: int
    grade: Literal["A", "B", "C", "F"]
    field_recovery: float = Field(alias="fieldRecovery")
    reading_order_ok: bool = Field(alias="readingOrderOk")
    findings: list[LintFinding] = Field(default_factory=list)
    recovered_text_chars: int = Field(default=0, alias="recoveredTextChars")

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class RenderResponse(Strict):
    format: Literal["pdf", "docx", "tex"]
    artifact_b64: str = Field(alias="artifactB64")
    duration_ms: int = Field(alias="durationMs")
    ats: AtsReport | None = None
    compile_log_excerpt: str | None = Field(default=None, alias="compileLogExcerpt")

    model_config = ConfigDict(extra="forbid", populate_by_name=True)
