# ResumeForge

Paste a job description, upload whatever resume or bio-data you already have,
and get back an ATS-safe PDF and an editable Word file that actually target the
role. Editable three ways: section forms, plain-language prompts, or raw LaTeX.

---

## Architecture

```
┌─────────────────────────────────────────────┐
│  apps/web — Next.js 15 (TypeScript)         │
│  UI · auth · MongoDB · Gemini · JD ingest   │
└──────────────────┬──────────────────────────┘
                   │ HTTP + X-Service-Token
┌──────────────────▼──────────────────────────┐
│  services/docsvc — FastAPI (Python, Docker) │
│  ingest · LaTeX→PDF · JSON→DOCX · ATS lint  │
└─────────────────────────────────────────────┘
```

The split is by capability, not preference. Python owns the document pipeline
because Docling's reading-order reconstruction is what makes a photographed
bio-data usable, and because the TeX engine needs a long-running container that
serverless can't provide. Node owns everything else because of Next.js
streaming and a single shared type system.

### Four decisions everything else follows from

1. **One canonical JSON, two independent renderers.** `schema/resume.schema.json`
   is the source of truth. PDF comes from LaTeX; DOCX comes from `python-docx`
   directly. We never convert LaTeX→DOCX — converters emit text boxes, which are
   among the structures ATS parsers handle worst, so converting would turn a safe
   document into an unsafe one.

2. **ATS-friendliness is measured, not claimed.** `app/atslint/engine.py` renders
   the PDF then re-extracts it with PyMuPDF — a library that had no part in
   building it — and diffs the recovered fields against the canonical JSON. Field
   recovery rate is the score. A template that looks beautiful and loses the
   phone number scores badly and says so.

3. **The model may rephrase, never invent.** Every bullet carries `origin` and,
   when AI-rewritten, a `sourceId`. The schema rejects an `ai-rewritten` bullet
   with no source, and `enforceProvenance()` downgrades any bullet whose source
   doesn't exist in the original. Missing requirements surface as gap cards, not
   invented experience.

4. **Prompt edits are JSON Patches, not regenerations.** Free undo, no collateral
   damage to untouched sections, and a visible diff the user approves.

---

## Setup

```bash
unzip resumeforge.zip && cd resumeforge
./scripts/setup.sh          # creates .env, generates secrets, runs the checks
# add your GEMINI_API_KEY to .env  (https://aistudio.google.com/apikey)
npm run dev                 # mongo + docsvc + web
```

That's the whole thing. Sign-in is optional, rate limiting is off, and phone
sign-in accepts a fixed code — see the limitations section before exposing this
to anyone.

### Docker (recommended — the TeX engine is already primed)

```bash
docker compose up --build
# web    → http://localhost:3000
# docsvc → http://localhost:8000/health
```

The first build takes several minutes: it downloads Tectonic and primes its
package cache by compiling a probe document. That priming is required, not an
optimisation — the compile container runs with **no network access**, so an
unprimed cache means every compile fails. See `docs/SECURITY.md`.

### Local, without Docker

```bash
# docsvc
cd services/docsvc
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
# Tectonic must be on PATH: https://tectonic-typesetting.github.io
uvicorn app.main:app --reload --port 8000

# web
cd apps/web && pnpm install && pnpm dev
```

---

## Verifying it works

```bash
# Everything checkable without node_modules, TeX, or an API key.
# Wire this into CI as the pre-install gate.
./scripts/check-all.sh

# Regenerate the 12 template packages after editing scripts/gen_templates.py
python3 scripts/gen_templates.py

# Full suite, inside the container (needs Tectonic + PyMuPDF)
cd services/docsvc && pytest -v
```

Three checks run, and each exists because it caught a real bug during the build:

| Check | Catches |
|---|---|
| `check-schema-drift.mjs` | A field added to Zod but not Pydantic. Pydantic runs `extra="forbid"`, so that drift makes the render service 422 on exactly the documents that most need rendering — a production outage from a one-line edit. |
| `check-web.mjs` | Imports naming exports nobody wrote, `fetch` calls to routes that don't exist, response fields the caller reads but the route never sends, missing `"use client"`, credentials leaking through `NEXT_PUBLIC_`. Plus ownership discipline: a DB-writing route that never resolves an owner, an owner id read from the request body, an inverse patch trusted from a caller, a missing TTL index on anonymous data. |
| `check-templates.mjs` | A manifest that declares its own `atsScore` (scores are measured, not asserted), a multi-column template graded A, a multi-column template with no risk note, a template rendering a photo, an option with no default, a category referenced by a manifest but missing from `ROLE_FAMILIES`, or grade-A templates failing to outnumber the rest. |
| `check-web.mjs` (build-ability) | A compose service that builds from a path with no Dockerfile, `next.config` missing `output:"standalone"` when the Dockerfile expects it, `useSearchParams` in a client page with no Suspense boundary, and `session.user.id` used without the next-auth module augmentation. Each of these is a hard build failure, not a warning. |
| `verify_latex.py` | Escaping failures, greedy control sequences, unbalanced braces, unconsumed Jinja delimiters, duplicate `\titleformat` declarations, legacy bio-data leaking into the page, and a single-column template that quietly emitted `multicol`. Runs against **all 12 templates**, each rendered with a fixture built from every character that breaks LaTeX pipelines. |

The load-bearing test is `test_ats_roundtrip_recovers_contact_and_employment`.
It renders a resume built out of every character that breaks LaTeX pipelines —
`Ernst & Young`, `C#`, `user_accounts`, `100%`, `₹200Cr`, curly quotes, em
dashes — then re-extracts the PDF and asserts the data survived. If that test
fails, our ATS claim is false.

---

## The template catalogue

12 templates, 9 grade A and 3 grade B. That ratio is enforced by CI: if the
prettier layouts ever outnumber the safe ones, the default experience gets worse
no matter what the picker prefers.

| Template | Cols | Grade | Leads with | For |
|---|---|---|---|---|
| Classic Single Column | 1 | A | experience | most people |
| Compact Technical | 1 | A | skills | dense technical histories |
| Senior Impact | 1 | A | summary | senior, lead, executive |
| Skills Forward | 1 | A | skills | career switchers, returning after a gap |
| Academic CV | 1 | A | publications | faculty, research, doctoral |
| Simple and Clear | 1 | A | experience | bio-data upgrade, trades, retail |
| Banded Sections | 1 | B | experience | design and marketing |
| Two Column | 2 | B | skills rail | when a human reads first |
| Educator | 1 | A | experience | teachers, lecturers |
| Creative Minimal | 1 | B | projects | writers, artists, photographers |
| Formal | 1 | A | education | government, banking, defence |
| Fresher — Projects First | 1 | A | education | first job, internships |

**One base, twelve override sets.** `_shared/base.tex.j2` owns every ATS rule —
the escaping discipline, single-column reading order, contact details in the body
rather than a page header, plain `Label: a, b, c` skills lines. Each template
only declares what makes it different. Twelve copies of that preamble would be
twelve places for the next escaping bug to hide.

**`recommendedOrder` is a hint, not an instruction.** A template can prefer
skills-first, and the tailoring step reads that preference — but the document's
own section order always wins at render time. A template that silently reordered
sections would undo a choice the person made, with no way for them to see why.

**Two-column is honest about its risk.** Entries are never split across columns
(a job title separated from its own bullets is unrecoverable), but interleaved
extraction order is still possible, so it is graded B and carries an `atsNote`
the gallery displays. CI refuses to let a multi-column template claim grade A.

### Adding a template

No application code changes required.

```
services/docsvc/templates/<your-id>/
├── template.json     # manifest: categories, ATS grade, options schema
├── main.tex.j2       # \BLOCK{ extends '_shared/base.tex.j2' } + overrides
├── preview.png       # 600×850
└── packages.txt      # CTAN closure
```

Easiest path: add an entry to `SPECS` in `scripts/gen_templates.py` and rerun it.
That keeps the LaTeX in one reviewed place.

The manifest's `options` block is a mini JSON Schema, so the design panel in the
web app **renders itself** from it. Add a control to the manifest and it appears
in the UI.

Two things to remember:

- Add any new `\usepackage` to the `prime.tex` heredoc in the Dockerfile, or the
  template works locally and fails in production.
- Every resume is pinned to `{templateId, templateVersion}`. Improving a template
  must not silently change a document a user already downloaded, so bump the
  version and keep the old one.

### Template rules learned the hard way

- Use `sec['items']`, not `sec.items`. Jinja resolves `getattr` before
  `getitem`, so `.items` on a dict returns the **built-in method** and the
  render dies with "not iterable". Subscript syntax works for both dicts and
  Pydantic models.
- Put a space after any size or shape command that precedes an interpolation.
  `{\normalsize\VAR{x}}` becomes `\normalsizeBackend` — one undefined control
  sequence. `verify_latex.py` lints for this.
- Apply a filter to every interpolation. `\VAR{x}` unescaped is a compile
  failure the first time someone works at a company with an ampersand.

---

## Status

**Working**
- Entry screen (one screen, mode inferred), editor shell with three edit modes
- ATS score as the signature visual; gap cards; change notes; finding groups
- Save-triggered auth: persist under an anonymous session, then offer an account,
  then transfer ownership. See `docs/AUTH.md` for why that order is mandatory
- MongoDB layer: resumes, append-only patch log with server-computed inverses,
  global JD cache, sliding-window rate limiter
- Version history with undo; undo is recorded forward, never rewritten
- Auth.js with phone (stub), Google and email link — all optional
- All 12 templates, one shared base: `_shared/base.tex.j2` owns every ATS rule,
  each template is an override set rather than a copy
- Template gallery with visible grades; Design tab in the editor switches live
- Dashboard listing saved resumes, working for anonymous owners too
- Canonical schema with provenance enforcement (JSON Schema + Zod + Pydantic)
- LaTeX templating: escaping, two-pass Unicode normalisation, date formatting
- Template package format with self-rendering options panel
- Template 1 of 12: `ats-classic-single` (grade A), verified render
- PDF renderer with sandboxed Tectonic compilation
- Independent DOCX renderer, asserted free of tables and text boxes
- ATS lint: round-trip recovery, reading-order detection, rule checks, grading
- Ingestion routing with vision fallback for photographed documents
- Gemini layer: extraction, JD parsing, tailoring with gap cards, prompt→patch
- API routes: `/api/tailor`, `/api/patch`, `/api/jd`, `/api/render`
- Hardened container + documented sandbox

**Next**
- Replace the phone OTP stub with a real SMS provider (one function:
  `verifyCode()` in `lib/auth-phone.ts`)
- CodeMirror LaTeX panel behind the eject flow (`/compile/tex` already exists)
- Template preview thumbnails (`preview.png` per package; the gallery reads them)
- Drag reordering in the section editor (`dnd-kit` already a dependency)
- Auth on the save path only; rate limiting on the build path
- Drag reordering in the section editor (`dnd-kit` is already a dependency)
- CodeMirror LaTeX panel behind the eject flow (`/compile/tex` already exists)
- Education `details` bullets aren't editable in the form pane yet — only
  `experience` and generic-section bullets are

- All 12 templates ship: 9 grade A, 3 grade B, covering 54 role categories.
  One shared `_shared/base.tex.j2` holds the ATS rules; each template overrides
  only typography, density and layout
- Phone OTP sign-in, wired end to end as a guarded static stub
- Template gallery, design panel and dashboard

**Known limitations, stated plainly**
- **Phone OTP accepts a fixed code.** It refuses to load in production without an
  explicit magic-string override, logs every use, and CI fails if those guards
  are removed. Read `docs/AUTH.md` before deploying.
- **Rate limiting is disabled** (`RATE_LIMIT_ENABLED=false`) for single-user use.
  Turn it on before anyone else can reach the app.
- Grade B templates use a second column. Extraction stays in order in our tests,
  but a single-column template is measurably safer — the per-document score in
  the editor is the number to trust, not the template's declared grade.
- Anonymous drafts live in memory, so a refresh loses them. The editor says so
  and offers to start again rather than showing an empty form. Persisting a
  stranger's resume before they've asked us to would be the wrong default.
- The DOCX is intentionally plainer than the PDF. One DOCX renderer serves every
  template, because DOCX ATS-safety is structural, not decorative.
- **Phone sign-in is a static-code stub.** It accepts a fixed code for any
  number — a complete authentication bypass. It refuses to load when
  `NODE_ENV=production` unless an explicitly-named override is set, logs on every
  use, and marks accounts `authProvider: "phone-static"` so a production database
  can be audited. CI fails if the fence is removed. Swap `verifyCode()` for a
  provider call and delete `STATIC_CODE`; nothing else changes.
- **Rate limiting is off** (`RATE_LIMIT_ENABLED=false`) for personal use. Turn it
  on before the app is reachable by anyone else — each build spends several
  Gemini calls plus a LaTeX compile.
- Template preview images aren't drawn yet, so the gallery shows text cards.
- Education `details` bullets aren't editable in the form pane; experience and
  generic sections are.
- Anonymous saves expire after 7 days by design. The UI states the deadline
  rather than letting anyone assume permanence.

---

## Docs

- `docs/SECURITY.md` — the LaTeX sandbox. **Read before deploying.**
- `docs/AUTH.md` — ownership, the claim, and why persist-then-authenticate.
- `schema/resume.schema.json` — the contract everything else obeys.
